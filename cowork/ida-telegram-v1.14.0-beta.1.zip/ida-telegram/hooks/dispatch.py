#!/usr/bin/env python3
"""Hook runtime entry point.

Invoked as ``dispatch.py <client> <event>``.
Reads the hook payload as JSON on stdin, normalizes client + event, runs
the plugin's registered handlers, merges their results, and prints the response.
"""

from __future__ import annotations

import importlib.util
import json
import os
import re
import sys
from collections.abc import Callable
from dataclasses import asdict, dataclass, field, fields
from datetime import UTC, datetime
from enum import Enum
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class HookContext:
    client: str
    event: str
    tool: str = ""
    command: str = ""
    session_id: str = ""
    agent_type: str = ""
    agent_id: str = ""
    prompt_id: str = ""
    transcript_path: str = ""
    cwd: str = ""
    hook_event_name: str = ""
    # The tool call's arguments: Claude Code's ``tool_input``, agy's
    # ``toolCall.args``. Empty on events that carry no tool call.
    tool_input: dict[str, Any] = field(default_factory=dict)
    # PostToolBatch only: every tool call in the resolved batch, each a
    # ``{tool_name, tool_input, tool_use_id, tool_response}`` mapping. Empty on
    # every other event, so a handler can read it without guarding the event.
    tool_calls: tuple[dict[str, Any], ...] = ()
    raw: dict[str, Any] = field(default_factory=dict)
    hooks_dir: Path = field(default_factory=Path)
    _aops_date: str = field(default_factory=lambda: datetime.now(UTC).isoformat())


class Kind(Enum):
    """One of three dispositions, in descending order of force.

    ``REFUSE`` denies a tool call outright and is reserved for structural
    impossibility — the session as configured cannot carry the call out, so
    letting it through produces a hang rather than an outcome. It is never a
    rule verdict.

    ``BLOCK`` refuses to let a *stop* land: the turn continues so the agent
    can do the thing the hook asked for. It is legal only on the events in
    ``BLOCKABLE_EVENTS``, because no other event has a stop to withhold.

    ``ADVISE`` is neither: text the agent reads and weighs, which is what
    every rule-driven handler is limited to.

    One field with three values rather than a flag per disposition, so a result
    cannot hold two at once. The renderers resolve the dispositions in their own
    order, and a result that was both a refusal and a block would render as
    whichever each renderer happened to test first.

    Members are compared with ``is``, which holds because the entry point at
    the bottom of this file guarantees one module object — and so one ``Kind``
    class — for the whole run. That guarantee is what makes this an ordinary
    enum rather than something defensive; see the ``__main__`` block.
    """

    ADVISE = "advise"
    REFUSE = "refuse"
    BLOCK = "block"


@dataclass(frozen=True)
class Result:
    inject_text: str
    user_text: str | None = None
    kind: Kind = Kind.ADVISE


def warn(message: str, user_text: str | None = None) -> Result:
    return Result(message, user_text)


def refuse(reason: str, user_text: str | None = None) -> Result:
    return Result(reason, user_text, Kind.REFUSE)


def block(reason: str, user_text: str | None = None) -> Result:
    return Result(reason, user_text, Kind.BLOCK)


def load_message_pair(hooks_dir: Path, name: str) -> tuple[str, str | None]:
    agent_path = hooks_dir / "messages" / f"{name}.md"
    user_path = hooks_dir / "messages" / f"{name}.user.md"
    agent = agent_path.read_text(encoding="utf-8").strip() if agent_path.exists() else ""
    user = user_path.read_text(encoding="utf-8").strip() if user_path.exists() else None
    return agent, user


Handler = Callable[[HookContext], Result | None]

CANONICAL_EVENTS = (
    "SessionStart",
    "SessionEnd",
    "UserPromptSubmit",
    "PreToolUse",
    "PostToolUse",
    "PostToolUseFailure",
    # Fires once after every call in a resolved batch, carrying all of them in
    # ``tool_calls`` — the one event that sees a whole batch rather than a
    # single call. Claude Code only; agy has no wire equivalent.
    "PostToolBatch",
    "SubagentStart",
    "Stop",
    "SubagentStop",
    # Claude Code only; agy has no wire equivalent for any of these.
    "StopFailure",
    "PermissionRequest",
    "PermissionDenied",
    "Notification",
    "PreCompact",
    "PostCompact",
)

STOP_EVENTS = ("Stop", "SubagentStop")
CONTINUATION_EVENTS = ("Stop", "SubagentStop", "PostToolBatch")

# The events a block disposition is honoured on. Claude Code reads
# ``decision: "block"`` on a stop and gives the session another turn; on every
# other event the field is not part of the response contract, so emitting it
# there is a no-op the handler would mistake for enforcement.
BLOCKABLE_EVENTS = STOP_EVENTS


def is_continuation(event: str, raw: dict[str, Any]) -> bool:
    """Is this stop the one our own injection caused, rather than a real one?

    A hook that injects on a stop gives the session another turn, which stops
    again and re-fires the hook; the client marks that re-entry with
    ``stop_hook_active``. Answering yes here is what gives a stop hook
    once-per-chain semantics with no state of its own.

    Claude Code (and Antigravity) can re-fire Stop/SubagentStop for the same
    stop after a hook already ran once for it — the client re-invokes the same
    hook to let it reconsider, and the re-invocation payload carries
    ``stop_hook_active=true``. Treating that re-entry as a fresh stop is the
    loop that hit ``router.py`` on 2026-07-13. Callers must check this before
    ``normalize()``, before logging the fire, and before loading or running any
    handler — structurally, in the dispatcher itself rather than in each
    handler, so every current and future Stop/SubagentStop handler is covered
    without having to remember it.
    """
    return event in CONTINUATION_EVENTS and bool(raw.get("stop_hook_active"))


# The one place a Claude Cowork session is recognised. The dispatcher asks it
# before doing anything, and in Cowork does nothing: Cowork sessions carry
# none of the environment SessionStart needs.
#
# The signal is Claude Code's own, read from the 2.1.314 binary (build
# 2026-10-29, 5c99a5b6). ``CLAUDE_CODE_IS_COWORK`` is in the set of variables
# the host app sets for the session and is read as a boolean
# (``if(i.CLAUDE_CODE_IS_COWORK)return!0``). The surface-name table labels the
# ``CLAUDE_CODE_ENTRYPOINT`` values ``local-agent`` and ``remote_cowork``
# "Cowork"; ``remote_cowork_trigger`` is the Cowork scheduled-run entrypoint
# and ``local_agent`` is the spelling the client normalises to ``local-agent``
# at startup. The client's own Cowork test is the disjunction of the two
# variables. ``claude-desktop`` and ``remote_desktop`` are the desktop app's
# Code tab, and ``CLAUDE_CODE_REMOTE`` is also ``true`` in cloud sessions,
# which keep their hooks; neither is part of the signal. A hook process
# inherits the parent environment (hooks reference, "Inherited environment"),
# so the hook sees what the client set.
COWORK_FLAG_VAR = "CLAUDE_CODE_IS_COWORK"
ENTRYPOINT_VAR = "CLAUDE_CODE_ENTRYPOINT"
COWORK_ENTRYPOINTS = frozenset(
    {"local-agent", "local_agent", "remote_cowork", "remote_cowork_trigger"}
)
# The two spellings Claude Code documents for its own boolean variables
# (``CLAUDE_CODE_REMOTE`` is ``"true"``, ``CLAUDE_CODE_SUBPROCESS_ENV_SCRUB`` is ``1``).
_TRUE_VALUES = frozenset({"1", "true"})


def is_cowork(environ: dict[str, str] | None = None) -> bool:
    """Is this hook running inside a Claude Cowork session?

    ``environ`` defaults to the process environment; tests pass a dict.
    """
    env = os.environ if environ is None else environ
    if (env.get(COWORK_FLAG_VAR) or "").strip().lower() in _TRUE_VALUES:
        return True
    return (env.get(ENTRYPOINT_VAR) or "").strip() in COWORK_ENTRYPOINTS


TO_CANONICAL = {
    "claude": {name: name for name in CANONICAL_EVENTS},
    "agy": {
        "SessionStart": "SessionStart",
        "PreInvocation": "UserPromptSubmit",
        # Deliberately unmapped, not merely omitted: live instrumentation
        # (headless agy 1.1.13, AOPS_HOOK_LOG_PATH plus a wire-level probe on
        # the hook command itself) showed PostInvocation fires once per
        # internal model invocation/tool-call round-trip — three times for a
        # three-tool-call turn — not once per turn. It previously aliased
        # onto "Stop", so every Stop-registered handler on every plugin saw
        # N+1 fires per turn; orchestrate's own agy OTel tracer built and
        # exported a CHAIN span, then deleted its trace state, after each
        # premature fire, fragmenting one turn into several incomplete
        # traces. None of PreToolUse/PostToolUse/Stop/
        # SubagentStop covers "one invocation step finished, possibly not
        # the last" — agy has no wire event at that granularity mapped here,
        # and no currently-live handler (across aops-debug, orchestrate,
        # crew, ida) depends on receiving it, so it is a no-op rather than a
        # guess at some other canonical event.
        "PostInvocation": None,
        "PreToolUse": "PreToolUse",
        "PostToolUse": "PostToolUse",
        "Stop": "Stop",
    },
}


def to_canonical(client: str, wire_event: str) -> str | None:
    mapping = TO_CANONICAL.get(client, {})
    if wire_event in mapping:
        return mapping[wire_event]
    return wire_event


def _log_fire(ctx: HookContext) -> None:
    log_path = os.environ.get("AOPS_HOOK_LOG_PATH")
    if not log_path:
        return
    record = asdict(ctx)
    record["ts"] = datetime.now(UTC).isoformat()
    try:
        path = Path(log_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, default=str) + "\n")
    except OSError:
        pass


def _load_handlers(event: str, hooks_dir: Path) -> list[Handler]:
    handlers_path = hooks_dir / "handlers.py"
    if not handlers_path.exists():
        return []
    spec = importlib.util.spec_from_file_location("handlers", handlers_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"aops hooks: failed to load {handlers_path} (no spec)")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    registry = getattr(module, "HANDLERS", {})
    handlers = list(registry.get(event, []))
    for h in registry.get("*", []):
        if h not in handlers:
            handlers.append(h)
    return handlers


def _run_handler(handler: Handler, ctx: HookContext) -> Result | None:
    try:
        return handler(ctx)
    except Exception as exc:
        name = getattr(handler, "__name__", str(handler))
        msg = f"aops hooks: handler {name!r} failed with {exc!r}"
        print(msg, file=sys.stderr)
        return warn(msg)


def _merge(results: list[Result | None]) -> Result | None:
    """Strongest disposition wins, then first-registered.

    Within one plugin's handlers only. Two plugins registered on the same event
    are two processes and never meet here, so this settles registration order,
    not precedence between plugins — the client decides that.
    """
    present = [r for r in results if r is not None]
    refuses = [r for r in present if r.kind is Kind.REFUSE]
    if refuses:
        if len(refuses) == 1:
            return refuses[0]
        merged_inject = "\n\n".join(r.inject_text for r in refuses if r.inject_text)
        user_texts = [r.user_text.strip() for r in refuses if r.user_text and r.user_text.strip()]
        merged_user = " ".join(user_texts) if user_texts else None
        return Result(merged_inject, merged_user, Kind.REFUSE)
    blocks = [r for r in present if r.kind is Kind.BLOCK]
    if blocks:
        if len(blocks) == 1:
            return blocks[0]
        merged_inject = "\n\n".join(b.inject_text for b in blocks if b.inject_text)
        user_texts = [b.user_text.strip() for b in blocks if b.user_text and b.user_text.strip()]
        merged_user = " ".join(user_texts) if user_texts else None
        return Result(merged_inject, merged_user, Kind.BLOCK)
    if present:
        if len(present) == 1:
            return present[0]
        merged_inject = "\n\n".join(r.inject_text for r in present if r.inject_text)
        user_texts = [r.user_text.strip() for r in present if r.user_text and r.user_text.strip()]
        merged_user = " ".join(user_texts) if user_texts else None
        return Result(merged_inject, merged_user, Kind.ADVISE)
    return None


def _render_claude(result: Result, event: str) -> dict:
    if result.kind is Kind.BLOCK:
        if event in BLOCKABLE_EVENTS:
            # The one shape Claude Code reads as "do not stop": a top-level
            # decision, not nested under hookSpecificOutput.
            blocked: dict[str, Any] = {"decision": "block", "reason": result.inject_text}
            if result.user_text:
                blocked["systemMessage"] = result.user_text
            return blocked

        else:
            # Block only means something on certain events; in case of misconfiguration
            # text is still worth delivering; the disposition is not, and a handler
            # must not read silence here as enforcement that happened.
            print(
                f"dispatch: block() is illegal on event {event!r}; "
                "degraded to advisory — the text was delivered, the block was not",
                file=sys.stderr,
            )

    if result.kind is Kind.REFUSE:
        specific = {
            "hookEventName": event,
            "permissionDecision": "deny",
            "permissionDecisionReason": result.inject_text,
        }
    else:
        specific = {"hookEventName": event, "additionalContext": result.inject_text}

    output: dict[str, Any] = {"hookSpecificOutput": specific}
    if result.user_text:
        output["systemMessage"] = result.user_text
    return output


def _render_agy(result: Result, event: str = "") -> dict:
    """agy has no blockable event, so a block reaches it as advice or not at all.

    Its ``PostInvocation`` response contract is a bare object with no disposition
    field to carry one, and the invocation has already ended by the time the
    event fires. The text still has somewhere to go, so it goes there.
    """
    if result.kind is Kind.REFUSE:
        return {"decision": "deny", "reason": result.inject_text}

    steps: list[dict[str, Any]] = []
    if event == "SessionStart":
        text = result.user_text or result.inject_text
        if text:
            steps.append({"systemMessage": {"systemMessage": text}})
        if result.user_text and result.inject_text and result.inject_text != result.user_text:
            eph = result.inject_text
            if eph.startswith(result.user_text):
                eph = eph[len(result.user_text) :].strip()
            if eph:
                steps.append({"ephemeralMessage": eph})
    else:
        if result.user_text:
            steps.append({"systemMessage": {"systemMessage": result.user_text}})
        if result.inject_text:
            steps.append({"ephemeralMessage": result.inject_text})

    return {"injectSteps": steps}


def render(client: str, event: str, result: Result | None) -> dict:
    if result is None:
        return {}
    if client == "claude":
        return _render_claude(result, event)
    if client == "agy":
        return _render_agy(result, event)
    return {}


_PROC_ROOT = Path("/proc")
_MAX_PROC_ANCESTORS = 12


def _parse_proc_ppid(stat_text: str) -> int:
    """Parse parent PID from Linux /proc/<pid>/stat (handling spaces/parens in comm)."""
    rparen = stat_text.rfind(")")
    if rparen == -1:
        return 0
    fields_after = stat_text[rparen + 1 :].split()
    if len(fields_after) < 2:
        return 0
    return int(fields_after[1])


def _extract_agent_flag(args: list[str]) -> str:
    """Extract `--agent <name>` or `--agent=<name>` from an argv list."""
    for idx, arg in enumerate(args):
        if arg.startswith("--agent="):
            val = arg.split("=", 1)[1].strip()
            if val:
                return val
        elif arg == "--agent" and idx + 1 < len(args):
            val = args[idx + 1].strip()
            if val and not val.startswith("-"):
                return val
    return ""


def _agy_ancestor_agent_name() -> str:
    """Resolve `--agent <name>` from the nearest ancestor `agy` process via Linux /proc."""
    if not (_PROC_ROOT / "self" / "stat").is_file():
        return ""
    pid = os.getpid()
    visited: set[int] = set()
    for _ in range(_MAX_PROC_ANCESTORS):
        if pid <= 1 or pid in visited:
            break
        visited.add(pid)
        proc_dir = _PROC_ROOT / str(pid)
        try:
            raw_cmdline = (proc_dir / "cmdline").read_bytes()
        except (FileNotFoundError, ProcessLookupError):
            raw_cmdline = b""
        if raw_cmdline:
            args = [
                part.decode("utf-8", errors="replace")
                for part in raw_cmdline.rstrip(b"\x00").split(b"\x00")
            ]
            if args and args[0] and (args[0] == "agy" or args[0].endswith("/agy")):
                return _extract_agent_flag(args)
        try:
            stat_text = (proc_dir / "stat").read_text(encoding="utf-8", errors="replace")
        except (FileNotFoundError, ProcessLookupError):
            break
        if not stat_text:
            break
        ppid = _parse_proc_ppid(stat_text)
        if ppid <= 1:
            break
        pid = ppid
    return ""


def resolve_caller_session_id(
    raw: dict[str, Any],
    client: str = "",
    environ: dict[str, str] | None = None,
) -> str:
    """Resolve caller session_id from official client env vars first, then hook stdin."""
    env = os.environ if environ is None else environ
    effective_client = client
    if not effective_client:
        effective_client = "agy" if ("toolCall" in raw or "conversationId" in raw) else "claude"

    if effective_client == "claude":
        env_sid = (env.get("CLAUDE_CODE_SESSION_ID") or env.get("CLAUDE_SESSION_ID") or "").strip()
        if env_sid:
            return env_sid
    elif effective_client == "agy":
        env_sid = (env.get("ANTIGRAVITY_CONVERSATION_ID") or "").strip()
        if env_sid:
            return env_sid

    stdin_sid = (
        raw.get("session_id") or raw.get("conversationId") or raw.get("conversation_id") or ""
    )
    return str(stdin_sid).strip() if stdin_sid else ""


def normalize(client: str, event: str, raw: dict[str, Any], hooks_dir: Path) -> HookContext:
    # agy nests the tool call: ``{"toolCall": {"name": ..., "args": {...}}}``
    # on PreToolUse and PostToolUse. Its PostToolUse carries no tool result.
    tool_call = raw.get("toolCall")
    tool_call = tool_call if isinstance(tool_call, dict) else {}
    tool_input = raw.get("tool_input") or raw.get("toolInput") or tool_call.get("args")
    tool_input = tool_input if isinstance(tool_input, dict) else {}
    command = tool_input.get("command", "")
    raw_calls = raw.get("tool_calls")
    tool_calls = (
        tuple(c for c in raw_calls if isinstance(c, dict)) if isinstance(raw_calls, list) else ()
    )

    valid_keys = {f.name for f in fields(HookContext)}
    kwargs = {k: v for k, v in raw.items() if k in valid_keys and v is not None}

    raw_agent_candidates = (
        raw.get("agent_type"),
        raw.get("agentType"),
        raw.get("agent_name"),
        raw.get("agentName"),
        raw.get("agent"),
        raw.get("subagent_type"),
        raw.get("subagentType"),
        raw.get("subagent_name"),
        raw.get("subagentName"),
    )
    agent_type = ""
    for cand in raw_agent_candidates:
        if isinstance(cand, str) and cand.strip():
            agent_type = cand.strip()
            break
    if not agent_type and client == "agy":
        agent_type = _agy_ancestor_agent_name()
    if not agent_type:
        for cand in (
            os.environ.get("CLAUDE_AGENT_NAME"),
            os.environ.get("AGY_AGENT_NAME"),
            os.environ.get("AOPS_AGENT_NAME"),
            kwargs.get("agent_type"),
        ):
            if isinstance(cand, str) and cand.strip():
                agent_type = cand.strip()
                break

    cwd = raw.get("cwd") or ""
    if not cwd:
        wp = raw.get("workspacePaths") or raw.get("workspace_paths")
        if isinstance(wp, (list, tuple)) and wp:
            cwd = str(wp[0]).strip()
        elif isinstance(wp, str) and wp.strip():
            cwd = wp.strip()

    kwargs.update(
        client=client,
        event=event,
        tool=raw.get("tool_name")
        or raw.get("toolName")
        or tool_call.get("name")
        or kwargs.get("tool", ""),
        tool_input=tool_input,
        command=command,
        cwd=cwd or kwargs.get("cwd", ""),
        session_id=resolve_caller_session_id(raw, client=client)
        or str(kwargs.get("session_id", "")),
        transcript_path=raw.get("transcript_path")
        or raw.get("transcriptPath")
        or kwargs.get("transcript_path", ""),
        agent_type=agent_type,
        agent_id=raw.get("agent_id") or raw.get("agentId") or kwargs.get("agent_id", ""),
        tool_calls=tool_calls,
        raw=raw,
        hooks_dir=hooks_dir,
    )
    return HookContext(**kwargs)


# The operator-visible switch for OTel emission. Read here only to decide
# whether a missing module is worth complaining about; `resolve()` in the
# module itself remains the authority on the destination.
_OTEL_TRACE_ENV = "COPE_EVALUATOR_OTEL_TRACE_PATH"


def _get_evaluator_otel_trace():
    """The OTel emitter, when the plugin this dispatch ships inside provides it.

    `evaluator_otel_trace` ships in crew. This file is shared into every
    plugin's `hooks/` directory, and the entry point puts this module's own
    directory on `sys.path`, so the import below resolves against whichever
    plugin this copy is shipping inside — crew's, in the builds checked. That
    is a file reading its own plugin's directory, not another plugin's. The
    traversal to another plugin's `hooks/` that used to sit here named another
    plugin by path, and in the `dist/<name>-<client>/` layout resolved to
    nothing, leaving the instrumentation a silent no-op.

    Tests may resolve this import by injecting a path instead; the sibling
    rule describes the shipped layout, not every possible one.

    Silence is right when nobody asked for OTel. It is wrong when someone did,
    so that case says so on stderr instead of disappearing.
    """
    try:
        import evaluator_otel_trace  # pyright: ignore[reportMissingImports]

        return evaluator_otel_trace
    except ImportError:
        if os.environ.get(_OTEL_TRACE_ENV):
            print(
                f"aops hooks: {_OTEL_TRACE_ENV} is set but evaluator_otel_trace is not "
                "importable here — OTel instrumentation ships with crew, and this "
                "dispatch is running inside a plugin that does not carry it.",
                file=sys.stderr,
            )
        return None


def _handlers_for_client(handlers: list[Handler], client: str) -> list[Handler]:
    return [
        h
        for h in handlers
        if (scope := getattr(h, "only_on_clients", None)) is None or client in scope
    ]


def _instrument_otel_events(ctx: HookContext) -> None:
    otel_mod: Any = _get_evaluator_otel_trace()
    if otel_mod is None:
        return

    config = otel_mod.resolve()
    if config is None:
        return

    # 1. Tool plumbing errors (unknown_tool, missing_mcp)
    plumbing_err = otel_mod.detect_tool_plumbing_error(ctx)
    if plumbing_err:
        err_type, err_msg = plumbing_err
        otel_mod.record_tool_plumbing_error(
            ctx, error_type=err_type, error_message=err_msg, config=config
        )

    # 2. SendMessage tool call linkage
    is_send_msg = (ctx.tool or "").lower() in ("sendmessage", "send_message") or any(
        isinstance(call, dict)
        and (
            str(call.get("tool_name") or "").lower() in ("sendmessage", "send_message")
            or str(call.get("tool") or "").lower() in ("sendmessage", "send_message")
        )
        for call in ctx.tool_calls
    )
    if is_send_msg:
        otel_mod.record_send_message(ctx, config=config)

    # 3. Agent idle/timeout on Stop or SubagentStop
    idle_timeout = otel_mod.detect_agent_idle_timeout(ctx)
    if idle_timeout:
        otel_mod.record_agent_idle_timeout(ctx, event_type=idle_timeout, config=config)

    # 4. SubagentStop unsent output inspection
    if ctx.event == "SubagentStop":
        otel_mod.record_subagent_stop(ctx, config=config)


def main(argv: list[str]) -> int:
    if len(argv) < 3:
        print("usage: dispatch.py <client> <event>", file=sys.stderr)
        return 1
    client, wire_event = argv[1], argv[2]

    raw: dict[str, Any] = {}
    if not sys.stdin.isatty():
        try:
            raw = json.load(sys.stdin)
        except json.JSONDecodeError:
            raw = {}

    # In a Claude Cowork session the hooks do nothing: no fire is logged, no
    # handler runs, nothing is printed. The payload is read first so the
    # client's write never meets a closed pipe.
    if is_cowork():
        return 0

    hooks_dir = Path(__file__).resolve().parent
    if str(hooks_dir) not in sys.path:
        sys.path.insert(0, str(hooks_dir))

    event = to_canonical(client, wire_event)
    if event is None:
        # Plugins with a wildcard ("*") handler (e.g. aops-debug) observe client
        # wire events even when no canonical hook name exists for them.
        if not _handlers_for_client(_load_handlers("*", hooks_dir), client):
            return 0
        event = wire_event

    # Do not fire if we have already prevented a stop event this turn
    if is_continuation(event, raw):
        return 0

    ctx = normalize(client, event, raw, hooks_dir)
    _log_fire(ctx)
    _instrument_otel_events(ctx)

    kept_handlers = _handlers_for_client(_load_handlers(event, hooks_dir), client)

    results = [_run_handler(h, ctx) for h in kept_handlers]
    result = _merge(results)

    output = render(client, event, result)
    if output:
        print(json.dumps(output))
    return 0


_AGY_USER_REQUEST = re.compile(r"<USER_REQUEST>\s*(.*)\s*</USER_REQUEST>", re.DOTALL)
_AGY_MESSAGE = re.compile(
    r"\[Message\][^\n]*?\bsender=(\S+)[^\n]*?\bcontent=(.*?)\s*(?:</SYSTEM_MESSAGE>\s*)?$",
    re.DOTALL,
)


def _tracer_state_dir() -> Path:
    env_dir = (
        os.environ.get("AOPS_TRACER_STATE_DIR")
        or os.environ.get("TRACER_STATE_DIR")
        or os.environ.get("AOPS_TRACER_DIR")
    )
    if env_dir:
        return Path(env_dir)
    return Path.home() / ".claude" / "tracer"


def _is_session_start_or_harness_injection(content: str) -> bool:
    """True if a SYSTEM_MESSAGE is a SessionStart hook message or harness banner."""
    s = content.lower()
    return "injected by a sessionstart hook" in s or (
        "session:" in s and "host:" in s and "cwd:" in s
    )


def _agy_candidate_transcripts(ctx: HookContext) -> list[Path]:
    raw_path = ctx.transcript_path or ctx.raw.get("transcriptPath")
    candidates: list[Path] = []
    if raw_path:
        p = Path(raw_path)
        if p.is_file():
            candidates.append(p)
        parent = p.parent
        for alt_name in ("transcript.jsonl", "transcript_full.jsonl"):
            alt_path = parent / alt_name
            if alt_path.is_file() and alt_path not in candidates:
                candidates.append(alt_path)
    return candidates


def _read_all_agy_entries(ctx: HookContext) -> list[dict[str, Any]]:
    candidates = _agy_candidate_transcripts(ctx)
    if not candidates:
        return []
    entries_by_index: dict[int, dict[str, Any]] = {}
    fallback_entries: list[dict[str, Any]] = []

    for path in candidates:
        try:
            with open(path, encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        entry = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    if not isinstance(entry, dict):
                        continue
                    step_idx = entry.get("step_index")
                    if isinstance(step_idx, int):
                        existing = entries_by_index.get(step_idx)
                        if existing is None:
                            entries_by_index[step_idx] = entry
                        elif "content" in existing.get(
                            "truncated_fields", []
                        ) and "content" not in entry.get("truncated_fields", []):
                            entries_by_index[step_idx] = entry
                    else:
                        fallback_entries.append(entry)
        except OSError:
            continue

    if entries_by_index:
        return [entries_by_index[idx] for idx in sorted(entries_by_index.keys())]
    return fallback_entries


def _agy_turn_start(ctx: HookContext) -> dict[str, Any] | None:
    inv = (ctx.raw or {}).get("invocationNum", 0)
    if inv is not None and inv != 0:
        return None
    entries = _read_all_agy_entries(ctx)
    if not entries:
        return None
    for entry in reversed(entries):
        entry_type = entry.get("type")
        if entry_type == "USER_INPUT":
            return entry
        if entry_type == "SYSTEM_MESSAGE":
            content = str(entry.get("content") or "")
            if _is_session_start_or_harness_injection(content):
                continue
            return entry
    return None


def agy_arrival(content: str) -> str:
    """The report or direction an agy SYSTEM_MESSAGE delivers, or '' when it delivers none."""
    m = _AGY_MESSAGE.search(content)
    if not m:
        return ""
    sender, body = m.group(1), m.group(2).strip()
    if sender == "system" or "/" in sender:
        return ""
    return body


def _agy_user_prompt(ctx: HookContext) -> str:
    """The user's text for an agy turn, read from the turn's transcript."""
    turn_start = _agy_turn_start(ctx)
    if not turn_start:
        return ""
    if turn_start.get("type") == "USER_INPUT":
        content = str(turn_start.get("content") or "").strip()
        m = _AGY_USER_REQUEST.search(content)
        return (m.group(1) if m else content).strip()
    if turn_start.get("type") == "SYSTEM_MESSAGE":
        content = str(turn_start.get("content") or "").strip()
        arrival = agy_arrival(content)
        if arrival:
            return arrival
    return ""


def prompt_text(ctx: HookContext) -> str:
    """Extract prompt text canonically across Claude Code and agy."""
    prompt = ctx.raw.get("prompt")
    if prompt is None and hasattr(ctx, "prompt"):
        prompt = ctx.prompt
    if isinstance(prompt, dict):
        prompt = prompt.get("text") or prompt.get("content") or ""
    text = str(prompt or "").strip()
    if not text and ctx.client == "agy":
        text = _agy_user_prompt(ctx)
    return text


def _has_subagent_marker(text: str) -> bool:
    return "<subagent_reminder>" in text or "invoked by a caller agent" in text


def _initial_agy_turn_content(ctx: HookContext) -> str:
    """Content of the first non-harness turn-start entry in an agy transcript."""
    for entry in _read_all_agy_entries(ctx):
        entry_type = entry.get("type")
        if entry_type == "USER_INPUT":
            return str(entry.get("content") or "")
        if entry_type == "SYSTEM_MESSAGE":
            content = str(entry.get("content") or "")
            if _is_session_start_or_harness_injection(content):
                continue
            return content
    return ""


def _is_subagent_conversation(ctx: HookContext) -> bool:
    """True if ctx is an agy subagent conversation invoked by a caller agent."""
    raw = ctx.raw or {}
    if (
        raw.get("caller_id")
        or raw.get("parent_conversation_id")
        or raw.get("is_subagent")
        or raw.get("caller_session")
    ):
        return True
    if ctx.session_id:
        try:
            tracer_file = _tracer_state_dir() / f"{ctx.session_id}.json"
            if tracer_file.is_file():
                tdata = json.loads(tracer_file.read_text(encoding="utf-8"))
                phx_sid = tdata.get("phoenix_session_id")
                if phx_sid:
                    phx_root = str(phx_sid).split("/", 1)[0]
                    if phx_root and phx_root != ctx.session_id:
                        return True
                if tdata.get("parent_session_id") or tdata.get("caller_session_id"):
                    return True
        except Exception:
            pass
    if ctx.client == "agy" and ctx.event == "PreToolUse":
        direct_prompt = raw.get("prompt")
        if direct_prompt is None and hasattr(ctx, "prompt"):
            direct_prompt = ctx.prompt
        if isinstance(direct_prompt, dict):
            direct_prompt = direct_prompt.get("text") or direct_prompt.get("content") or ""
        if _has_subagent_marker(str(direct_prompt or "")):
            return True
        return _has_subagent_marker(_initial_agy_turn_content(ctx))
    prompt = prompt_text(ctx) or ""
    if _has_subagent_marker(prompt):
        return True
    return False


if __name__ == "__main__":
    # Hand off to this same file imported under its own name, and do no work
    # here. Running it directly makes it the module ``__main__``; a plugin's
    # ``handlers.py`` then does ``from dispatch import ...``, which loads the
    # file a second time as ``dispatch``. Calling ``main`` on this side would
    # leave the handlers building results from one set of classes while the
    # renderers tested another — ``Result`` and ``Kind`` would be two unrelated
    # types with the same names, so every ``is`` comparison would be false and
    # every disposition would degrade to an advisory while reporting success.
    #
    # Re-entering here makes ``dispatch`` the only module that does anything:
    # handlers import it, ``main`` runs inside it, one set of classes. This
    # block is the whole reason those comparisons can be identity checks.
    sys.path.insert(0, str(Path(__file__).resolve().parent))

    import dispatch

    try:
        sys.exit(dispatch.main(sys.argv))
    except Exception as exc:
        print(f"dispatch: fatal error: {exc!r}", file=sys.stderr)
        sys.exit(1)
