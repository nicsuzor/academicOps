#!/usr/bin/env python3
"""Record a premise-check verdict, emit its OpenTelemetry span, and disarm the gate.

A verdict is one token (PASS, REVISE, FAIL) and the checker's reason. A PASS
reason must carry every keyed line of the skill's checker reason and pass
the mechanical cross-checks against the judged text the gate stored at arm
time; REVISE and FAIL take any reason. The reason may come from a file or stdin
so that free text stays off the command line, where harness guards scan it.

A verdict is recorded only once its span is exported: an unconfigured tracer or
an unacknowledged export raises, and the gate stays armed.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
import time
from pathlib import Path
from typing import Any

import report_argument as ra
from premise_check_gate import disarm, get_judged, get_state, is_armed, mint_verification_id

VERDICTS: tuple[str, ...] = ("PASS", "REVISE", "FAIL")

_TASK_ID_RE = re.compile(
    r"^(?:task|epic|aops|wf)[_-][a-zA-Z0-9_-]+$"
    r"|^(?:[a-z][a-z0-9-]*[_-])?[0-9a-f]{8}$"
    r"|^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$"
    r"|^(?:engine-)?task-\d+$",
    re.IGNORECASE,
)
_NON_TASK_PREFIXES = ("claim-", "verdict-", "report-", "toolu_")
_KNOWN_NON_TASK_IDS = {"ns", "default", "academicops", "aops"}


def is_task_id(identifier: str) -> bool:
    """Return True if identifier resembles a task or epic ID."""
    if not identifier:
        return False
    tid = identifier.strip()
    low = tid.lower()
    if low in _KNOWN_NON_TASK_IDS:
        return False
    if any(low.startswith(p) for p in _NON_TASK_PREFIXES):
        return False
    if _TASK_ID_RE.match(tid):
        return True
    if re.match(r"^[a-z][a-z0-9_.-]*[_-][0-9a-f]{6,}$", tid, re.IGNORECASE):
        return True
    return False


def _import_claude_code_tracer() -> Any:
    import claude_code_tracer  # type: ignore[import-not-found]

    return claude_code_tracer


def _surface(state: dict[str, Any] | None) -> str:
    if os.environ.get("GITHUB_ACTIONS"):
        return "github-actions"
    if state and state.get("surface") == "agy":
        return "agy"
    if os.environ.get("ANTIGRAVITY_CLI") or os.environ.get("GEMINI_CLI"):
        return "agy"
    return "claude-code"


def _export_tool_span(
    tracer_mod: Any,
    session_id: str,
    tool_name: str,
    tool_input: dict[str, Any],
    tool_response: dict[str, Any],
    attributes: dict[str, Any],
    config: dict[str, Any] | None,
) -> None:
    """Ship one TOOL span through claude_code_tracer's pipeline, or raise RuntimeError."""
    if config is None:
        config = tracer_mod.discover_config()
    if config is None:
        raise RuntimeError("premise_check_verdict: tracing is not configured (no OTel endpoint)")

    now_ns = time.time_ns()
    trace_id = tracer_mod._new_trace_id()
    parent_span_id = tracer_mod._new_span_id()

    phoenix_session_id = os.environ.get("AOPS_SESSION_ID") or session_id
    state = tracer_mod._load_state(phoenix_session_id)
    current_trace = state.get("current_trace") if state else None
    if current_trace:
        trace_id = current_trace["trace_id"]
        parent_span_id = current_trace["root_span_id"]

    record = tracer_mod._build_tool_span_record(
        tool_name=tool_name,
        tool_input=tool_input,
        tool_response=tool_response,
        start_ns=now_ns,
        end_ns=now_ns + 1_000_000,
        trace_id=trace_id,
        root_span_id=parent_span_id,
    )
    surface = _surface(state)
    record["attributes"].update(attributes)
    record["attributes"]["service.name"] = "aops-verdict-hooks"
    record["attributes"]["aops.surface"] = surface

    username = os.environ.get("USER") or os.environ.get("USERNAME") or None
    try:
        exported = tracer_mod._build_and_export_spans(
            config=config,
            session_id=phoenix_session_id,
            username=username,
            span_records=[record],
            service_name="aops-verdict-hooks",
            surface=surface,
        )
    except Exception as exc:
        raise RuntimeError(f"premise_check_verdict: OTel span export failed: {exc!r}") from exc
    if exported is not True:
        raise RuntimeError("premise_check_verdict: OTel span export failed")


def emit_verdict_span(
    tracer_mod: Any,
    session_id: str,
    claim_id: str,
    verdict: str,
    reason: str,
    verification_id: str = "",
    title: str | None = None,
    config: dict[str, Any] | None = None,
    attributes: dict[str, Any] | None = None,
) -> bool:
    """Ship one TOOL span for this verdict via claude_code_tracer's pipeline.

    Returns True when the OTLP exporter reported SUCCESS for the span; raises
    RuntimeError when tracing is unconfigured or the export was not acknowledged.
    """
    tool_input: dict[str, Any] = {"claim_id": claim_id, "verdict": verdict, "reason": reason}
    if title:
        tool_input["title"] = title
    tool_response: dict[str, Any] = {"status": "recorded"}
    if verification_id:
        tool_response["verification_id"] = verification_id

    attrs: dict[str, Any] = {
        "premise_check.claim_id": claim_id,
        "premise_check.verdict": verdict,
        "premise_check.reason_text": tracer_mod._truncate(reason),
    }
    if verification_id:
        attrs["premise_check.verification_id"] = verification_id
    if title:
        attrs["premise_check.title"] = title
    attrs.update(attributes or {})

    _export_tool_span(
        tracer_mod,
        session_id,
        "premise_check_verdict",
        tool_input,
        tool_response,
        attrs,
        config,
    )
    return True


def emit_override_span(
    tracer_mod: Any,
    session_id: str,
    claim_id: str,
    tool: str,
    event: str,
    variable: str,
    override_count: int,
) -> bool:
    """Ship one ``premise_check_override`` span; raises like ``emit_verdict_span``."""
    attrs = {
        "premise_check.claim_id": claim_id,
        "premise_check.override_var": variable,
        "premise_check.override_tool": tool,
        "premise_check.override_event": event,
        "premise_check.override_count": override_count,
    }
    _export_tool_span(
        tracer_mod,
        session_id,
        "premise_check_override",
        {"claim_id": claim_id, "tool": tool, "event": event, "variable": variable},
        {"status": "passed"},
        attrs,
        None,
    )
    return True


def emit_hearsay_span(
    tracer_mod: Any,
    session_id: str,
    claim_id: str,
    event: str,
    judged_ref: str | None = None,
    attributes: dict[str, Any] | None = None,
    config: dict[str, Any] | None = None,
) -> bool:
    """Ship one TOOL span for this hearsay check via claude_code_tracer's pipeline."""
    attrs: dict[str, Any] = {
        "hearsay.claim_id": claim_id,
        "hearsay.event": event,
        "hearsay.status": "armed",
        "premise_check.claim_id": claim_id,
    }
    if judged_ref:
        attrs["hearsay.judged_ref"] = judged_ref
        attrs["premise_check.judged_ref"] = judged_ref
    if attributes:
        attrs.update(attributes)

    _export_tool_span(
        tracer_mod,
        session_id,
        "hearsay_check",
        {"claim_id": claim_id, "event": event},
        {"status": "armed"},
        attrs,
        config,
    )
    return True


def judge_reason(token: str, reason: str, judged_text: str | None) -> dict[str, Any]:
    """Parse the reason against the judged block; for PASS, refuse on any failed check.

    Returns the verdict's span attributes. Raises ValueError naming every
    failed check when a PASS reason is refused.
    """
    vocab = ra.load_vocabulary()
    parsed = ra.parse_reason(reason, vocab)
    block_text = ra.extract_block(judged_text)
    block_err: str | None = None
    if token == "PASS" and block_text is not None and not ra.is_null_form(block_text):
        if "block" not in parsed.waived_items(vocab):
            valid, parser_output, _ = ra.check_argdown_block(block_text)
            if not valid:
                block_err = parser_output

    block = (
        ra.parse_block(block_text, vocab)
        if (block_text is not None and block_err is None)
        else None
    )
    if token == "PASS":
        failures = ra.pass_failures(
            parsed,
            block,
            vocab,
            is_null=ra.is_null_form(block_text),
            block_text=block_text,
            block_error=block_err,
        )
        if failures:
            formatted = []
            for f in failures:
                remedy = ra.remediation_for_failure(f)
                if remedy:
                    formatted.append(f"{f}\n{remedy}")
                else:
                    formatted.append(f)
            raise ValueError(
                "PASS refused -- the reason fails the recorder's checks "
                "(see the premise-check skill's checker reason):\n- " + "\n- ".join(formatted)
            )
    elif token in ("REVISE", "FAIL"):
        valid_lines = parsed.get("Valid")
        if valid_lines:
            valid_entries = parsed.valid_entries()
            all_hold = all(m is not None and m.group("word") == "holds" for m in valid_entries)
            if all_hold:
                has_unanswered = False
                for ans in parsed.answered():
                    if ans is not None and ans[1] is None:
                        has_unanswered = True
                        break
                if not has_unanswered:
                    for entry in parsed.get("Answered"):
                        if "unanswered" in entry.lower():
                            has_unanswered = True
                            break
                if not has_unanswered:
                    for line in reason.splitlines():
                        if re.search(r"^\s*asks?\s*:.*?\bunanswered\b", line, re.IGNORECASE):
                            has_unanswered = True
                            break
                if not has_unanswered:
                    raise ValueError(
                        f"{token} refused -- reason has Valid entries that all hold and no "
                        f"Ask: ... -> unanswered; {token} requires at least one failing "
                        f"inference step ('Valid: (n) fails -- <defect>') or unanswered ask.\n"
                        f"Required remediation format: For {token}, record at least one failing step or unanswered ask:\n"
                        f"  Valid: (n) fails #<defect-tag> -- <explanation of failure>\n"
                        f"  # or:\n"
                        f"  Answered: <ask_id> unanswered"
                    )
    return ra.span_attributes(parsed, block, vocab)


def record_verdict(
    session_id: str = "",
    claim_id: str = "",
    verdict: str = "",
    reason: str = "",
    title: str | None = None,
    tracer_mod: Any | None = None,
    machine: bool = False,
) -> dict[str, Any]:
    """Validate, emit the span, and disarm the premise check."""
    cid = (claim_id or "").strip()
    if not cid:
        raise ValueError("a verdict needs a report id; got none")

    token = (verdict or "").strip().upper()
    if token not in VERDICTS:
        raise ValueError(f"verdict must be one of {', '.join(VERDICTS)}; got {verdict!r}")
    reason = (reason or "").strip()
    if not reason:
        raise ValueError("a verdict needs a reason; got none")

    armed = is_armed(session_id)
    is_task_claim = is_task_id(cid)

    if not armed:
        if not is_task_claim:
            raise ValueError(f"no premise check is currently armed for session {session_id!r}")
        state = get_state(session_id)
    else:
        state = get_state(session_id)
        expected_id = state.get("claim_id")
        valid_ids = state.get("claim_ids") or ([expected_id] if expected_id else [])
        if cid != expected_id and cid not in valid_ids:
            if not is_task_claim:
                raise ValueError(
                    f"unknown or mismatched report id {cid!r}; gate is armed for {expected_id!r}"
                )

    judged_text, judged_ref = get_judged(session_id, cid)
    if is_task_claim and not judged_ref:
        judged_ref = cid
    block_text = ra.extract_block(judged_text)

    entry = (state.get("judged") or {}).get(cid, {})
    block_expected = bool(entry.get("block_expected") or state.get("block_expected"))
    is_peer = block_expected or any(
        str(judged_ref or "").startswith(prefix)
        for prefix in ("<cross-session-message", "<teammate-message", "<task-notification")
    )
    if token == "PASS" and is_peer and block_text is None:
        raise ValueError(
            "PASS refused -- no argument block in judged text: an absent block cannot pass; "
            "send the message back for revision\n"
            "Defect: The judged text does not contain a fenced ```argdown block.\n"
            "Required remediation: Peer messages must end with a valid ```argdown block. "
            "Return the message for revision:\n"
            "  verdict.py --claim <id> --verdict REVISE --reason-file <path>"
        )

    # Machine check on Argdown block for PASS verdicts unless block is waived
    if token == "PASS" and block_text is not None and not ra.is_null_form(block_text):
        vocab = ra.load_vocabulary()
        parsed_reason = ra.parse_reason(reason, vocab)
        if "block" not in parsed_reason.waived_items(vocab):
            valid, parser_output, _ = ra.check_argdown_block(block_text)
            if not valid:
                raise ValueError(
                    f"PASS verdict refused for {cid}: could not parse argdown block:\n{parser_output}"
                )

    attributes = judge_reason(token, reason, judged_text)
    if machine:
        attributes["premise_check.machine"] = True
    attributes["premise_check.judged_ref"] = judged_ref or ""
    attributes["premise_check.judged_text_sha256"] = (
        hashlib.sha256(judged_text.encode("utf-8")).hexdigest() if judged_text is not None else ""
    )

    clean_title = (title or "").strip() or None
    verification_id = mint_verification_id(cid, token, reason, title=clean_title)

    if tracer_mod is None:
        tracer_mod = _import_claude_code_tracer()

    emit_verdict_span(
        tracer_mod,
        session_id,
        cid,
        token,
        reason,
        verification_id=verification_id,
        title=clean_title,
        attributes=attributes,
    )

    disarm(
        session_id,
        cid,
        token,
        reason,
        verification_id=verification_id,
        title=clean_title,
        machine=bool(attributes.get("premise_check.machine")),
    )

    result: dict[str, Any] = {
        "ok": True,
        "verification_id": verification_id,
        "claim_id": cid,
        "verdict": token,
        "reason": reason,
        "span_emitted": True,
        "span_error": None,
        "disarmed": True,
        "no_claim": bool(attributes.get("premise_check.no_claim")),
        "machine": bool(attributes.get("premise_check.machine")),
    }
    if clean_title:
        result["title"] = clean_title
    return result


def _read_reason(path: str) -> str:
    if path == "-":
        return sys.stdin.read()
    return Path(path).read_text(encoding="utf-8")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="premise_check_verdict.py",
        description="Record a premise-check verdict and disarm the premise check.",
    )
    # Support both direct flags and optional 'verdict' subcommand
    if argv and argv[0] == "verdict":
        argv = argv[1:]

    parser.add_argument(
        "--claim",
        "--report",
        dest="claim",
        required=True,
        help="Identifier or short description of the claim or report.",
    )
    parser.add_argument(
        "--verdict",
        type=str.upper,
        choices=VERDICTS,
        help="PASS, REVISE or FAIL.",
    )
    parser.add_argument(
        "--title",
        default=None,
        help="Optional short title for the verification.",
    )
    reason = parser.add_mutually_exclusive_group()
    reason.add_argument("--reason", help="The checker's reason, inline.")
    reason.add_argument(
        "--reason-file",
        help="Read the reason from this file, or from stdin when '-'.",
    )
    parser.add_argument(
        "--session",
        default=os.environ.get("AOPS_SESSION_ID", ""),
        help="Session id. Defaults to $AOPS_SESSION_ID.",
    )

    args = parser.parse_args(argv)

    if not args.session:
        print(
            "premise_check_verdict: no session id ($AOPS_SESSION_ID unset and --session not given)",
            file=sys.stderr,
        )
        return 1

    if not args.verdict:
        print(
            "premise_check_verdict: error: the following arguments are required: --verdict",
            file=sys.stderr,
        )
        return 2

    if not args.reason and not args.reason_file:
        print(
            "premise_check_verdict: error: one of --reason or --reason-file is required",
            file=sys.stderr,
        )
        return 2

    try:
        text = args.reason if args.reason is not None else _read_reason(args.reason_file)
        result = record_verdict(
            session_id=args.session,
            claim_id=args.claim,
            verdict=args.verdict,
            reason=text,
            title=args.title,
        )
    except (OSError, ValueError, RuntimeError, ImportError) as exc:
        print(f"premise_check_verdict: {exc}", file=sys.stderr)
        return 1

    print(json.dumps(result))
    return 0


if __name__ == "__main__":
    sys.exit(main())
