# Phoenix span-store facts

Canonical facts about the Arize Phoenix OpenTelemetry span store, shared by
every skill that queries or exports it. Read this before writing a query,
sorting spans, or trusting a span's `duration_ms`.

## Classify the identifier before you query

Searching `session.id` with a `trace_id` returns `{"data":[],"next_cursor":null}`
silently, which reads as "telemetry not retained" and is not.

| Identifier | Shape | Example | Query pattern |
| - | - | - | - |
| **`trace_id`** | 32 hex chars, **no dashes** | `c75f0a20a67140e791244eb5dfa64be5` | `WHERE t.trace_id = '<32_HEX>'` on `traces` joined from `spans.trace_rowid` (Recipe A0) -- resolve to `session.id`, then pivot |
| **`session.id`** (session ID / conversation ID) | 36 chars, **dashed UUID** | `22ec8f3e-72c1-4b15-9988-123456789abc` | `WHERE JSON_EXTRACT(attributes, '$.session.id') = '<UUID>'` |
| **session slug** | 6–8 hex chars | `22ec8f3e` | `WHERE JSON_EXTRACT(attributes, '$.session.id') LIKE '%<slug>%'` |
| **`span_id`** | 16 hex chars, **no dashes** | `a1b2c3d4e5f60718` | `WHERE span_id = '<16_HEX>'` |

`spans` has no `trace_id` or `project_name` column (`column_not_allowed`): join
`spans.trace_rowid` to `traces.id`, and `traces.project_rowid` to `projects.id`.

A query returning 0 rows is a reason to re-check the identifier's shape, never
by itself a finding that telemetry was dropped.

## Filter on `session.id`, never `trace_id`

A trace is not session-scoped: OTel context propagates across inter-agent
messages, so one trace can carry spans from more than one session. Grouping
by `trace_id` silently mixes sessions together. Use `trace_id` only to resolve the owning `session.id`,
then pivot every subsequent query onto `session.id`
(`attributes->>'session.id'` / `JSON_EXTRACT(attributes, '$.session.id')`).

Every span and turn-trace belonging to a session carries a consistent
`session.id` (OpenInference attribute matching `session_id` in Claude Code and
`conversationId` in agy), across both harnesses (`claude` and `agy`) and across subagent
activity. That does **not** guarantee nested parent/child span structure, and it does not give
per-agent attribution: a subagent shares the dispatching session's
`session.id` by design, with no attribute marking which agent produced a
given span.

## `turn_number` is not a reliable turn counter

`turn_number` (and `arthur.turn_number`) is scoped per tracer-state file and
resets at that file's init, so when subagents share the parent's `session.id` (in `claude`),
the numbers overlap and repeat within one exported session. In practice it has been observed
to take only the values 1 or 2: a hook-ordering artifact, not a genuine per-turn counter. Never
sort or discriminate on it. Sort by `start_time` for session-wide chronology.

## Dispatch span durations are not the worker's runtime

- In `claude`, a named-teammate dispatch's `AGENT` span (`teammate_spawned`) closes in
  ~150–250 ms, on the spawn acknowledgement, and has no OTel-visible close event tied to
  the teammate's actual work.
- In `agy`, an `invoke_subagent` tool span's duration reflects dispatch / turn latency.
  Detached workers and background tasks finish independently.
- Never read a dispatch span's `duration_ms` as how long the spawned worker ran.

## Timestamps need an offset

`start_time >= '2026-08-19 22:12:00'` fails with `unsupported_syntax`; a time of
day needs an explicit offset (`'2026-08-19 22:12:00+00:00'`). A bare date is
accepted and read as UTC.
