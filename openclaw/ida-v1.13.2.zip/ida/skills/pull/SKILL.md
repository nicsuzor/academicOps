---
name: pull
description: Claim a PKB task, do the job it specifies to completion, record verified evidence under ## Report, and hand over via /dump. Use as the single worker entry point for any task.
---

# /pull -- Task Execution

Claim a PKB task, do the job it specifies, record verified evidence under `## Report`, and invoke `/dump` to hand over.

## 1. Claim & Assemble

- Claim the assigned task via `pkb_claim_task` (`assignee` set to your agent or role), looking it up by exact ID or title (`pkb_get_task`); if invoked on an untracked directive without a task ID, place it via `/q` first, then claim it.
- Verify deliverables as a frozen `## Acceptance` checklist before starting work. If the task lacks `## Instructions` and `## Appendix: Sources` (and is not `invoke /<skill>`), compose its workflow in-session via `/reify`.
- Keep the PKB task updated after major stages so progress survives container pre-emption.

## 2. Do the Job

- Execute the task end-to-end in-session, coordinating subagents in parallel where helpful and reading each target file in full before editing.
- Commit and push scrubbed work incrementally (`data-boundaries`: no private PKB, task, or session IDs, `Task:` trailers, personal names, or private hostnames) so work survives pre-emption.
- Escalate blocking infrastructure or tool failures verbatim without hidden workarounds.
- Deliver everything executable in-session (tests, linters, builds, draft PR, or durable PKB artifact). Queue a dependent follow-up via `/q` (under the governing parent with `needs` edges and zero leaf `serves` edges) only when work requires a different repository, a different execution window or external wait, or a separate external agent or session.

## 3. Consolidate Findings & Durable Facts

- Write the handback under `## Report` solely in clean Argdown prose per `ida:premise-check`, stating the task's original ask and acceptance criteria upfront and quoting deciding primary evidence inline for every load-bearing claim.
- Offer settled durable facts uncovered during work (decisions, architectural constraints, verified system-state facts, or KB corrections -- excluding exploratory thinking aloud) to the custodian (`pauli`) with source pointers, or record them under `## Durable Facts` on the task and handover when isolated.

## 4. Verify Criteria & Determine Status

Verify every criterion against primary evidence (`file:line`, quoted output, counts, PR URL, or test run). Tick (`[x]`) only items directly evidenced; leave others unticked (`[ ]`) with limits stated.

- `done`: All in-scope criteria are met with evidence in `## Report` and delivered where `Output` names (draft PR opened via `gh pr create --draft` with `pr_url` and `branch`, or durable PKB artifact pointer -- never ephemeral scratch paths), and any out-of-session follow-up is queued. Exit without waiting for CI, review, merge, or proof of user installation or deployment.
- `partial`: In-session criteria remain unfinished (blocker, missing tool, scope seam, missing evidence, or pre-work approval boundary), or the task checklist contains an unreachable post-exit criterion (complete reachable work, leave that item unticked, and cite it in `reason`).
- `failed`: Check or review task fails; document failure evidence and root cause.
- Never set `review`, and never create speculative follow-up tasks (`/reconcile` settles partial and failed tasks from the parent).

## 5. Handover (`/dump`)

Always invoke `/dump` on exit regardless of release status (`done`, `partial`, `failed`, `cancelled`, or `in_progress`) so `## Report` and the final handover report are recorded.
