---
name: strategic-review
description: Multi-agent review of an artifact (document, plan, PR). Deploys a rule-compliance reviewer, a strategic-fit reviewer, and a quality reviewer in parallel and reconciles their findings into a single verdict. Pass comment or fix flags to write results back.
---

# Strategic Review

Coordinate multi-agent review across expert lenses and synthesize findings into one reconciled verdict.

## Inputs

- **Artifact**: File path, PKB note ID, inline text, or PR reference (`owner/repo#N`).
- **Flags** (optional): `comment` (post findings to review surface), `fix` (apply minor fixes directly). Without flags, review is advisory.

## Review Process

### 1. Gather Context

Load the artifact, its diff (for PRs), full file contents, metadata, commit messages and trailers, PR title and body, and review replies. Determine destination repository visibility (public or private) and relevant quality standards. If originating from a brief, verify against its acceptance criteria and evidence requirements.

### 2. Strategic Fit Check

Before implementation detail is reviewed, the strategic-fit reviewer (TypeName `pauli`) situates the artifact against the objectives it claims to serve in the PKB graph using the analytical lenses in `../strategize/SKILL.md` and returns an explicit `FIT`/`MISFIT` verdict, distinct from the compliance verdict and the quality verdict. Provide Pauli's strategic-fit brief inline in the dispatch payload (including parent objective, claimed target nodes, and problem definition) rather than directing Pauli to read filesystem workflow templates or repository files, ensuring Pauli remains strictly on the PKB graph.

### 3. Deploy Parallel Reviewers

Dispatch all three reviewers concurrently via `invoke_subagent` in a single message. Every reviewer's brief is drawn from the shared review briefing defined in `wf-review`:

- **Rule compliance** (TypeName `rbg`): Axiom and rule compliance per `wf-rbg`. Confined strictly to artifact text/diff and rule/spec sources.
- **Strategic fit** (TypeName `pauli`): Strategic Fit Check per `wf-strategic-fit`, provided with an inline graph-only brief.
- **Quality** (TypeName `marsha`): Runtime quality, user ask satisfaction, and excellence per `wf-qa`.

Reviewers select 3-4 relevant lenses (e.g. Scope discipline, Self-consistency, Assumption hygiene, Attribution, Feasibility). Every reviewer also judges proportion: whether the artifact is larger than the request needs, and whether each fix it asks for is worth its cost given the failure's likelihood and consequence.

### 4. Reconcile Findings

Synthesize reviewer outputs into a unified findings table:

| Reviewer | Issue | Feedback | Severity |
| - | - | - | - |

- Collapse concordant findings across reviewers into a single row that keeps each reviewer's own severity; where they differ, state the severity adopted and why.
- Give the fit verdict its own row (`FIT`/`MISFIT`), even when concordant with other rows.
- **Severities**: `REJECT` (fundamental redesign, or work out of proportion to the request), `REVISE` (substantial rework), `FIX` (straightforward resolution), `TRIVIAL` (cosmetic polish), `ADVISORY` (non-blocking).
- **Overall verdict**: `APPROVE`, `MINOR CHANGES`, `REVISE`, or `REJECT`. A `MISFIT` forces `REVISE` or `REJECT` even when the compliance and quality reviews both pass. A reviewer's `REJECT` stands unless the synthesis names the finding that overrules it.

### 5. Action and Reporting

- **Default**: Return the synthesis table and overall verdict to the caller.
- **`comment`**: Run the `data-boundaries` check against destination visibility before posting; then post reconciled feedback to the PR review or task note.
- **`fix`**: Run the `data-boundaries` check against destination visibility before pushing; apply `FIX` and `TRIVIAL` remedies immediately.
- Write the final verdict and evidence to the artifact's task record.
