---
name: learn
description: Diagnose systemic root causes of errors from session logs and file anonymised issues or evidence-bump comments in the appropriate repository. Diagnoses only; does not inspect repository source code, propose fixes, or implement remedies directly.
---

# Learn

Perform root-cause analysis on systemic failure classes using session execution records. Diagnose observable failure mechanisms from OpenTelemetry spans (or session logs where the surface does not emit traces) and file an issue or evidence-bump comment at the responsible layer; do not inspect source code or propose fixes directly.

## Worker

Dispatch `/learn` to **`pauli`** (`TypeName: "pauli"`), never `james`. Pauli operates strictly from session execution records (`ida:session-trace`) and the PKB graph without searching or reading repository source code.

## Protocol

1. **Retrieve session execution record**:
   - Query session logs via OpenTelemetry spans using the `ida:session-trace` skill.
   - If the surface does not emit traces, proceed using the session's execution log or transcript directly. If the surface emits traces but the trace is absent, unexported, or incomplete, halt immediately and state that the trace is unavailable.
   - Do not fall back to inspecting, grepping, or reading repository source code.
2. **Diagnose systemic cause from execution evidence**:
   - **Root causes are framework defects, never agent faults.** A root cause is never an agent's fault, capability limitation, choice, or action; it is always the framework's: the instructions, skills, workflows, contracts, or tools that led the agent to act as it did. An agent's action (e.g. dispatching to an agent without necessary credentials or access, rewording an ask, skipping a step, never delivering a result) is an intermediate event on the execution trace, never the root cause. When an agent acts, locate and quote the instruction, skill, workflow, or prompt text that led that agent to take that action, and identify the framework defect (missing constraint, contradictory rule, or ambiguous guidance) that permitted or caused the failure. Never cite an agent, its brief, its capabilities, or its choices as the root cause.
   - **Workflow non-compliance is never a missing rule:** When an agent fails to follow an applicable workflow or skips steps within a workflow, diagnose the failure as poor workflow compliance or ambiguous/unclear instructions within that workflow under the universal framework rule ("follow the applicable workflow"). Never diagnose workflow execution failures as a missing framework-level enforcement rule, and never propose or file issues minting per-workflow framework rules, specs, or gates.
   - **Login and authentication failures are configuration failures, not bugs.** Login and authentication failures (for example a server or service requiring re-authentication) are configuration failures, not bugs. `/learn` files no issue and posts no comment for them; return to the caller that the failure is a configuration failure.
   - **No passive voice; name the actor and quote the instruction.** Use active voice throughout all findings, issue descriptions, and reports; passive voice is strictly prohibited (e.g. "the run went to X" or "a file was modified" is forbidden). Every finding must explicitly state who acted by naming the specific actor (e.g. "Ida Prime sent the run to Pauli"), followed immediately by quoting the exact instruction, skill, or workflow text that led them to act (e.g. "The instructions provided to Ida in `<file>` state: `[extract]`"). Then state the framework defect in those instructions or tools.
   - Ground findings in observable runtime mechanisms shown in the trace (or session log if the surface does not emit traces): failing tool invocations, unexpected tool error payloads, schema mismatches, hook blocks, timeout spikes.
   - Describe what the session attempted and where execution broke down. The runtime execution record is the evidence; do not inspect source files or name responsible code lines.
   - Treat an agent's account of its causes as hearsay, never as evidence of mechanism. Re-read the case from the primary user words independently of the caller's framing; what each agent received, ran, and chose on the record is the evidence.
   - Address the class of failure rather than proximate mistakes. Focus on mechanisms and contracts rather than speculating on agent psychology or internal states.
3. **Generalise the instance**: when the ask names one instance, take both steps below yourself, even if the instance is already fixed.
   - _General bug_: name the mechanism that produced the instance and will produce more like it.
   - _Verification miss_: search for the existing control (in axioms, rules, skills, and enforcement maps) governing the failure class; determine why that control did not fire or pass, and never assert that no control exists without an exhaustive search.
4. **Determine scope** of each finding:
   - _Project_: Project-specific configuration, workflow templates, or repository guidelines.
   - _User/PKB_: User preferences, habits, or personal knowledge base.
   - _Framework_: Universal axioms, agent roles, or core tooling.
5. **File issues or post evidence-bump comments**:
   - File no issue and post no comment for login or authentication failures.
   - For each finding, search existing issues within the owning repository for the error class before creating a new issue to avoid duplicate reports. Target the remote repository directly by name (`owner/repo`) for both search and issue/comment creation rather than relying on a local checkout.
   - When the evidence belongs to an issue that already exists, summarise that evidence into an evidence-bump comment on that existing issue; do not file a separate issue for the evidence.
   - When no existing issue covers the finding, file in the owning repository:
     - When the primary failure is already well known and has a handler, file one issue for the handler's failure only.
     - When the primary failure is not already handled, file both issues (the general bug and the verification miss).
   - Format every filed issue using the repository's issue template at `.github/ISSUE_TEMPLATE/learn.md`, completing each section with concrete trace data and omitting speculation.
   - Ground the issue description or evidence-bump comment in the execution record (tool calls, error payloads, latencies). Strip personal names, credentials, file paths containing sensitive usernames, raw environment details, session IDs, private telemetry domains, and PKB IDs (`aops_...`, `task_...`, `mem_...`).
6. **No direct fixes**:
   - Diagnose only; do not propose fixes, select enforcement mechanisms, or open tasks to implement remedies. Findings serve as evidence for the framework enforcement loop (`specs/enforcement/enforcement.md`).

## Output

Return a markdown report containing:

- **Evidence**: Session ID / Conversation ID, relevant OTel span IDs (or session log excerpts if the surface does not emit traces), and execution excerpts (tool calls, error payloads, latencies).
- **Root cause**: The framework or workflow defect the execution record shows let the failure happen: the missing, unreached, ambiguous, or contradicted instruction, workflow step, contract, or tool that led the agent to act as it did. State strictly in active voice, name the actor who acted, quote the governing instruction text that led them to act, and explain the framework defect. Never cite an agent, an agent's capability limitation, or an agent's choice as the root cause, and never use passive voice.
- **Verification miss**: The check that should have caught the instance, and why it did not.
- **Impact estimate**: Projected frequency and severity.
- **Artifacts**: Links to the filed issue(s) or evidence-bump comment(s) (evidence-bump comment when an existing issue tracks the failure; otherwise handler's failure only if the primary failure is handled, or both the general bug and verification miss if unhandled).

For login or authentication failures, return to the caller that the failure is a configuration failure (file no issue and post no comment).
