---
alias:
  - wf-fact-check
description: Fills evaluate slot for factual, empirical, and citation-bearing claims against primary sources. Skip for pure judgment or stylistic work.
id: wf-fact-check
tags:
  - wf-template
  - qa
title: wf-fact-check
type: template
---

## What this step does

Checks factual and evidentiary claims in a draft against their sources -- citations resolve, quoted
numbers match the source, described behaviour matches what was actually observed rather than
assumed, links are live and point where claimed. This is narrower and more mechanical than
general QA evaluation: it verifies claims are TRUE, not that the work is GOOD.

## Output contract

The fact-check handback must state, per claim checked:

- The claim, the source checked, and the resolving link/command/output.
- PASS (claim verified against source) or FAIL (claim doesn't hold) -- no third state; a claim that couldn't be checked is a FAIL with the reason recorded ("source unavailable", "couldn't reproduce").
- A summary count: N claims checked, N passed, N failed -- so the evaluating QA step doesn't have to re-derive coverage.

## Record surface (mandatory)

The ledger, the work log, and the reasoning behind them are working records. Their durable home is the PKB, attached to the commissioning task -- never a public or shared artifact repository. The repository under review receives only the completed work itself and, where the surrounding process requires a report (a PR review requirement, an editor sign-off), a summary -- verdict and counts, with a pointer to the task that holds the record -- not the internal ledger or narrative. This applies to every project, not any one repo: a reasoning log committed to a shared repo publishes the team's internal deliberations alongside the work.

## When to include

Any artifact making factual, empirical, or citation-bearing claims: research writing, grant text, anything citing data or prior work, code claiming a behavior ("this fixes X" -- did it?). When in doubt, include it -- it's cheap relative to a wrong claim shipping.
