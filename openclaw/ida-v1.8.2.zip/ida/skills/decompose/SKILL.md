---
name: decompose
type: command
description: Expand one situated objective into an abstract graph of sub-objectives, decision branches, implied prerequisites, and alternate paths, each a node bound to no executor. Use as soon as an objective is on the graph, so other objectives' tasks can intersect with its parts; the PKB custodian (Pauli) runs it. Exclude for direction across the whole graph (use strategize) or writing one node's dispatchable task (use reify).
---

# /decompose -- Expand an objective into an abstract graph

**Object: one objective.** The output is its sub-objectives, forks and probes with their edges: nodes that say what must become true, bound to no executor and no workflow. Objectives and plans are expanded exclusively into abstract graph nodes, never into repository plan files. Decompose early, as soon as the objective is captured, because its sub-objectives are what other objectives' tasks intersect with; a task minted elsewhere can only account for them once they exist. Expand only as far as reliable inference reaches now, and stop at the first unknown. The PKB custodian (Pauli) runs this skill.

State what needs doing, never how. Decompose reads; it runs nothing. What the record cannot settle becomes a probe on the graph.

## Workflow

1. **Reconnaissance**: Read the artefacts and the graph.
   - Search the record or knowledge base using short (5-15 word) conceptual queries distilled from the objective (never the raw or verbatim ask) for how the relevant part of the domain or system already works; list what is settled before naming any unknown. What the record settles is not a node or probe; an unknown the record answers is not a node.
   - A premise is load-bearing when its falsity would change the graph's shape (which nodes exist, which forks are open). Record each one, what settled it, and what it showed.
   - Resolve every pointer between artefacts and graph both ways. One that no longer resolves is a finding.
   - A false load-bearing premise halts the run: record it and stop.
2. **Ground in existing means**:
   - Take the stage skeleton for this class of work from the workflow template library (e.g. `/workflow-library preview`) at stage depth. Its stages are the spine; a stage filled by a choice (method, frame, venue) becomes a fork, never a chosen step.
   - Place the objective against each stage: met, partly met or open, and the node that carries it.
   - **Capabilities.** For each component, name what it needs (tool and operation, service, data, credentials) and settle from the record whether some executor has it. Recorded as working somewhere: ground on it. Recorded as absent or refused everywhere: the component needs a prerequisite node. Not on record: a probe wired via execution prerequisite `needs: [<probe_id>]`, whose finding is written back as a capability record. Which executor runs the component is settled at reification, not here.
3. **Expand within reliable inference**:
   - **Objective altitude**: Nodes are objectives ("clarify X and address gaps if required", "create the workflow for Y"), never mechanisms, choices between mechanisms, or probes of tool flags. Those belong to the worker.
   - Model sub-objectives as far as reliable inference allows per the Three-Purpose Taxonomy ([ADR-0002](../../../../specs/decisions/0002-distinguish-pkb-graph-edge-purposes-and-enforce-parsimony.md)): competing candidate options stay inside the body of the scoping task or ADR until chosen. A task that has options to choose between is created as one task with the candidate choices and evaluation criteria inside its body; when chosen, only the selected option is reified into an actionable task under `parent: <scoping_task_id>`. Separate decision points from their validation nodes.
   - **Stop rule**: When the next step depends on something not yet known, the node ends naming that unknown, and no branches beyond it are modelled.
4. **Resolve unknowns**:
   - **Decide**: Choose the obvious path and record the rationale in one bullet.
   - **Defer**: Mint an empirical probe task (`classification: probe`); dependent nodes wire `needs: [<probe_id>]`.
   - **Surface**: With the author in the session, surface forks in conversation, one per turn. Competing candidate options stay inside the body of the scoping task or ADR until chosen. When chosen, reify only the winning branch under `parent: <scoping_task_id>`. Downstream tasks depend on the reified implementation task via `needs`.
5. **Collapse and merge before minting**: mint only what no existing node can carry.
   - **Collapse to session units**: two components one worker would do in one session against the same material are one node, unless the second must not run in that session (review, verification, merge), one gates on another party, or deciding between them changes the second.
   - **Merge into what exists**: search the graph first (`done` tasks and templates included) using concise conceptual queries distilled from each candidate component rather than querying verbatim prompt text; extend an overlapping node instead of minting a sibling. Overlap with completed work cuts the candidate to what that work left unanswered, with contextual references as markdown `[[wikilinks]]` in `## Pointers`; if nothing is left, do not mint.
   - **A first run is not a step**: the first execution of an existing node belongs to that node.
6. **Wire the graph**: verb-led titles (`Implement X`), no personal names; `parent` for hierarchy, no redundant descendant edges; `needs: [<task_id>]` for prerequisites on waiting tasks; candidate options kept inside task bodies until chosen; contextual references as `[[wikilinks]]` under `## Pointers`; a convergence node where forks rejoin; slugged ids (`<slug>`). Wire edges per the Three-Purpose Taxonomy ([ADR-0002](../../../../specs/decisions/0002-distinguish-pkb-graph-edge-purposes-and-enforce-parsimony.md)).
7. **Write or redraw the plan view**:
   - **Template selection**: Apply the plan-view template named by the user, if specified. Otherwise, discover templates tagged `plan-view` and select the template whose frontmatter marks `default: true`. Do not hardcode template names or identifiers in instructions. Halt loudly if the named template is missing, if no template carries the `plan-view` tag, or if multiple templates carry `default: true`.
   - **Render the plan**: Apply the selected template to write a `## Plan` section on the objective's top-level task containing the stage strip, Mermaid dependency flowchart, workflow template colour legend, and summary table derived from descendant tasks. Display planned process and structural dependencies only; omit task status, assignee, progress, and execution metrics to preserve single source of truth on the tasks.
   - **Idempotent redrawing**: Each run and re-run completely replaces any existing `## Plan` section in place, carrying added detail, forks, and graph modifications from the current tree.

## Output Schema

```
- Expanded [PARENT-ID] into N components, F forks, P probes; C collapsed, M merged
- Premises: <premise> -- held | false | probe TASK-ID; unresolved pointers: <list | none>
- Capabilities: <need> -- recorded on <executor> | absent | probe TASK-ID
- Plan view: written | redrawn on [PARENT-ID] via <template-slug>
- [TASK-ID] - [TITLE] (fork: <branch> | probe for: <fork-id> | -)
- Merged into [EXISTING-ID]: <candidate> (collapsed | overlap | first run)
- Halted on: <unresolved blocker> [if applicable]
```

## Constraints

- Abstract outcomes only; no execution methods, mechanisms, or scripts.
- Bind no node to an executor or a workflow and write no acceptance criteria: a node is reified (`/reify`) when it is next to run, and not before.
- Plan view shows planned process structure only; task status stays exclusively on child tasks.
