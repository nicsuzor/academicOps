# GitHub Advanced Search Strategies

Comprehensive guide to searching GitHub issues effectively to avoid creating duplicates and find related work.

## Core Principle

Search EXHAUSTIVELY before creating new issues. Use multiple search strategies in parallel. Minimum 3 searches required, but more is better.

## Basic gh CLI Commands

```bash
# List all open issues
gh issue list --repo nicsuzor/academicOps

# List all issues (including closed)
gh issue list --repo nicsuzor/academicOps --state all

# Search issues
gh issue list --repo nicsuzor/academicOps --search "query"

# View specific issue
gh issue view NUMBER --repo nicsuzor/academicOps

# List with more details
gh issue list --repo nicsuzor/academicOps --limit 50 --state all
```

## Search Strategy 1: Keyword/Phrase Matching

### Exact Error Messages

When you have an error message, search for distinctive parts:

```bash
# Full error phrase (if short)
gh issue list --repo nicsuzor/academicOps --search "KeyError: ACADEMICOPS_BOT"

# Distinctive portion
gh issue list --repo nicsuzor/academicOps --search "load_instructions.py"

# Error type + component
gh issue list --repo nicsuzor/academicOps --search "KeyError environment"
```

**Tip**: Avoid generic terms like "error" or "failure" alone.

### Component Names

Search by the specific component mentioned:

```bash
# By agent name
gh issue list --repo nicsuzor/academicOps --search "agent-trainer"
gh issue list --repo nicsuzor/academicOps --search "TRAINER.md"

# By script name
gh issue list --repo nicsuzor/academicOps --search "load_instructions.py"
gh issue list --repo nicsuzor/academicOps --search "validate_tool.py"

# By hook type
gh issue list --repo nicsuzor/academicOps --search "SessionStart"
gh issue list --repo nicsuzor/academicOps --search "PreToolUse"

# By skill name
gh issue list --repo nicsuzor/academicOps --search "git-commit skill"
```

### Behavioral Patterns

Search for the underlying pattern, not just the symptom:

```bash
# Pattern categories
gh issue list --repo nicsuzor/academicOps --search "defensive behavior"
gh issue list --repo nicsuzor/academicOps --search "scope creep"
gh issue list --repo nicsuzor/academicOps --search "DRY violation"
gh issue list --repo nicsuzor/academicOps --search "authority violation"

# Axiom violations
gh issue list --repo nicsuzor/academicOps --search "DO ONE THING"
gh issue list --repo nicsuzor/academicOps --search "ANSWER DIRECT QUESTIONS"
gh issue list --repo nicsuzor/academicOps --search "VERIFY FIRST"
gh issue list --repo nicsuzor/academicOps --search "NO EXCUSES"
```

## Search Strategy 2: Label Filtering

### Search by Label

```bash
# By type
gh issue list --repo nicsuzor/academicOps --label "bug"
gh issue list --repo nicsuzor/academicOps --label "enhancement"
gh issue list --repo nicsuzor/academicOps --label "documentation"

# By component
gh issue list --repo nicsuzor/academicOps --label "agent-behavior"
gh issue list --repo nicsuzor/academicOps --label "infrastructure"
gh issue list --repo nicsuzor/academicOps --label "environment"

# By pattern (if labels exist)
gh issue list --repo nicsuzor/academicOps --label "defensive-behavior"
gh issue list --repo nicsuzor/academicOps --label "scope-creep"

# By severity
gh issue list --repo nicsuzor/academicOps --label "critical"
gh issue list --repo nicsuzor/academicOps --label "high"

# Combine labels
gh issue list --repo nicsuzor/academicOps --label "bug,agent-behavior"
```

### Search by State

```bash
# Open only (default)
gh issue list --repo nicsuzor/academicOps --search "DRY violation"

# All (including closed - might have recurred!)
gh issue list --repo nicsuzor/academicOps --search "DRY violation" --state all

# Closed only (to check if was resolved)
gh issue list --repo nicsuzor/academicOps --search "DRY violation" --state closed
```

## Search Strategy 3: Temporal Filtering

### Recent Activity

Sometimes recent issues are more relevant:

```bash
# Last 20 updated issues
gh issue list --repo nicsuzor/academicOps --state all --limit 20

# Recently opened
gh issue list --repo nicsuzor/academicOps --limit 20

# Search within recent
gh issue list --repo nicsuzor/academicOps --search "trainer" --limit 30
```

### Date Ranges (using GitHub search syntax)

```bash
# Created after date
gh issue list --repo nicsuzor/academicOps --search "created:>2025-10-01"

# Updated recently
gh issue list --repo nicsuzor/academicOps --search "updated:>2025-10-15"

# Combine with keyword
gh issue list --repo nicsuzor/academicOps --search "DRY violation updated:>2025-10-01"
```

## Search Strategy 4: Semantic Variations

### Synonym Search

The same concept can be described many ways:

```bash
# For "creates backup files":
gh issue list --repo nicsuzor/academicOps --search "_new file"
gh issue list --repo nicsuzor/academicOps --search "backup copy"
gh issue list --repo nicsuzor/academicOps --search "defensive behavior"
gh issue list --repo nicsuzor/academicOps --search "duplicate file"

# For "doesn't follow instructions":
gh issue list --repo nicsuzor/academicOps --search "violates axiom"
gh issue list --repo nicsuzor/academicOps --search "ignores instructions"
gh issue list --repo nicsuzor/academicOps --search "agent behavior"

# For "path errors":
gh issue list --repo nicsuzor/academicOps --search "path not found"
gh issue list --repo nicsuzor/academicOps --search "file not found"
gh issue list --repo nicsuzor/academicOps --search "missing file"
gh issue list --repo nicsuzor/academicOps --search "FileNotFoundError"
```

### Abstraction Levels

Search both specific and general:

```bash
# Specific
gh issue list --repo nicsuzor/academicOps --search "load_instructions.py line 45"

# General
gh issue list --repo nicsuzor/academicOps --search "load_instructions.py"
gh issue list --repo nicsuzor/academicOps --search "SessionStart hook"
gh issue list --repo nicsuzor/academicOps --search "instruction loading"
```

## Search Strategy 5: Related Components

### Chain Search

Start specific, expand to related areas:

```bash
# 1. Specific error
gh issue list --repo nicsuzor/academicOps --search "trainer fixed code"

# 2. Expand to pattern
gh issue list --repo nicsuzor/academicOps --search "authority violation"

# 3. Expand to component
gh issue list --repo nicsuzor/academicOps --search "trainer agent"

# 4. Check all agent issues
gh issue list --repo nicsuzor/academicOps --label "agent-behavior"
```

### Cross-Component Search

If one component fails, related components might have similar issues:

```bash
# If TRAINER.md has issue, check other agents
gh issue list --repo nicsuzor/academicOps --search "DEVELOPER.md"
gh issue list --repo nicsuzor/academicOps --search "REVIEW.md"

# If SessionStart hook fails, check other hooks
gh issue list --repo nicsuzor/academicOps --search "PreToolUse"
gh issue list --repo nicsuzor/academicOps --search "hooks"
```

## Search Strategy 6: Author and Assignee

### Find Related Work by Same Reporter

If you're tracking your own reports:

```bash
# Issues by author
gh issue list --repo nicsuzor/academicOps --author @me

# Issues assigned to you
gh issue list --repo nicsuzor/academicOps --assignee @me
```

## Advanced GitHub Search Syntax

### Boolean Operators

```bash
# OR (find issues matching either term)
gh issue list --repo nicsuzor/academicOps --search "trainer OR developer"

# AND (both terms must appear - implicit)
gh issue list --repo nicsuzor/academicOps --search "trainer authority violation"

# NOT (exclude term)
gh issue list --repo nicsuzor/academicOps --search "agent NOT trainer"
```

### Qualifiers

```bash
# In title only
gh issue list --repo nicsuzor/academicOps --search "in:title DRY violation"

# In body only
gh issue list --repo nicsuzor/academicOps --search "in:body _CORE.md"

# In comments
gh issue list --repo nicsuzor/academicOps --search "in:comments experiment results"

# Author
gh issue list --repo nicsuzor/academicOps --search "author:nicsuzor"

# Mentions
gh issue list --repo nicsuzor/academicOps --search "mentions:@me"

# Labels in search
gh issue list --repo nicsuzor/academicOps --search "label:bug label:agent-behavior"
```

### Numeric Ranges

```bash
# Issues with many comments (active discussion)
gh issue list --repo nicsuzor/academicOps --search "comments:>5"

# Recently created
gh issue list --repo nicsuzor/academicOps --search "created:>2025-10-15"
```

## Complete Search Workflow Example

### Scenario: Agent created `_new` file instead of editing existing

**Step 1: Exact behavior search**
```bash
gh issue list --repo nicsuzor/academicOps --search "_new file"
```

**Step 2: Pattern search**
```bash
gh issue list --repo nicsuzor/academicOps --search "defensive behavior"
gh issue list --repo nicsuzor/academicOps --search "backup copy"
```

**Step 3: Axiom search**
```bash
gh issue list --repo nicsuzor/academicOps --search "DRY violation"
gh issue list --repo nicsuzor/academicOps --search "trust git"
```

**Step 4: Component search**
```bash
gh issue list --repo nicsuzor/academicOps --search "agent-developer"
gh issue list --repo nicsuzor/academicOps --label "agent-behavior"
```

**Step 5: Synonym search**
```bash
gh issue list --repo nicsuzor/academicOps --search "duplicate file"
gh issue list --repo nicsuzor/academicOps --search "version control"
```

**Step 6: Check recent issues**
```bash
gh issue list --repo nicsuzor/academicOps --state all --limit 30
```

**Step 7: Check closed issues** (might have recurred)
```bash
gh issue list --repo nicsuzor/academicOps --search "defensive behavior" --state closed
```

**Result**: If ANY of these searches returns a match, update that issue. Only create new if ALL searches come up empty.

## Search Result Analysis

### When Reviewing Search Results

For each potential match, check:

1. **Title**: Does it describe the same pattern?
2. **Labels**: Do the labels match (agent-behavior, pattern type)?
3. **Description**: Is the root cause the same?
4. **Examples**: Are the manifestations similar?
5. **Status**: Is it open, closed, or closed as duplicate?

### Deciding: Update vs Create

**Update existing issue if**:
- Same behavioral pattern (even if different manifestation)
- Same root cause (even if different symptom)
- Same component affected
- Issue marked as "recurring" or "systemic"

**Create new issue if**:
- Different root cause (e.g., one is environment error, other is agent behavior)
- Different pattern category
- Existing issue is resolved and this is a NEW problem (not recurrence)
- Completely unrelated despite similar keywords

**When in doubt**: Comment on the existing issue first asking "Is this related?" before creating new.

## Common Search Mistakes

### Mistake 1: Only One Search

❌ Bad:
```bash
gh issue list --repo nicsuzor/academicOps --search "error"
# If nothing found → create issue
```

✅ Good:
```bash
gh issue list --repo nicsuzor/academicOps --search "KeyError load_instructions"
gh issue list --repo nicsuzor/academicOps --search "environment variable"
gh issue list --repo nicsuzor/academicOps --search "SessionStart hook"
gh issue list --repo nicsuzor/academicOps --label "infrastructure"
gh issue list --repo nicsuzor/academicOps --state all --limit 20
# Only create if ALL searches empty
```

### Mistake 2: Too Specific Search

❌ Bad:
```bash
# Searching for exact error message with line numbers
gh issue list --repo nicsuzor/academicOps --search "KeyError ACADEMICOPS_BOT at line 45"
# Might miss same error at different line
```

✅ Good:
```bash
# Search for essence, not specifics
gh issue list --repo nicsuzor/academicOps --search "KeyError ACADEMICOPS_BOT"
gh issue list --repo nicsuzor/academicOps --search "missing environment variable"
```

### Mistake 3: Ignoring Closed Issues

❌ Bad:
```bash
# Only searching open issues
gh issue list --repo nicsuzor/academicOps --search "defensive behavior"
```

✅ Good:
```bash
# Check closed too (problem might have recurred!)
gh issue list --repo nicsuzor/academicOps --search "defensive behavior" --state all
```

### Mistake 4: Surface-Level Matching

❌ Bad thinking: "My issue is about TRAINER.md, existing issue is about DEVELOPER.md, so they're different"

✅ Good thinking: "Both are authority violations (wrong agent doing work). Same pattern, update existing issue with new example."

## Quick Reference Commands

```bash
# Minimum required search (do ALL of these):

# 1. Exact error/behavior
gh issue list --repo nicsuzor/academicOps --search "[specific-term]"

# 2. Pattern category
gh issue list --repo nicsuzor/academicOps --search "[pattern-name]"

# 3. Component
gh issue list --repo nicsuzor/academicOps --search "[component-name]"

# 4. Recent issues (might not be labeled yet)
gh issue list --repo nicsuzor/academicOps --state all --limit 20

# BONUS: Closed issues (check for recurrence)
gh issue list --repo nicsuzor/academicOps --search "[term]" --state closed
```

## Integration with Categorization

Before searching, determine pattern category (see categorization-guide.md), then search for:

1. The pattern category name
2. Related axiom violations
3. Similar symptoms
4. Same component
5. Behavioral keywords

This ensures you find issues with the same ROOT CAUSE even if symptoms differ.
