# Error and Violation Categorization Guide

Comprehensive guide to categorizing academicOps framework errors and agent violations by behavioral patterns and root causes.

## Purpose

Avoid duplicate GitHub issues by recognizing underlying patterns rather than surface symptoms. Multiple manifestations of the same root cause should be tracked in ONE issue with multiple examples.

## Behavioral Pattern Categories

### 1. Defensive Behavior

**Pattern**: Agent creates safety nets instead of trusting infrastructure.

**Root Cause**: Agent doesn't trust version control, rollback mechanisms, or fail-fast philosophy.

**Manifestations**:
- Creating `_new`, `_backup`, `_old` files before editing
- Adding `try/except` blocks that return fallback values
- Building workarounds instead of fixing root problems
- Asking permission before making changes git can revert
- Copying files before modifying them

**Example Issue Title**: "Agent: Defensive behavior - creates backup files instead of trusting git"

**Related Axiom**: #7 (Fail-Fast), #10 (DRY)

---

### 2. Scope Creep

**Pattern**: Agent expands beyond requested task.

**Root Cause**: Agent doesn't follow "DO ONE THING" axiom.

**Manifestations**:
- Fixing problems not requested
- Launching into solutions before answering questions
- Adding extra features during bug fixes
- Refactoring unrelated code
- Continuing work after task completion

**Example Issue Title**: "Agent: Scope creep - fixes unrelated issues without permission"

**Related Axiom**: #1 (DO ONE THING), #2 (ANSWER DIRECT QUESTIONS)

---

### 3. DRY Violations

**Pattern**: Agent duplicates content across files.

**Root Cause**: Doesn't recognize existing authoritative source.

**Manifestations**:
- Repeating core axioms in agent-specific files
- Creating similar functions/scripts instead of reusing
- Copying documentation instead of referencing
- Adding detailed instructions that exist elsewhere
- Creating multiple files for same purpose

**Example Issue Title**: "Agent: DRY violation - duplicates _CORE.md content in DEVELOPER.md"

**Related Axiom**: #10 (DRY, modular, EXPLICIT)

---

### 4. Authority Violations

**Pattern**: Wrong agent does wrong work.

**Root Cause**: Agent boundaries not clear or respected.

**Manifestations**:
- Trainer fixing application code
- Developer committing without code-review
- Analyst modifying framework
- General agent bypassing specialist
- Agent performing tasks outside its responsibility

**Example Issue Title**: "Agent: Authority violation - trainer fixed code instead of instructions"

**Related Axiom**: Agent-specific responsibilities (TRAINER.md, DEVELOPER.md, etc.)

---

### 5. Evidence-Free Claims

**Pattern**: Agent claims success without verification.

**Root Cause**: NO EXCUSES axiom not enforced.

**Manifestations**:
- Marking tasks complete without testing
- Showing old results as current proof
- Rationalizing failures instead of admitting them
- Claiming "it will work" without running it
- Making excuses for why verification didn't happen

**Example Issue Title**: "Agent: NO EXCUSES violation - claimed success without verification"

**Related Axiom**: #13 (VERIFY FIRST), #14 (NO EXCUSES)

---

### 6. Assumption Over Verification

**Pattern**: Agent assumes state instead of checking.

**Root Cause**: VERIFY FIRST not enforced.

**Manifestations**:
- Proceeding without checking file existence
- Assuming configuration is correct
- Not reading actual state before modifying
- Guessing instead of searching
- Using stale information

**Example Issue Title**: "Agent: Assumes file exists without verification"

**Related Axiom**: #13 (VERIFY FIRST)

---

### 7. Instruction Bloat

**Pattern**: Adding lengthy instructions when code/hooks/config would work.

**Root Cause**: Not following enforcement hierarchy (Scripts > Hooks > Config > Instructions).

**Manifestations**:
- Adding 50+ lines to agent instructions
- Explaining procedures agents keep forgetting
- Repeating instructions that aren't followed
- Creating detailed steps instead of automation
- Documenting workarounds instead of fixes

**Example Issue Title**: "Framework: Instruction bloat - added 85 lines agent ignores"

**Related Axiom**: Enforcement hierarchy (trainer skill)

---

### 8. Poor Listening

**Pattern**: Agent doesn't answer direct questions.

**Root Cause**: ANSWER DIRECT QUESTIONS axiom violated.

**Manifestations**:
- Launching into solutions when asked for information
- Ignoring user corrections
- Not addressing the actual question asked
- Providing verbose context instead of specific answer
- Continuing after user says "stop"

**Example Issue Title**: "Agent: Doesn't answer direct questions - launches into solutions"

**Related Axiom**: #2 (ANSWER DIRECT QUESTIONS DIRECTLY), #12 (STOP WHEN INTERRUPTED)

---

## Infrastructure Error Categories

### 1. Environment Errors

**Pattern**: Missing or misconfigured environment.

**Symptoms**:
- `KeyError` for environment variables
- Import failures for dependencies
- Path not found errors
- Permission denied errors
- Wrong Python/tool version

**Example Issue Title**: "Environment: ACADEMICOPS_BOT not set causes SessionStart failure"

---

### 2. Integration Errors

**Pattern**: External tool compatibility issues.

**Symptoms**:
- GitHub CLI authentication failures
- Git command errors
- Claude Code API changes
- uv package manager issues
- pytest incompatibilities

**Example Issue Title**: "Integration: gh CLI version 2.x breaks issue creation"

---

### 3. Hook Failures

**Pattern**: Automated checks crash or produce wrong results.

**Symptoms**:
- Hook script exceptions
- Exit code errors
- Infinite loops in validation
- False positives/negatives
- Hook not triggering when expected

**Example Issue Title**: "Hook: PreToolUse crashes on Write(**/*.md) permission check"

---

### 4. Script Logic Errors

**Pattern**: Automation scripts have bugs.

**Symptoms**:
- Wrong output produced
- Edge cases not handled
- Incorrect file parsing
- Logic errors in validation
- Performance issues

**Example Issue Title**: "Script: load_instructions.py fails on missing personal tier"

---

## Categorization Decision Tree

```
START: New error or violation identified
↓
Q1: Is this agent behavior or infrastructure?

AGENT BEHAVIOR → Q2
INFRASTRUCTURE → Q5

Q2: Which core axiom violated?
├─ DO ONE THING → Scope Creep
├─ ANSWER DIRECT → Poor Listening
├─ VERIFY FIRST → Assumption Over Verification
├─ NO EXCUSES → Evidence-Free Claims
├─ DRY → DRY Violations
└─ Fail-Fast → Defensive Behavior OR Assumption

Q3: Is this wrong agent doing work?
YES → Authority Violation
NO → Q4

Q4: Does this need instructions or automation?
INSTRUCTIONS → Check for Instruction Bloat
AUTOMATION → Propose script/hook/config solution

Q5 (Infrastructure): What failed?
├─ Env vars, paths, deps → Environment Error
├─ External tools → Integration Error
├─ Hooks → Hook Failure
└─ Scripts → Script Logic Error

Q6: Search GitHub for pattern category
FOUND → Update existing issue
NOT FOUND → Create new issue with pattern label
```

## GitHub Search Strategies by Category

### For Defensive Behavior

```bash
gh issue list --repo nicsuzor/academicOps --search "defensive behavior"
gh issue list --repo nicsuzor/academicOps --search "_new file"
gh issue list --repo nicsuzor/academicOps --search "backup copy"
gh issue list --repo nicsuzor/academicOps --search "try except fallback"
```

### For Scope Creep

```bash
gh issue list --repo nicsuzor/academicOps --search "scope creep"
gh issue list --repo nicsuzor/academicOps --search "DO ONE THING"
gh issue list --repo nicsuzor/academicOps --search "extra work"
gh issue list --repo nicsuzor/academicOps --search "unauthorized fix"
```

### For DRY Violations

```bash
gh issue list --repo nicsuzor/academicOps --search "DRY violation"
gh issue list --repo nicsuzor/academicOps --search "duplication"
gh issue list --repo nicsuzor/academicOps --search "repeated content"
gh issue list --repo nicsuzor/academicOps --search "_CORE.md"
```

### For Authority Violations

```bash
gh issue list --repo nicsuzor/academicOps --search "authority violation"
gh issue list --repo nicsuzor/academicOps --search "wrong agent"
gh issue list --repo nicsuzor/academicOps --search "trainer fixed code"
gh issue list --repo nicsuzor/academicOps --search "bypassed code-review"
```

### For Evidence-Free Claims

```bash
gh issue list --repo nicsuzor/academicOps --search "NO EXCUSES"
gh issue list --repo nicsuzor/academicOps --search "claimed success"
gh issue list --repo nicsuzor/academicOps --search "without verification"
gh issue list --repo nicsuzor/academicOps --search "rationalization"
```

## Severity Assessment

### Critical

**Impact**: Framework becomes untrustworthy for research.

**Examples**:
- Supervisor showing fake results
- Agent silently failing and hiding it
- Data corruption risks
- Security/privacy violations

### High

**Impact**: Major workflow disruption or axiom violations.

**Examples**:
- Authority violations (wrong agent working)
- Persistent scope creep
- Framework hooks failing
- Core axiom violations

### Medium

**Impact**: Efficiency loss or inconsistent behavior.

**Examples**:
- Defensive behavior creating extra work
- DRY violations requiring cleanup
- Minor instruction additions
- Edge case bugs

### Low

**Impact**: Cosmetic issues or rare occurrences.

**Examples**:
- First-time mistakes corrected immediately
- Documentation typos
- Suggestions for improvements
- Enhancement requests

## Frequency Tracking

Mark issues with frequency labels:

- `first-occurrence` - Never seen this pattern before
- `recurring` - This pattern has happened 2-3 times
- `systemic` - This pattern happens regularly despite fixes

Systemic patterns indicate need for architectural solution (scripts/hooks/config), not more instructions.

## Issue Linking Strategy

When creating or updating issues, link to:

1. **Related patterns** - Other manifestations of same root cause
2. **Experiments** - Framework changes addressing this
3. **Commits** - Code that triggered or fixed this
4. **Axioms** - Core rules being violated
5. **Components** - Agents, skills, scripts, hooks involved

Use GitHub syntax:
- `#123` - Link to issue
- `nicsuzor/academicOps#123` - Link to issue in academicOps from other repo
- `experiments/2025-10-21_name.md` - Reference experiment log
- `_CORE.md:45` - Reference specific line in file

## Label Strategy

Every issue should have:

**Type label** (one):
- `bug` - Something is broken
- `enhancement` - Feature request
- `documentation` - Docs need updating

**Component label** (one or more):
- `agent-behavior` - Agent violated instructions
- `infrastructure` - Scripts/hooks/config issue
- `environment` - Setup/dependency problem
- `integration` - External tool issue

**Pattern label** (for agent behaviors):
- `defensive-behavior`
- `scope-creep`
- `dry-violation`
- `authority-violation`
- `no-excuses-violation`
- `verify-first-violation`

**Frequency label**:
- `first-occurrence`
- `recurring`
- `systemic`

**Severity label**:
- `critical`
- `high`
- `medium`
- `low`

## Examples of Good Categorization

### Example 1: Multiple Symptoms, One Root Cause

**Three separate reports**:
1. "Agent created backup file before editing"
2. "Agent asked permission before git commit"
3. "Agent added try/except with fallback value"

**Correct categorization**: ONE issue titled "Agent: Defensive behavior - doesn't trust infrastructure"

**Evidence sections**: Three dated examples showing the pattern

---

### Example 2: Similar Symptoms, Different Root Causes

**Two reports**:
1. "Trainer agent fixed code bug"
2. "Developer agent committed without code-review"

**Correct categorization**: TWO issues
- Issue 1: "Trainer: Authority violation - fixed code instead of instructions"
- Issue 2: "Developer: Authority violation - bypassed required code-review agent"

**Why separate**: Different agents, different solutions needed

---

### Example 3: Infrastructure vs Agent Behavior

**Report**: "Agent tried to load ARCHITECTURE.md but path was wrong"

**Analysis**:
- If path was hardcoded incorrectly → Infrastructure error
- If agent assumed path without checking → Agent violation (VERIFY FIRST)

**Categorization depends on root cause, not symptom**

## Quick Reference Checklist

Before creating new issue:

- [ ] Identified behavioral pattern or error category
- [ ] Searched GitHub with 3+ pattern-based queries
- [ ] Checked recently updated issues
- [ ] Checked closed issues for recurrence
- [ ] Determined if this matches existing issue
- [ ] If match found → Update existing issue
- [ ] If no match → Create new with pattern labels
- [ ] Linked to related issues and experiments
- [ ] Assigned appropriate severity
- [ ] Marked frequency (first/recurring/systemic)
