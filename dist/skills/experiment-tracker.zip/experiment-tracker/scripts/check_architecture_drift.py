#!/usr/bin/env python3
"""
Check for drift between ARCHITECTURE.md and actual codebase state.

Compares documented components with actual files to identify missing documentation.

Usage:
    uv run python check_architecture_drift.py [--repo-root PATH]

Examples:
    # Check from current directory
    uv run python check_architecture_drift.py

    # Check specific repository
    uv run python check_architecture_drift.py --repo-root /path/to/academicOps
"""

import argparse
import sys
from pathlib import Path
from typing import Any


class ArchitectureDriftChecker:
    """Check for drift between ARCHITECTURE.md and codebase."""

    def __init__(self, repo_root: Path) -> None:
        """
        Initialize checker.

        Args:
            repo_root: Path to repository root
        """
        self.repo_root = repo_root
        self.architecture_file = repo_root / 'ARCHITECTURE.md'
        self.drift_found = False

    def check_exists(self) -> bool:
        """Check if ARCHITECTURE.md exists."""
        if not self.architecture_file.exists():
            print(f"❌ ARCHITECTURE.md not found at {self.architecture_file}")
            return False
        return True

    def get_actual_components(self) -> dict[str, list[str]]:
        """
        Discover actual components in codebase.

        Returns:
            Dictionary mapping component type to list of component names
        """
        components: dict[str, list[str]] = {
            'agents': [],
            'skills': [],
            'scripts': [],
            'hooks': [],
            'commands': [],
        }

        # Find agents
        agents_dir = self.repo_root / 'agents'
        if agents_dir.exists():
            components['agents'] = [
                f.stem for f in agents_dir.glob('*.md')
                if f.name not in ['README.md', 'EXAMPLE.md']
            ]

        # Find skills
        skills_dir = self.repo_root / '.claude' / 'skills'
        if skills_dir.exists():
            components['skills'] = [
                d.name for d in skills_dir.iterdir()
                if d.is_dir() and (d / 'SKILL.md').exists()
            ]

        # Find scripts
        scripts_dir = self.repo_root / 'scripts'
        if scripts_dir.exists():
            components['scripts'] = [
                f.stem for f in scripts_dir.glob('*.py')
                if not f.name.startswith('_')
            ]

        # Find hooks (from settings.json if exists)
        settings_file = self.repo_root / '.claude' / 'settings.json'
        if settings_file.exists():
            import json
            try:
                settings = json.loads(settings_file.read_text())
                hooks_config = settings.get('hooks', {})
                components['hooks'] = list(hooks_config.keys())
            except (json.JSONDecodeError, KeyError):
                pass

        # Find commands
        commands_dir = self.repo_root / '.claude' / 'commands'
        if commands_dir.exists():
            components['commands'] = [
                f.stem for f in commands_dir.glob('*.md')
            ]

        return components

    def check_documented(self, component_type: str, component_name: str) -> bool:
        """
        Check if component is documented in ARCHITECTURE.md.

        Args:
            component_type: Type of component (agents, skills, etc.)
            component_name: Name of component

        Returns:
            True if documented, False otherwise
        """
        arch_text = self.architecture_file.read_text()

        # Different search patterns for different component types
        search_patterns = {
            'agents': [
                f'@agent-{component_name}',
                f'`{component_name}.md`',
                f'agent-{component_name}',
            ],
            'skills': [
                f'{component_name} skill',
                f'`.claude/skills/{component_name}',
                f'`{component_name}`',
            ],
            'scripts': [
                f'{component_name}.py',
                f'`scripts/{component_name}',
            ],
            'hooks': [
                f'{component_name}',
                f'`{component_name}`',
            ],
            'commands': [
                f'/{component_name}',
                f'`/{component_name}`',
            ],
        }

        patterns = search_patterns.get(component_type, [component_name])

        return any(pattern.lower() in arch_text.lower() for pattern in patterns)

    def report_drift(self) -> None:
        """Generate and print drift report."""
        print("\n🔍 Architecture Drift Report\n")
        print(f"Repository: {self.repo_root}")
        print(f"Architecture file: {self.architecture_file}\n")

        components = self.get_actual_components()

        for component_type, component_list in components.items():
            if not component_list:
                continue

            print(f"\n## {component_type.title()}")
            print("-" * 40)

            undocumented = []
            for component in sorted(component_list):
                is_documented = self.check_documented(component_type, component)

                if is_documented:
                    print(f"✅ {component}")
                else:
                    print(f"❌ {component} - NOT DOCUMENTED")
                    undocumented.append(component)
                    self.drift_found = True

            if undocumented:
                print(f"\n⚠️  {len(undocumented)} undocumented {component_type}: {', '.join(undocumented)}")

    def suggest_updates(self) -> None:
        """Suggest sections to update in ARCHITECTURE.md."""
        if not self.drift_found:
            print("\n✅ No drift detected. ARCHITECTURE.md is current.")
            return

        print("\n\n📝 Suggested Actions")
        print("-" * 40)
        print("\n1. Update ARCHITECTURE.md to include missing components")
        print("2. For each component, document:")
        print("   - Purpose and responsibility")
        print("   - When to use it")
        print("   - Key features or capabilities")
        print("   - Examples (if applicable)")
        print("\n3. Check 'Open Questions' section for resolved items")
        print("4. Move resolved questions to implementation sections")
        print("\n5. Consider creating GitHub issue for major drift:")
        print("\n   gh issue create --repo nicsuzor/academicOps \\")
        print('     --title "docs: ARCHITECTURE.md missing components" \\')
        print('     --label "documentation"')


def main() -> None:
    """CLI entry point."""
    parser = argparse.ArgumentParser(
        description='Check for drift between ARCHITECTURE.md and codebase',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    parser.add_argument(
        '--repo-root',
        type=str,
        default='.',
        help='Path to repository root (default: current directory)'
    )

    args = parser.parse_args()

    repo_root = Path(args.repo_root).resolve()

    if not repo_root.exists():
        print(f"Error: Repository root not found: {repo_root}", file=sys.stderr)
        sys.exit(1)

    checker = ArchitectureDriftChecker(repo_root)

    if not checker.check_exists():
        sys.exit(1)

    checker.report_drift()
    checker.suggest_updates()

    # Exit with error code if drift found
    sys.exit(1 if checker.drift_found else 0)


if __name__ == '__main__':
    main()
