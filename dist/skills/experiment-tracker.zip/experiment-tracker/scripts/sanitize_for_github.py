#!/usr/bin/env python3
"""
Sanitize conversation transcripts and error messages before posting to public GitHub.

Removes sensitive information while preserving framework-relevant details.

Usage:
    uv run python sanitize_for_github.py <input_file> [--output output_file]

    or pipe input:
    echo "Error in /home/nic/client-acme/api_key.py" | uv run python sanitize_for_github.py -

Examples:
    # Sanitize a conversation log
    uv run python sanitize_for_github.py conversation.txt --output sanitized.md

    # Sanitize from stdin
    cat error_log.txt | uv run python sanitize_for_github.py - > sanitized.md
"""

import argparse
import re
import sys
from pathlib import Path
from typing import Pattern


class Sanitizer:
    """Sanitize text for public GitHub posting."""

    def __init__(self) -> None:
        """Initialize sanitization patterns."""
        # Patterns for sensitive data
        self.patterns: list[tuple[Pattern[str], str]] = [
            # API keys and tokens
            (re.compile(r'sk_live_[a-zA-Z0-9]+'), '[API-KEY-REDACTED]'),
            (re.compile(r'sk_test_[a-zA-Z0-9]+'), '[API-KEY-REDACTED]'),
            (re.compile(r'Bearer [a-zA-Z0-9_\-\.]+'), 'Bearer [TOKEN-REDACTED]'),
            (re.compile(r'token["\s:=]+[a-zA-Z0-9_\-\.]{20,}', re.IGNORECASE), 'token: [TOKEN-REDACTED]'),

            # Connection strings
            (re.compile(r'postgresql://[^@]+@[^\s]+'), 'postgresql://[REDACTED]@[REDACTED]'),
            (re.compile(r'mysql://[^@]+@[^\s]+'), 'mysql://[REDACTED]@[REDACTED]'),
            (re.compile(r'mongodb://[^@]+@[^\s]+'), 'mongodb://[REDACTED]@[REDACTED]'),

            # Passwords
            (re.compile(r'password["\s:=]+[^\s,\]}"]+', re.IGNORECASE), 'password: [REDACTED]'),
            (re.compile(r'passwd["\s:=]+[^\s,\]}"]+', re.IGNORECASE), 'passwd: [REDACTED]'),

            # AWS credentials
            (re.compile(r'AKIA[0-9A-Z]{16}'), '[AWS-ACCESS-KEY-REDACTED]'),
            (re.compile(r'aws_secret_access_key["\s:=]+[^\s,\]}"]+', re.IGNORECASE),
             'aws_secret_access_key: [REDACTED]'),

            # Email addresses (except anthropic.com, github.com for attribution)
            (re.compile(r'\b(?!noreply@anthropic\.com)(?!.*@github\.com)[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'),
             '[EMAIL-REDACTED]'),
        ]

        # Path patterns - preserve structure but generalize
        self.path_patterns: list[tuple[Pattern[str], str]] = [
            # User home directories
            (re.compile(r'/home/[^/\s]+'), '/home/[user]'),
            (re.compile(r'/Users/[^/\s]+'), '/Users/[user]'),
            (re.compile(r'C:\\Users\\[^\\s]+'), 'C:\\Users\\[user]'),

            # Common sensitive directory patterns (keep if they're academicOps or bot)
            (re.compile(r'/home/[^/\s]+/(?!academicOps|bot)([^/\s]+)'),
             '/home/[user]/[project]'),
        ]

    def sanitize(self, text: str) -> str:
        """
        Sanitize text by removing/replacing sensitive information.

        Args:
            text: Raw text that may contain sensitive data

        Returns:
            Sanitized text safe for public posting
        """
        result = text

        # Apply credential/token patterns
        for pattern, replacement in self.patterns:
            result = pattern.sub(replacement, result)

        # Apply path patterns
        for pattern, replacement in self.path_patterns:
            result = pattern.sub(replacement, result)

        return result

    def sanitize_file(self, input_path: Path, output_path: Path | None = None) -> str:
        """
        Sanitize a file.

        Args:
            input_path: Path to input file
            output_path: Path to output file (if None, returns sanitized text)

        Returns:
            Sanitized text
        """
        if input_path == Path('-'):
            # Read from stdin
            text = sys.stdin.read()
        else:
            text = input_path.read_text()

        sanitized = self.sanitize(text)

        if output_path:
            output_path.write_text(sanitized)

        return sanitized


def main() -> None:
    """CLI entry point."""
    parser = argparse.ArgumentParser(
        description='Sanitize text for public GitHub posting',
        epilog=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    parser.add_argument(
        'input',
        type=str,
        help='Input file path (use "-" for stdin)'
    )
    parser.add_argument(
        '-o', '--output',
        type=str,
        help='Output file path (if not specified, prints to stdout)'
    )

    args = parser.parse_args()

    input_path = Path(args.input)
    output_path = Path(args.output) if args.output else None

    sanitizer = Sanitizer()

    try:
        sanitized = sanitizer.sanitize_file(input_path, output_path)

        if not output_path:
            # Print to stdout if no output file specified
            print(sanitized)
        else:
            print(f"Sanitized content written to: {output_path}", file=sys.stderr)

    except FileNotFoundError:
        print(f"Error: File not found: {input_path}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
