# CLAUDE.md

@bots/prompts/PROJECT_overview.md
@$ACADEMICOPS_BOT/bots/prompts/python_standards.md
@$ACADEMICOPS_PERSONAL/prompts/my_workflow.md
