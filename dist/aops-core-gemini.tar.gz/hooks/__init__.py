# Hook modules for Claude Code integration
