# Gemini CLI Configuration for AcademicOps

This project uses the `academic-ops-core` extension to manage hooks, skills, and MCP servers.
