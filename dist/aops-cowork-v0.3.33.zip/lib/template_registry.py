"""Template Registry: Centralized management of gate message templates.

Provides a unified system for:
- Template specification with required/optional variables
- Rendering with placeholder validation
- Category-based filtering (user messages, context injection, subagent instructions)
- Environment variable overrides for template paths

Usage:
    from lib.template_registry import TemplateRegistry

    registry = TemplateRegistry.instance()
    content = registry.render("enforcer.policy_message", {})

Exit behavior: Functions raise exceptions (fail-fast P#8). Callers handle graceful degradation.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any, ClassVar

from lib.template_loader import load_template


class TemplateCategory(Enum):
    """Distinguishes template purpose."""

    USER_MESSAGE = "user_message"  # Short, actionable, shown to user
    CONTEXT_INJECTION = "context_injection"  # Injected into agent context
    SUBAGENT_INSTRUCTION = "subagent_instruction"  # Rich context for subagents


@dataclass(frozen=True)
class TemplateSpec:
    """Specification for a gate template.

    Attributes:
        name: Unique identifier, e.g., "enforcer.policy_message"
        category: What kind of template (user message, context, subagent)
        filename: Template file name, e.g., "enforcer-policy-message.md"
        required_vars: Variables that MUST be provided to render
        optional_vars: Variables that MAY be provided (default to empty string)
        description: Human-readable purpose
        env_override: Env var name to override template path
    """

    name: str
    category: TemplateCategory
    filename: str
    required_vars: tuple[str, ...] = ()
    optional_vars: tuple[str, ...] = ()
    description: str = ""
    env_override: str | None = None


@dataclass
class RenderedTemplate:
    """Result of rendering a template with metadata."""

    content: str
    spec: TemplateSpec
    variables_used: dict[str, Any]


# =============================================================================
# TEMPLATE SPECIFICATIONS
# =============================================================================
# All gate templates defined here. This is the single source of truth.

TEMPLATE_SPECS: dict[str, TemplateSpec] = {
    "hydration.warn": TemplateSpec(
        name="hydration.warn",
        category=TemplateCategory.USER_MESSAGE,
        filename="hydration-gate-warn.md",
        required_vars=(),
        optional_vars=("session_id", "client_type"),
        description="Lightweight skills-routing hint (formerly hydration warning)",
        env_override="HYDRATION_WARN_TEMPLATE",
    ),
    "pkb.nudge": TemplateSpec(
        name="pkb.nudge",
        category=TemplateCategory.CONTEXT_INJECTION,
        filename="pkb-nudge.md",
        required_vars=(),
        optional_vars=(),
        description="Static UPS nudge to search the PKB before relying on memory (T0)",
        env_override="PKB_NUDGE_TEMPLATE",
    ),
    # --- Enforcer gate ---
    "enforcer.context": TemplateSpec(
        name="enforcer.context",
        category=TemplateCategory.SUBAGENT_INSTRUCTION,
        filename="enforcer-context.md",
        required_vars=(
            "session_context",
            "tool_name",
        ),
        optional_vars=("session_id", "gate_name", "active_skill", "skill_scope"),
        description="Full context for enforcer compliance check",
        env_override="ENFORCER_CONTEXT_TEMPLATE",
    ),
    "qa.context": TemplateSpec(
        name="qa.context",
        category=TemplateCategory.SUBAGENT_INSTRUCTION,
        filename="qa-context.md",
        required_vars=(
            "session_context",
            "tool_name",
        ),
        optional_vars=("session_id", "gate_name"),
        description="Session context for QA verification before exit",
    ),
    "enforcer.verified": TemplateSpec(
        name="enforcer.verified",
        category=TemplateCategory.USER_MESSAGE,
        filename="enforcer-verified.md",
        required_vars=(),
        description="Status message when enforcer compliance check passes",
    ),
    "enforcer.policy_message": TemplateSpec(
        name="enforcer.policy_message",
        category=TemplateCategory.USER_MESSAGE,
        filename="enforcer-policy-message.md",
        required_vars=(),
        optional_vars=("ops_since_open",),
        description="Short message when enforcer gate blocks a tool call",
    ),
    "enforcer.policy_context": TemplateSpec(
        name="enforcer.policy_context",
        category=TemplateCategory.CONTEXT_INJECTION,
        filename="enforcer-policy-context.md",
        required_vars=("temp_path",),
        optional_vars=("ops_since_open",),
        description="Full context injection when enforcer gate blocks",
        env_override="ENFORCER_POLICY_CONTEXT_TEMPLATE",
    ),
    "enforcer.countdown": TemplateSpec(
        name="enforcer.countdown",
        category=TemplateCategory.USER_MESSAGE,
        filename="enforcer-countdown.md",
        required_vars=("remaining", "temp_path"),
        optional_vars=("threshold", "current", "gate_name"),
        description="Countdown warning before enforcer threshold",
    ),
    "enforcer.instruction": TemplateSpec(
        name="enforcer.instruction",
        category=TemplateCategory.CONTEXT_INJECTION,
        filename="enforcer-instruction.md",
        required_vars=("temp_path",),
        description="Instruction to invoke enforcer agent",
        env_override="ENFORCER_INSTRUCTION_TEMPLATE",
    ),
    "enforcer.audit": TemplateSpec(
        name="enforcer.audit",
        category=TemplateCategory.SUBAGENT_INSTRUCTION,
        filename="enforcer-audit.md",
        required_vars=("session_id", "gate_name", "tool_name"),
        description="Audit context for enforcer gate",
    ),
    # --- QA gate: trigger and policy messages ---
    "qa.complete": TemplateSpec(
        name="qa.complete",
        category=TemplateCategory.USER_MESSAGE,
        filename="qa-complete.md",
        required_vars=(),
        description="Status message when QA verification completes",
    ),
    "qa.policy_message": TemplateSpec(
        name="qa.policy_message",
        category=TemplateCategory.USER_MESSAGE,
        filename="qa-policy-message.md",
        required_vars=(),
        description="Short message when QA gate blocks exit",
    ),
    "qa.policy_context": TemplateSpec(
        name="qa.policy_context",
        category=TemplateCategory.CONTEXT_INJECTION,
        filename="qa-policy-context.md",
        required_vars=("temp_path",),
        description="Full context injection when QA gate blocks exit",
    ),
    # --- Handover gate: trigger and policy messages ---
    "handover.bound": TemplateSpec(
        name="handover.bound",
        category=TemplateCategory.USER_MESSAGE,
        filename="handover-bound.md",
        required_vars=(),
        description="Status message when task is bound and handover required",
    ),
    "handover.complete": TemplateSpec(
        name="handover.complete",
        category=TemplateCategory.USER_MESSAGE,
        filename="handover-complete.md",
        required_vars=(),
        description="Status message when end_session / handover / dump skill completes",
    ),
    "handover.policy_message": TemplateSpec(
        name="handover.policy_message",
        category=TemplateCategory.USER_MESSAGE,
        filename="handover-policy-message.md",
        required_vars=(),
        description="Short message when handover gate blocks exit",
    ),
    # --- Stop gate ---
    "stop.handover_block": TemplateSpec(
        name="stop.handover_block",
        category=TemplateCategory.CONTEXT_INJECTION,
        filename="stop-gate-handover-block.md",
        required_vars=(),
        description="Block message requiring handover before stop",
        env_override="STOP_GATE_HANDOVER_TEMPLATE",
    ),
    # --- Sentinel gate: destructive-env-op protection ---
    "sentinel.policy_message": TemplateSpec(
        name="sentinel.policy_message",
        category=TemplateCategory.USER_MESSAGE,
        filename="sentinel-policy-message.md",
        required_vars=(),
        description="Short message when sentinel gate blocks a destructive env op",
    ),
    "sentinel.policy_context": TemplateSpec(
        name="sentinel.policy_context",
        category=TemplateCategory.CONTEXT_INJECTION,
        filename="sentinel-policy-context.md",
        required_vars=(),
        description="Context injection when sentinel gate blocks a destructive env op",
        env_override="SENTINEL_POLICY_CONTEXT_TEMPLATE",
    ),
    # --- Ida (Ida B. Wells — proof-of-claim reminder) gate ---
    "ida.reminder": TemplateSpec(
        name="ida.reminder",
        category=TemplateCategory.CONTEXT_INJECTION,
        filename="ida-reminder.md",
        required_vars=(),
        description="Agent-facing honesty check injected into context on Stop",
    ),
    "ida.policy_message": TemplateSpec(
        name="ida.policy_message",
        category=TemplateCategory.USER_MESSAGE,
        filename="ida-policy-message.md",
        required_vars=(),
        description="Short user-facing message when Ida gate fires on Stop",
    ),
}


# =============================================================================
# TEMPLATE REGISTRY
# =============================================================================


class TemplateRegistry:
    """Central registry for gate templates.

    Singleton pattern - use instance() to get the shared instance.
    Use reset() or configure() for test isolation.
    """

    _instance: ClassVar[TemplateRegistry | None] = None

    def __init__(self) -> None:
        """Initialize registry with default templates directory."""
        self._specs: dict[str, TemplateSpec] = TEMPLATE_SPECS.copy()
        self._templates_dir: Path = Path(__file__).parent.parent / "hooks" / "templates"

    @classmethod
    def instance(cls) -> TemplateRegistry:
        """Get the singleton instance."""
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    @classmethod
    def reset(cls) -> None:
        """Reset singleton for test isolation. Call in test teardown."""
        cls._instance = None

    @classmethod
    def configure(cls, templates_dir: Path | None = None) -> TemplateRegistry:
        """Reset and reconfigure registry. Returns new instance.

        Use in tests to inject custom templates_dir.

        Args:
            templates_dir: Custom templates directory path

        Returns:
            New TemplateRegistry instance
        """
        cls.reset()
        instance = cls()
        if templates_dir:
            instance._templates_dir = templates_dir
        cls._instance = instance
        return instance

    def get_spec(self, name: str) -> TemplateSpec:
        """Get template specification by name.

        Args:
            name: Template name (e.g., "hydration.block")

        Returns:
            TemplateSpec for the template

        Raises:
            KeyError: Template not found
        """
        if name not in self._specs:
            raise KeyError(f"Template not found: {name}")
        return self._specs[name]

    def list_templates(self, category: TemplateCategory | None = None) -> list[str]:
        """List all template names, optionally filtered by category.

        Args:
            category: Optional category filter

        Returns:
            List of template names
        """
        if category is None:
            return list(self._specs.keys())
        return [name for name, spec in self._specs.items() if spec.category == category]

    def render(self, name: str, variables: dict[str, Any] | None = None) -> str:
        """Render a template by name with variables.

        Args:
            name: Template name (e.g., "hydration.block")
            variables: Variables to interpolate

        Returns:
            Rendered template content as string

        Raises:
            KeyError: Template not found
            ValueError: Required variable missing
            FileNotFoundError: Template file not found
        """
        return self.render_with_metadata(name, variables).content

    def render_with_metadata(
        self, name: str, variables: dict[str, Any] | None = None
    ) -> RenderedTemplate:
        """Render a template with full metadata.

        Args:
            name: Template name (e.g., "hydration.block")
            variables: Variables to interpolate

        Returns:
            RenderedTemplate with content, spec, and variables used

        Raises:
            KeyError: Template not found
            ValueError: Required variable missing
            FileNotFoundError: Template file not found
        """
        spec = self.get_spec(name)
        variables = variables or {}

        # Validate required variables
        missing = [var for var in spec.required_vars if var not in variables]
        if missing:
            raise ValueError(f"Template '{name}' missing required variables: {', '.join(missing)}")

        # Build complete variables dict with optional defaults
        complete_vars = dict(variables)
        for var in spec.optional_vars:
            if var not in complete_vars:
                complete_vars[var] = ""

        # Resolve template path (with env override support)
        template_path = self._resolve_template_path(spec)

        # Load and render
        content = load_template(template_path, complete_vars)

        return RenderedTemplate(
            content=content,
            spec=spec,
            variables_used=variables,
        )

    def _resolve_template_path(self, spec: TemplateSpec) -> Path:
        """Resolve actual template path, checking env override.

        Priority:
        1. Environment variable (if set and file exists)
        2. Default path in templates_dir

        Args:
            spec: Template specification

        Returns:
            Path to template file

        Raises:
            FileNotFoundError: If resolved path doesn't exist (fail-fast P#8)
        """
        if spec.env_override:
            override = os.environ.get(spec.env_override)
            if override:
                # Env var can be absolute or relative to templates_dir
                path = Path(override)
                if not path.is_absolute():
                    path = self._templates_dir / path
                if not path.exists():
                    raise FileNotFoundError(
                        f"Template override {spec.env_override}={override} points to "
                        f"non-existent file: {path}"
                    )
                return path

        # Default path
        default = self._templates_dir / spec.filename
        if not default.exists():
            raise FileNotFoundError(f"Template not found: {default}")
        return default
