#!/usr/bin/env -S uv run python
"""
Path resolution for aOps framework (plugin-centric).

Resolves paths relative to this file's location in the aops-core plugin.
Dependency on $AOPS environment variable has been removed.

Required environment variables:
- $ACA_DATA: User data directory (still required for user data)
"""

from __future__ import annotations

import json
import logging
import os
import shutil
from functools import lru_cache
from pathlib import Path

logger = logging.getLogger(__name__)


def get_plugin_root() -> Path:
    """
    Get the root directory of the aops-core plugin.

    Resolution strategy:
    - This file is in <root>/lib/paths.py
    - Root is 2 levels up from this file

    Returns:
        Path: Absolute path to aops-core plugin root
    """
    # this file is at .../aops-core/lib/paths.py
    return Path(__file__).resolve().parent.parent


def get_aops_root() -> Path:
    """
    Get the AOPS root directory (alias for plugin root).

    In plugin-only architecture, this is always the plugin root.
    The $AOPS environment variable is no longer used.
    """
    return get_plugin_root()


def get_bots_dir() -> Path:
    """Alias for get_aops_root."""
    return get_aops_root()


def get_data_root() -> Path:
    """
    Get shared memory vault root.

    Returns:
        Path: Absolute path to data directory ($ACA_DATA)

    Raises:
        RuntimeError: If ACA_DATA environment variable not set or path doesn't exist
    """
    data = os.environ.get("ACA_DATA")
    if not data:
        raise RuntimeError(
            "ACA_DATA environment variable not set.\n"
            "Add to ~/.bashrc or ~/.zshrc:\n"
            "  export ACA_DATA='$HOME/writing/data'"
        )

    path = Path(data).resolve()
    if not path.exists():
        raise RuntimeError(f"ACA_DATA path doesn't exist: {path}")

    return path


def get_local_cache_root() -> Path:
    """Get the local cache root — the SINGLE source of truth, shared with
    ``polecat/manager.py:get_polecat_home`` (both delegate here, A16).

    Resolution, with NO default and NO guess (A14):
    1. ``$POLECAT_HOME`` — the container transport (host injects the resolved
       value) and the host's own export. Wins when present.
    2. Otherwise the host config SSoT: ``polecat_home:`` in polecat.yaml via
       ``lib.polecat_config.resolve_polecat_home``.

    If neither is available this raises — there is no ``~/.polecat`` fallback.
    In-container this never fails: the host always injects ``$POLECAT_HOME``.
    """
    polecat_home = os.environ.get("POLECAT_HOME")
    if polecat_home:
        return Path(polecat_home).resolve()
    # Host without an exported POLECAT_HOME: resolve from the config SSoT.
    from lib.polecat_config import resolve_polecat_home

    return resolve_polecat_home().resolve()


def get_sessions_repo() -> Path:
    """Get sessions repository root.

    Uses $AOPS_SESSIONS if set, otherwise defaults to $POLECAT_HOME/sessions.
    Creates the directory if it doesn't exist.

    Returns:
        Path: Absolute path to sessions repo
    """
    sessions = os.environ.get("AOPS_SESSIONS")
    if sessions:
        path = Path(sessions).resolve()
    else:
        path = get_local_cache_root() / "sessions"

    path.mkdir(parents=True, exist_ok=True)
    return path


# Framework component directories
# All resolved relative to get_plugin_root()


def get_skills_dir() -> Path:
    """Get skills directory (plugin_root/skills)."""
    return get_plugin_root() / "skills"


def get_hooks_dir() -> Path:
    """Get hooks directory (plugin_root/hooks)."""
    return get_plugin_root() / "hooks"


def get_commands_dir() -> Path:
    """Get commands directory (plugin_root/commands)."""
    return get_plugin_root() / "commands"


def get_tests_dir() -> Path:
    """Get tests directory (plugin_root/tests)."""
    return get_plugin_root() / "tests"


def get_config_dir() -> Path:
    """Get config directory (plugin_root/config)."""
    return get_plugin_root() / "config"


def get_workflows_dir() -> Path:
    """Get workflows directory (inside aops skill).

    Returns the aops-core/skills/aops/workflows/ path.
    Raises FileNotFoundError if the directory does not exist.
    """
    workflows = get_plugin_root() / "skills" / "aops" / "workflows"
    if not workflows.exists():
        raise FileNotFoundError(f"Framework workflows directory not found at {workflows}")
    return workflows


def get_indices_dir() -> Path:
    """Get indices directory (plugin_root/indices)."""
    return get_plugin_root() / "indices"


def get_claude_rpm_manifest() -> dict[str, str]:
    """Read the Claude Code RPM manifest to resolve plugin names to IDs.

    Returns:
        dict: Mapping of plugin names to their current installed IDs.
    """
    manifest_path = Path.home() / ".claude" / "rpm" / "manifest.json"
    if not manifest_path.exists():
        return {}
    try:
        data = json.loads(manifest_path.read_text())
        return data.get("plugins", {})
    except (json.JSONDecodeError, OSError):
        return {}


def resolve_plugin_path(plugin_name: str) -> Path | None:
    """Resolve a plugin's installation path by name.

    1. Checks if we are in a dev environment (relative to this plugin)
    2. Reads rpm/manifest.json to find installed plugin ID

    Args:
        plugin_name: Name of the plugin (e.g., 'aops-tools')

    Returns:
        Path: Absolute path to the plugin root, or None if not found.
    """
    # 1. Check for dev sibling (common in dev workspaces)
    # this file is at <root>/lib/paths.py, so get_plugin_root().parent is the workspace root
    dev_path = get_plugin_root().parent / plugin_name
    if dev_path.exists():
        return dev_path

    # 2. Resolve via Claude RPM manifest
    manifest = get_claude_rpm_manifest()
    # Handle both short name 'aops-tools' and full name 'aops-tools@academicOps'
    plugin_id = manifest.get(plugin_name) or manifest.get(f"{plugin_name}@academicOps")

    if plugin_id:
        install_path = Path.home() / ".claude" / "rpm" / "plugins" / plugin_id
        if install_path.exists():
            return install_path

    return None


def get_heuristics_file() -> Path:
    """Get path to HEURISTICS.md framework file."""
    return get_plugin_root() / "HEURISTICS.md"


def get_skills_file() -> Path:
    """Get path to SKILLS.md framework file."""
    return get_plugin_root() / "SKILLS.md"


def get_tools_file() -> Path:
    """Get path to TOOLS.md framework file."""
    return get_plugin_root() / "TOOLS.md"


# Data directories


def get_sessions_dir() -> Path:
    """Get sessions directory (root of sessions repo).

    Alias for get_sessions_repo() for backward compatibility.
    """
    return get_sessions_repo()


def get_transcripts_dir() -> Path:
    """Get transcripts directory ($AOPS_SESSIONS/transcripts)."""
    return get_sessions_repo() / "transcripts"


def get_subagent_transcripts_dir() -> Path:
    """Get subagent transcripts directory ($AOPS_SESSIONS/subagent-transcripts).

    Subagent (Task tool) invocations get their own transcripts in a directory
    sibling to ``transcripts/`` so they don't pollute primary session listings
    and can be queried independently (e.g. by ``/retro`` or trend analysis).

    Both ``transcripts/`` and ``subagent-transcripts/`` follow the same
    ``YYYY-MM/`` rotation (see ``lib.transcript_paths``). See PKB task
    ``task-b483e037``.
    """
    return get_sessions_repo() / "subagent-transcripts"


def get_subagent_summaries_dir() -> Path:
    """Get subagent insights directory ($AOPS_SESSIONS/subagent-summaries).

    Insights JSON for subagent invocations lives parallel to ``summaries/`` so
    consumers that walk ``summaries/`` aggregate-only see parent sessions, and
    per-subagent quality metrics (verdicts, token usage) are queryable
    independently. See PKB task ``task-b483e037``.
    """
    return get_sessions_repo() / "subagent-summaries"


def get_polecat_transcripts_dir() -> Path:
    """Get polecat transcripts directory for writing new transcripts.

    Always returns $POLECAT_HOME/polecats/ — worker session data lives outside
    the sessions git repo to avoid polluting the tracked working tree.

    Use find_polecat_transcript() for reading, which checks legacy locations.
    """
    cache = get_local_cache_root()
    return cache / "polecats"


def find_polecat_transcript(task_id: str) -> Path:
    """Find a polecat transcript file, checking current and legacy locations.

    Checks in order:
    1. $POLECAT_HOME/polecats/<task_id>.jsonl
    2. $AOPS_SESSIONS/polecats/<task_id>.jsonl (legacy)
    3. $AOPS_SESSIONS/transcripts/polecats/<task_id>.jsonl (legacy)

    Returns the first existing path, or the primary path if none exist.
    """
    filename = f"{task_id}.jsonl"
    primary = get_polecat_transcripts_dir() / filename
    if primary.exists():
        return primary

    sessions = get_sessions_repo()
    for legacy_dir in (sessions / "polecats", sessions / "transcripts" / "polecats"):
        legacy = legacy_dir / filename
        if legacy.exists():
            return legacy

    return primary


def get_summaries_dir() -> Path:
    """Get summaries directory ($AOPS_SESSIONS/summaries)."""
    return get_sessions_repo() / "summaries"


def get_projects_dir() -> Path:
    """Get projects directory ($ACA_DATA/projects)."""
    return get_data_root() / "projects"


def get_logs_dir() -> Path:
    """Get logs directory ($ACA_DATA/logs)."""
    return get_data_root() / "logs"


def get_context_dir() -> Path:
    """Get context directory ($ACA_DATA/context)."""
    return get_data_root() / "context"


def get_goals_dir() -> Path:
    """Get goals directory ($ACA_DATA/goals)."""
    return get_data_root() / "goals"


def get_daily_dir() -> Path:
    """Get daily notes directory ($ACA_DATA/daily or $ACA_DATA/brain/daily)."""
    root = get_data_root()
    # Check for brain/ subdirectory which is common in some setups
    brain_daily = root / "brain" / "daily"
    if brain_daily.exists():
        return brain_daily
    return root / "daily"


# Validation utilities


def validate_environment() -> dict[str, Path]:
    """
    Validate that required environment variables are set and paths exist.

    Returns:
        dict: Dictionary mapping names to resolved paths
    """
    return {
        "PLUGIN_ROOT": get_plugin_root(),
        "ACA_DATA": get_data_root(),
        "AOPS_SESSIONS": get_sessions_repo(),
    }


def print_environment() -> None:
    """Print current environment configuration."""
    try:
        env = validate_environment()
        print("aOps Environment Configuration:")
        print(f"  PLUGIN_ROOT:   {env['PLUGIN_ROOT']}")
        print(f"  ACA_DATA:      {env['ACA_DATA']}")
        print(f"  AOPS_SESSIONS: {env['AOPS_SESSIONS']}")
        print("\nFramework directories:")
        print(f"  Skills:      {get_skills_dir()}")
        print(f"  Hooks:       {get_hooks_dir()}")
        print(f"  Commands:    {get_commands_dir()}")
        print(f"  Tests:       {get_tests_dir()}")
        print(f"  Workflows:   {get_workflows_dir()}")
        print(f"  Indices:     {get_indices_dir()}")
        print("\nData directories:")
        print(f"  Sessions:    {get_sessions_repo()}")
        print(f"  Transcripts: {get_transcripts_dir()}")
        print(f"  Summaries:   {get_summaries_dir()}")
        print(f"  Projects:    {get_projects_dir()}")
        print(f"  Logs:        {get_logs_dir()}")
    except RuntimeError as e:
        print(f"Environment validation failed: {e}")
        raise


# External binary resolution


@lru_cache(maxsize=8)
def resolve_binary(name: str) -> Path | None:
    """
    Resolve an external binary to its absolute path with caching.

    Uses shutil.which() to find the binary in PATH, then validates it exists
    and is executable. Results are cached to avoid repeated lookups.

    Args:
        name: Binary name to resolve (e.g., 'bd', 'git')

    Returns:
        Path: Absolute path to the binary if found and executable
        None: If binary not found or not executable

    Note:
        Logs a warning at DEBUG level if binary not found.
        This function intentionally returns None rather than raising
        to support graceful degradation for optional dependencies.
    """
    binary_path = shutil.which(name)
    if binary_path is None:
        logger.debug(f"Binary '{name}' not found in PATH")
        return None

    resolved = Path(binary_path).resolve()
    if not resolved.is_file():
        logger.debug(f"Binary '{name}' resolved to non-file: {resolved}")
        return None

    if not os.access(resolved, os.X_OK):
        logger.debug(f"Binary '{name}' not executable: {resolved}")
        return None

    logger.debug(f"Binary '{name}' resolved to: {resolved}")
    return resolved


def get_ntfy_config() -> dict[str, str | bool | int] | None:
    """
    Get ntfy notification configuration from environment variables.

    Configuration is entirely through environment variables (fail-fast pattern).
    If NTFY_TOPIC is not set, returns None (notifications disabled).

    Required env vars (all must be set if notifications are desired):
    - NTFY_TOPIC: The ntfy topic to publish to (e.g., "aops-alerts")
    - NTFY_SERVER: Server URL (e.g., "https://ntfy.sh")
    - NTFY_PRIORITY: Priority 1-5 (e.g., "3")
    - NTFY_TAGS: Comma-separated tags (e.g., "robot,aops")

    Returns:
        dict with config if NTFY_TOPIC is set, None if not set

    Raises:
        RuntimeError: If NTFY_TOPIC is set but other required vars are missing
    """
    topic = os.environ.get("NTFY_TOPIC")
    if not topic:
        # Notifications disabled - this is the opt-in check
        return None

    # Once opted in via NTFY_TOPIC, all other config is required (fail-fast)
    server = os.environ.get("NTFY_SERVER")
    if not server:
        raise RuntimeError(
            "NTFY_TOPIC is set but NTFY_SERVER is missing.\n"
            "Add to environment:\n"
            "  export NTFY_SERVER='https://ntfy.sh'"
        )

    priority_str = os.environ.get("NTFY_PRIORITY")
    if not priority_str:
        raise RuntimeError(
            "NTFY_TOPIC is set but NTFY_PRIORITY is missing.\n"
            "Add to environment:\n"
            "  export NTFY_PRIORITY='3'"
        )

    tags = os.environ.get("NTFY_TAGS")
    if not tags:
        raise RuntimeError(
            "NTFY_TOPIC is set but NTFY_TAGS is missing.\n"
            "Add to environment:\n"
            "  export NTFY_TAGS='robot,aops'"
        )

    return {
        "enabled": True,
        "topic": topic,
        "server": server,
        "priority": int(priority_str),
        "tags": tags,
    }


if __name__ == "__main__":
    try:
        print_environment()
    except Exception as e:
        print(f"Error: {e}")
        exit(1)
