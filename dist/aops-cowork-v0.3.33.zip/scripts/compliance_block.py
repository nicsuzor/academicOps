#!/usr/bin/env -S uv run python
"""CLI wrapper to set compliance block flag.

Usage:
    compliance_block.py <session_id> <reason>

Example:
    compliance_block.py abc123 "Agent modified setup.sh without approval - violates P#5"
"""

from __future__ import annotations

import sys
from pathlib import Path

# Add aops-core to path so lib is a proper package
aops_core_path = Path(__file__).parent.parent
sys.path.insert(0, str(aops_core_path))

from lib.session_state import set_enforcer_block


def main() -> int:
    if len(sys.argv) < 3:
        print("Usage: compliance_block.py <session_id> <reason>", file=sys.stderr)
        return 1

    session_id = sys.argv[1]
    reason = sys.argv[2]

    set_enforcer_block(session_id, reason)
    print(f"Block set for session {session_id}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
