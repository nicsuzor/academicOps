# Daily Note: Workflow Monitoring

## Step 6: Monitor Workflows

Surface outstanding workflow signals in "What Needs Attention". This step runs after progress sync and before the task completion sweep (Step 7). Task auto-close logic lives in Step 7 — not here.

### Step 6.1: Discover Tracked Repos

Read `$AOPS_SESSIONS/polecat.yaml` to get the project registry. For each project, resolve the on-disk path via convention (`$AOPS_SRC_DIR/<repo>`) or `$POLECAT_HOME/local.yaml` `paths.<slug>`. Skip repos that don't resolve locally.

**Deduplication**: If multiple projects map to the same underlying repository path (e.g., a sub-project alias like `tja` mapping to `explorations`), **deduplicate by repo path**. Render the PRs for that repository only once under the primary repository's name. Do not render duplicate sections for aliases.

This is the same repo discovery used by Step 4.2.5 (merged PR query). The repo list is configurable — repos are added/removed by editing `polecat.yaml` in the sessions repo, not by changing skill code.

### Step 6.2: Read PR State From repo-sync-cron Artefact

**Primary path: read `$AOPS_SESSIONS/state/pr-state.json`.** `repo-sync-cron` (invoking `gha_sync`) is the **single producer** of PR state across tracked repos. `/daily` is a **consumer** — it MUST NOT re-run `gh pr list` itself. One producer / two consumers (daily + dashboard) is the design.

```bash
test -f "$AOPS_SESSIONS/state/pr-state.json" && cat "$AOPS_SESSIONS/state/pr-state.json"
```

The artefact contains, per repo, the bucketed open PR list (Ready to merge / Needs review / Needs fixes / Stale / Draft) plus the timestamp of the producing `repo-sync-cron` run.

**Staleness threshold (concrete)**: If `pr-state.json` is older than **24 hours** (or missing entirely), render Outstanding Workflows with a single inline note: `Outstanding Workflows: stale (last repo-sync-cron artefact YYYY-MM-DD HH:MM, >24h ago) — running scripts/repo-sync-cron.sh will refresh.` Do NOT fall back to a live `gh pr list` from this skill — the producer/consumer separation is the whole point. The user can run `scripts/repo-sync-cron.sh` (or wait for the cron) to refresh.

**Graceful degradation**:

- Missing artefact (file does not exist) → render: `Outstanding Workflows: no repo-sync-cron artefact yet — run scripts/repo-sync-cron.sh to populate.`
- Stale artefact (>24h) → render the stale note above.
- Malformed JSON → render: `Outstanding Workflows: artefact unreadable — check $AOPS_SESSIONS/state/pr-state.json.`

Never produce empty tables or error codes.

> **Migration note**: prior versions of this step ran `gh pr list` per repo with parallel subagents. Removed in favour of consuming the `$AOPS_SESSIONS/state/pr-state.json` artefact produced by `repo-sync-cron`.

### Step 6.3: Bucket PRs by Actionability

Classify each open PR into one of the following buckets, in order of prominence:

| Bucket                 | Criteria                                                                                                                 | Prominence                         |
| ---------------------- | ------------------------------------------------------------------------------------------------------------------------ | ---------------------------------- |
| **Ready to merge**     | `mergeable == "MERGEABLE"` AND `reviewDecision == "APPROVED"` AND CI passing (all checks in `statusCheckRollup` succeed) | Bold, direct URL, one-click action |
| **Needs review**       | `mergeable == "MERGEABLE"` AND `reviewDecision` is empty/pending AND not draft                                           | Brief context line with URL        |
| **Needs fixes**        | `mergeable == "CONFLICTING"` OR CI failing OR `reviewDecision == "CHANGES_REQUESTED"`                                    | Name the specific blocker          |
| **Stale**              | `createdAt` >7 days ago AND `updatedAt` >7 days ago AND not draft                                                        | Flag with age only                 |
| **Draft / autonomous** | `isDraft == true` OR author is a bot/polecat-worker                                                                      | Collapsed into count               |

**CI status derivation**: Extract from `statusCheckRollup`. Classify as passing (all succeed), failing (any failure — name the failing checks), pending (any in progress, none failing), or no checks (empty rollup).

**A PR can appear in only one bucket.** Apply rules top-to-bottom — a stale PR that also needs fixes goes in "Needs fixes" (the more actionable bucket). A draft PR always goes in "Draft / autonomous" regardless of other signals.

### Step 6.4: Compose "Outstanding Workflows" Subsection

Write the subsection into "What Needs Attention" in the daily note. Format proportionally:

```markdown
### Outstanding Workflows

**Ready to merge:**

- [ ] [#123](url) [[repo]] — PR title (+N/-M, N files) — _merge now_
- [ ] [#456](url) [[repo]] — PR title (+N/-M, N files) — _merge now_

**Needs review:**

- [#789](url) [[repo]] — PR title — awaiting review (N days)

**Needs fixes:**

- [#101](url) [[repo]] — PR title — type check failing
- [#102](url) [[repo]] — PR title — merge conflicts

**Stale (>7d open):**

- [#200](url) [[repo]] — PR title — 12d open, no activity — close or rebase?

* N draft/autonomous PRs across M repos

_X open PRs total — Y ready to merge, Z need attention_
```

**Formatting rules:**

- **Ready to merge** PRs render as `- [ ]` checkboxes with direct URLs. One-click decisions the user can tick off in their editor as they merge them. User ticks are preserved on regeneration (bidirectional contract — see `SKILL.md`).
- **Draft / autonomous** PRs: Collapse into a single count line.
- **Stale** PRs include age only. Do not recommend close/rebase/review — the user decides.
- Include size (`+additions/-deletions, N files`) for ready-to-merge PRs to help gauge merge confidence.
- Omit empty buckets entirely. If nothing is ready to merge, don't show the heading.

**Empty state**: If no open PRs across all repos: "No outstanding PRs." (single line, no subsection heading).

### Step 6.5: "Needs Your Call" — Ambiguous Completions

This step defines the format and location for ambiguous completion cases. The content is populated during Step 7 (Task Completion Sweep) — not here. Step 6.5 runs before Step 7, so this subsection is written into the note by Step 7 when it identifies ambiguous cases.

```markdown
### Needs Your Call

- **[task-abc123]** [[Task Title]] — PR [#456](url) was closed (not merged). Complete anyway? `/pull task-abc123 --complete`
- **[task-def456]** [[Email Reply Task]] — Sent email to [[Contact]] on similar subject but different thread. Mark done? `/pull task-def456 --complete`
```

**Rules:**

- Never auto-close items listed here — human judgment required
- Include the specific evidence and why it's ambiguous
- Include a one-click closure suggestion (task ID + action)
- Omit this subsection entirely if no ambiguous cases exist

### Step 6.6: Relationship to Work Log

The Outstanding Workflows subsection in "What Needs Attention" is the **single source** for open PRs in the daily note. The Work Log no longer carries a parallel "Open PRs" table — it was removed because it duplicated the same PR data in full-table form, padding the note without adding signal.

**What goes where:**

| Signal                                     | What Needs Attention                        | Work Log              |
| ------------------------------------------ | ------------------------------------------- | --------------------- |
| Open PRs (all buckets)                     | Yes — this is the canonical place           | No                    |
| Ready-to-merge PRs                         | `- [ ]` checkbox with URL + "merge now"     | No                    |
| PRs needing review / fixes / stale         | Listed under their bucket heading           | No                    |
| Merged PRs                                 | No                                          | Yes — merged PR table |
| PR action pipeline (agent recommendations) | Called out inline with the PR in its bucket | No (retired)          |
| Task completion sweep results              | "Needs your call" for ambiguous             | Sweep summary counts  |
