---
title: Session Hook Forensics — Detailed Procedures
type: reference
category: ref
permalink: ref-forensics-details
description: How to read hook JSONL logs, diagnose gate failures, trace session events, and correlate artifacts across the polecat system
---

# Session Hook Forensics — Detailed Procedures

> **Scope split with `GATES.md`.** This file is the **JSONL forensics procedure** — how to read raw hook log files and diagnose specific session artifacts. For the **catalogue of which gates exist, how each is configured, and how to verify it's firing**, see [`specs/GATES.md`](../../../../specs/GATES.md) (the canonical state SSoT). For hook architecture and I/O schemas, see [[hooks]]. For general framework debugging, see [[debug-details]].

This reference provides the specific knowledge needed to diagnose hook and gate behavior from raw session artifacts.

## Hook JSONL Schema

Hook events are logged by `unified_logger.py` into the session status dir, alongside the state file. All artefacts for one session share a single canonical base name (PKB kb-d8f58167):

- Claude: `~/.claude/projects/<workspace>/<base>-hooks.jsonl`
- Gemini: `~/.gemini/tmp/<workspace>/<base>-hooks.jsonl` (no `logs/` subdir)
- Polecat workers: `/home/worker/.claude/projects/<workspace>/<base>-hooks.jsonl`

Where `<workspace>` for Gemini is the cwd basename (Gemini CLI's per-project tmp dir) and `<base>` is the unified session-naming string `{YYYYMMDD}-{HHMM}-{shorthash}-{shortform}-{slug}` shared across the state file, hook log, and gate context files for that session.

Each line is a JSON object. Hook logs are local-only — they are not synced to the sessions repo.

### Key Fields

| Field                | Type        | Description                                                                                                                                          |
| -------------------- | ----------- | ---------------------------------------------------------------------------------------------------------------------------------------------------- |
| `session_id`         | string      | Full UUID                                                                                                                                            |
| `session_short_hash` | string      | First 8 chars of UUID                                                                                                                                |
| `hook_event`         | string      | `SessionStart`, `PreToolUse`, `PostToolUse`, `UserPromptSubmit`, `Stop`, `SubagentStart`, `SubagentStop`, `SessionEnd`, `PreCompact`, `Notification` |
| `logged_at`          | string      | ISO 8601 timestamp                                                                                                                                   |
| `exit_code`          | int         | 0=allow, 1=warn, 2=block                                                                                                                             |
| `cwd`                | string      | Working directory at time of event                                                                                                                   |
| `tool_name`          | string/null | Tool that triggered this event (PreToolUse/PostToolUse)                                                                                              |
| `subagent_type`      | string/null | Agent type (SubagentStart/SubagentStop)                                                                                                              |
| `output`             | object/null | **The gate verdict and messages** — see below                                                                                                        |

### The `output` Field (CanonicalHookOutput)

This is the most important field for forensics. Written by `unified_logger.py:69` as `output.model_dump()`.

```json
{
  "verdict": "allow" | "deny" | null,
  "system_message": "Text shown to agent or logged (may be null)",
  "context_injection": "Text injected into agent context (may be null)",
  "updated_input": null,
  "metadata": { "source": "...", ... }
}
```

- **`verdict`**: `"allow"` = gate passed, `"deny"` = gate blocked. On PreToolUse, deny means the tool call was rejected.
- **`system_message`**: Human-readable message about gate state. Contains countdown markers (`◇ N`), gate status icons (`💧 ≡`), and blocking reasons.
- **`context_injection`**: Instructions injected into the agent's context. Contains compliance check demands, skill routing tables, etc.

### Known Transcript Gap

**IMPORTANT**: The transcript parser (`transcript_parser.py:1764`) reads `data.get("hookSpecificOutput")` — a field from the Claude Code protocol that does NOT exist in hook JSONL. All `output` fields (verdicts, system_messages, context_injections) are silently dropped from generated transcripts. Until this parser bug is fixed, you **must read raw hook JSONL** for gate forensics. Do not trust transcripts for hook behavior.

## File Locations & Cross-Referencing

### Finding Files for a Session

All session artefacts share one base name `<base> = {date}-{time}-{shorthash}-{shortform}-{slug}` where `<shortform>` is `{crew?}-{repo}-{provider}` (e.g. `gloria-academicops-gemini`):

| Artifact                        | Location                                                                           | Pattern                         |
| ------------------------------- | ---------------------------------------------------------------------------------- | ------------------------------- |
| Session state                   | `$AOPS_SESSION_STATE_DIR/`                                                         | `<base>-session.json`           |
| Hook JSONL                      | `$AOPS_SESSION_STATE_DIR/`                                                         | `<base>-session-hooks.jsonl`    |
| Enforcer audit                  | `$AOPS_SESSION_STATE_DIR/`                                                         | `<base>-session-enforcer.md`    |
| DEBUG_HOOKS dump                | `$AOPS_SESSION_STATE_DIR/`                                                         | `cc_hooks_<session-uuid>.jsonl` |
| Provider session JSONL (Claude) | `~/.claude/projects/<workspace>/`                                                  | `<session-uuid>.jsonl`          |
| Provider session JSONL (Gemini) | `~/.gemini/tmp/<workspace>/chats/`                                                 | `session-*.jsonl`               |
| Transcript (full)               | `$AOPS_SESSIONS/transcripts/` or `$AOPS_SESSIONS/transcripts/<yyyy-mm>/` (rotated) | `<base>-full.md`                |
| Transcript (abridged)           | `$AOPS_SESSIONS/transcripts/` or `$AOPS_SESSIONS/transcripts/<yyyy-mm>/` (rotated) | `<base>-abridged.md`            |
| Summary                         | `$AOPS_SESSIONS/summaries/`                                                        | `<base>.json`                   |

`$AOPS_SESSIONS` holds **only** parsed/synced outputs (transcripts, summaries) that get committed to git. Everything else — state, hook logs, gate context, debug dumps, provider's raw session stream — lives in `$AOPS_SESSION_STATE_DIR` (the per-provider tmp dir) and is not synced.

### Example Local Paths

- `$AOPS_SESSIONS` = `$HOME/src/sessions` (parsed transcripts/summaries; git-tracked)
- `$POLECAT_HOME` = `$HOME/.aops`
- `$AOPS_SESSION_STATE_DIR` = `$HOME/.claude/projects/<project-dir>/` (Claude) or `$HOME/.gemini/tmp/<basename(cwd)>/` (Gemini)
- Session env file (Claude only) = `$CLAUDE_ENV_FILE` set by Claude Code at session start (typically `~/.claude/shell-snapshots/...`); written to by `session_env_setup.py`. Gemini has no analog — Gemini hooks anchor on the existing state file in `$AOPS_SESSION_STATE_DIR` instead.

### Correlating Task → Session → Artifacts

1. **Task → Session**: Polecat branches use `polecat/<task-id>` naming. Check `git log --all --oneline | grep <task-id>` to find the worktree.
2. **Session → Hook JSONL**: Read the first line of the hook JSONL for `session_short_hash`, or match by date and session hash in the filename.
3. **Session → Transcript**: Transcripts include the session short hash in the filename. Search: `ls $POLECAT_HOME/sessions/transcripts/ | grep <session-short-hash>`.

## Gate Forensics

### Enforcer / RBG Gate

The compliance gate periodically requires the agent to invoke the enforcer (Haiku) or rbg (Sonnet) subagent.

**Configuration**:

- Threshold: `gates.enforcer_threshold` in `$AOPS_SESSIONS/polecat.yaml` (default: **50 operations**)
- Countdown starts: 7 operations before threshold (`start_before=7`)
- Counter: tracks `ops_since_open` (incremented on PostToolUse for non-subagent calls)
- Resets: when enforcer/rbg subagent completes (SubagentStop event)

**IMPORTANT**: The gate counts **operations** (tool calls), NOT turns (user prompts). A single turn may produce 5-10 tool calls. "11 turns" ≈ 50 operations.

**Diagnostic commands**:

```bash
# Count total operations in a session
grep -c '"hook_event":"PostToolUse"' <hooks.jsonl>

# Check if enforcer was dispatched (and how many times)
grep -E '"hook_event":"SubagentSt' <hooks.jsonl> | \
  python3 -c "
import sys, json
for line in sys.stdin:
    d = json.loads(line.strip())
    st = d.get('subagent_type', '')
    if 'enforcer' in st or 'rbg' in st:
        evt = d.get('hook_event')
        v = d.get('output', {}).get('verdict')
        print(f'{evt}: type={st}, verdict={v}')
"

# Check if enforcer blocked (verdict=deny on PreToolUse after threshold)
grep '"hook_event":"PreToolUse"' <hooks.jsonl> | \
  python3 -c "
import sys, json
for line in sys.stdin:
    d = json.loads(line.strip())
    out = d.get('output', {})
    if out.get('verdict') == 'deny':
        tool = d.get('tool_name', '?')
        msg = str(out.get('system_message', ''))[:100]
        print(f'BLOCKED: {tool} — {msg}')
"
```

**What to look for**:

- `SubagentStart` with `subagent_type` containing `enforcer` or `rbg` = gate check started
- `SubagentStop` with same type + `verdict=allow` = gate cleared, counter reset
- PreToolUse with `verdict=deny` and system_message mentioning "Compliance check" = gate blocking tools
- Multiple SubagentStart/Stop pairs = gate firing repeatedly (normal in long sessions)

### Stop / Handover Gate

The Stop hook enforces session completion requirements (commit, handover, etc.).

**Configuration**:

- Handover gate: starts CLOSED when task bound, opens when `/dump` skill completes
- Safety override: after **4 consecutive denies within 2 minutes**, auto-approves to prevent deadlock

**Diagnostic commands**:

```bash
# Find all Stop events and their verdicts
grep '"hook_event":"Stop"' <hooks.jsonl> | \
  python3 -c "
import sys, json
for line in sys.stdin:
    d = json.loads(line.strip())
    out = d.get('output', {})
    v = out.get('verdict', '?')
    msg = str(out.get('system_message', ''))[:100]
    ts = d.get('logged_at', '?')
    print(f'{ts} verdict={v} msg={msg}')
"
```

**What to look for**:

- `verdict=deny` with `system_message` containing "Uncommitted changes" = handover gate blocking
- 4 consecutive denies followed by `verdict=allow` = safety override fired (common pattern)
- `verdict=allow` with no denies = session ended cleanly

**The 4-deny pattern**: Many sessions show exactly 4 Stop denies before auto-approval. This is the safety override, not agent compliance. It means the agent either ignored or could not comply with the stop advice. Investigate the CC session JSONL to understand what the agent did between denies.

## Identifying Polecat Sessions

### By Working Directory

Polecat worktree sessions have `cwd` containing `.claude/worktrees/`:

```bash
for f in ~/.claude/projects/*/*-hooks.jsonl; do
    head -1 "$f" 2>/dev/null | python3 -c "
import sys, json
try:
    d = json.loads(sys.stdin.read())
    cwd = d.get('cwd', '')
    if 'worktree' in cwd:
        print(f'{d.get(\"session_short_hash\")} | {d.get(\"logged_at\",\"?\")[:10]} | {cwd}')
except: pass
" 2>/dev/null
done
```

### Claude vs Gemini

- **Claude sessions**: Standard UUID session IDs (e.g., `fafa268a-7570-4284-...`)
- **Gemini sessions**: Prefixed with `gemini-` (e.g., `gemini-20260405-abc12345`)
- **Known gap**: The `model` and `client` fields in hook JSONL are currently `unknown` for all polecat sessions. The only reliable identifier is the session ID format.

## Common Patterns

### Pattern: Enforcer firing repeatedly in long sessions

**Sessions**: `fafa268a` (193 ops, 10+ dispatches), `c7909ba1` (211 ops), `ac37cbc3` (268 ops)
**Meaning**: Normal. Long sessions accumulate many operations. The gate fires every ~50 ops, enforcer evaluates, returns OK, counter resets, work continues.

### Pattern: 4 Stop denies then auto-approve

**Sessions**: `00d1f873`, `08a89782`, `0adf0325`, and many others
**Meaning**: Agent tried to stop but had uncommitted changes. Ignored 3 denies. Safety override on 4th. Investigate whether the agent attempted to commit between denies or just retried Stop.

### Pattern: Zero Gemini hook JSONL

**As of 2026-04-09**: No Gemini-prefixed sessions exist in hook JSONL. Either Gemini polecats haven't been run with the current hook system, or the integration is broken. This is an open question.

### Pattern: Operations vs turns confusion

The gate threshold is 50 operations (tool calls), not 50 turns. A single user prompt can trigger 5-10+ tool calls. When someone says "the gate fired at 11 turns," it means ~50 operations happened across 11 prompts.
