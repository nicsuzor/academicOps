"""
Internal Pydantic models for hook scripts.

These models define typed structures for internal hook operations.
External API contracts are defined in schemas.py (HookContext, CanonicalHookOutput).
"""

from typing import Any

from pydantic import BaseModel, Field

from .schemas import HookContext


class SessionCleanupResult(BaseModel):
    """Result of end-of-session cleanup operations.

    Cleanup steps (fail-fast order):
    1. Generate transcript (includes insights extraction)
    2. Verify insights JSON exists
    3. Delete session state file

    Attributes:
        success: All cleanup steps succeeded
        transcript_generated: Transcript was generated successfully
        insights_verified: Insights JSON file exists
        state_deleted: Session state file was deleted
        message: Human-readable status message
    """

    success: bool = False
    transcript_generated: bool = False
    insights_verified: bool = False
    state_deleted: bool = False
    message: str = ""


class HookLogEntry(HookContext):
    """Single entry in the per-session hooks JSONL log.
    Inherits all fields from HookContext, plus additional metadata and caching.

    Attributes:
        hook_event: Name of the hook event (e.g., UserPromptSubmit)
        trace_id: Unique ID for this specific hook invocation
        logged_at: ISO timestamp when event was logged
        exit_code: Exit code of the hook (0 = success)
    """

    hook_event: str
    trace_id: str | None = None
    logged_at: str
    exit_code: int = 0
    output: dict[str, Any] | None = None
    raw_input: dict[str, Any] = Field(default_factory=dict)
