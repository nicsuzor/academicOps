"""
Session Reader - Unified parser for Claude Code session files.

Reads and combines:
- Main session JSONL (*.jsonl)
- Agent transcripts (agent-*.jsonl)
- Hook logs (*-hooks.jsonl)

Used by:
- /transcript skill for markdown export
- Dashboard for live activity display
- Intent router context extraction
"""

from __future__ import annotations

import itertools
import json
import logging
import re
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

from lib.paths import (
    get_plugin_root,
    get_sessions_repo,
    get_summaries_dir,
    get_transcripts_dir,
    resolve_plugin_path,
)
from lib.session_paths import cowork_source_roots
from lib.transcript_parser import (
    SessionInfo,
    SessionPipelineState,
    SessionProcessor,
    TodoWriteState,
    _summarize_tool_input,
    normalize_gemini_project,
)
from lib.transcript_paths import iter_rotated_files

_MAX_TURNS = 5
_PROMPT_TRUNCATE = 400  # Increased from 100 to preserve more context (validated 2026-01-11)


def parse_todowrite_state(entries: list[Any]) -> TodoWriteState | None:
    """
    Parse the most recent TodoWrite state from session entries.

    Scans entries in reverse order to find the most recent TodoWrite call
    and extracts the full state.

    Args:
        entries: List of session entries (dicts with type, message, etc.)

    Returns:
        TodoWriteState with todos list, counts, and in_progress task.
        Returns None if no TodoWrite found.
    """
    for entry in reversed(entries):
        # Handle both Entry objects and raw dicts
        if hasattr(entry, "type"):
            entry_type = entry.type
            message = entry.message or {}
        else:
            entry_type = entry.get("type")
            message = entry.get("message", {})

        if entry_type != "assistant":
            continue

        content = message.get("content", [])
        if not isinstance(content, list):
            continue

        for block in content:
            if isinstance(block, dict) and block.get("type") == "tool_use":
                if block.get("name") == "TodoWrite":
                    tool_input = block.get("input", {})
                    todos = tool_input.get("todos", [])
                    if todos:
                        counts = {"pending": 0, "in_progress": 0, "completed": 0}
                        in_progress_task = None
                        for todo in todos:
                            status = todo.get("status", "pending")
                            if status in counts:
                                counts[status] += 1
                            if status == "in_progress" and not in_progress_task:
                                in_progress_task = todo.get("content", "")

                        return TodoWriteState(
                            todos=todos,
                            counts=counts,
                            in_progress_task=in_progress_task,
                        )

    return None


def _is_system_injected_context(text: str) -> bool:
    """Check if text is system-injected context (not actual user input).

    These are automatically added by Claude Code, not typed by user:
    - <agent-notification> - task completion notifications
    - <ide_selection> - user's IDE selection
    - <ide_opened_file> - file user has open in IDE
    - <system-reminder> - hook-injected reminders
    """
    stripped = text.strip()
    system_prefixes = (
        "<agent-notification>",
        "<ide_selection>",
        "<ide_opened_file>",
        "<system-reminder>",
    )
    return any(stripped.startswith(prefix) for prefix in system_prefixes)


def _clean_prompt_text(text: str) -> str:
    """Clean prompt text by stripping command XML markup.

    Commands like /do wrap content in XML:
    <command-message>do</command-message>
    <command-name>/do</command-name>
    <command-args>actual user intent here</command-args>

    This extracts just the args content.
    """

    # Check for command XML format
    args_match = re.search(r"<command-args>(.*?)</command-args>", text, re.DOTALL)
    if args_match:
        return args_match.group(1).strip()

    # Not a command, return as-is
    return text


def _extract_and_expand_prompts(turns: list, max_turns: int) -> list[str]:
    """Extracts user prompts from turns, expanding command invocations."""
    prompts = []
    for turn in turns:
        user_message = turn.get("user_message") if isinstance(turn, dict) else turn.user_message
        is_meta = turn.get("is_meta") if isinstance(turn, dict) else turn.is_meta

        if not user_message or is_meta:
            continue

        text = user_message.strip()

        if not text or _is_system_injected_context(text):
            continue

        command_name = None
        args = ""

        # Case 1: XML-wrapped command
        command_name_match = re.search(r"<command-name>(.*?)</command-name>", text, re.DOTALL)
        if command_name_match:
            command_name = command_name_match.group(1).strip()
            args_match = re.search(r"<command-args>(.*?)</command-args>", text, re.DOTALL)
            if args_match:
                args = f" {args_match.group(1).strip()}"
        # Case 2: Simple command prefix
        elif text.startswith("/"):
            parts = text.split(maxsplit=1)
            command_name = parts[0]
            if len(parts) > 1:
                args = f" {parts[1]}"

        if command_name:
            skill_name = command_name.lstrip("/")

            scope = load_skill_scope(skill_name)
            if scope:
                # The scope is a markdown summary. Let's clean it up for the prompt.
                # "Purpose: ..." or "Workflow: ..."
                summary = " ".join(scope.replace("**", "").split())
                prompts.append(f'{command_name}{args} → "{summary}"')
                continue

        # Fallback to old logic
        cleaned = _clean_prompt_text(text)
        if cleaned:
            prompts.append(cleaned)

    return prompts[-max_turns:] if prompts else []


def extract_gate_context(
    transcript_path: Path,
    include: set[str],
    max_turns: int = _MAX_TURNS,
) -> dict[str, Any]:
    """Extract configurable context for gate agents.

    Provides targeted extraction for gate functions per gate-agent-architecture.md.
    Each gate requests only the context it needs via the include parameter.

    Args:
        transcript_path: Path to session JSONL file
        include: Set of extraction types (prompts, skill, todos, intent, errors, tools)
        max_turns: Lookback limit for prompts/tools

    Returns:
        Dict with requested context sections. Empty dict on error.

    Example:
        >>> result = extract_gate_context(path, include={"prompts", "skill"})
        >>> result["prompts"]  # List of recent user prompts
        >>> result["skill"]    # Most recent Skill invocation or None
    """
    if not include:
        return {}

    if not transcript_path.exists():
        return {}

    try:
        return _extract_gate_context_impl(transcript_path, include, max_turns)
    except (OSError, ValueError, KeyError, AttributeError) as exc:
        logger.error("extract_gate_context failed for %s: %s", transcript_path, exc, exc_info=True)
        return {}


def build_rich_session_context(transcript_path: Path | str, max_turns: int = 15) -> str:
    """Build rich session context for compliance checks.

    Extracts recent conversation history, tool usage, files modified,
    and any errors to provide context for compliance evaluation.

    Args:
        transcript_path: Path to session transcript JSONL file
        max_turns: Number of recent turns to include (default 15)

    Returns:
        Formatted markdown context or error message
    """
    path = Path(transcript_path)
    if not path.exists():
        return "(No transcript path available)"

    lines: list[str] = []

    # Extract using library
    gate_ctx = extract_gate_context(
        path,
        include={"prompts", "errors", "tools", "files", "conversation", "skill"},
        max_turns=max_turns,
    )

    # ALL user requests (chronological) - enables scope drift detection
    prompts = gate_ctx.get("prompts", [])
    if prompts:
        lines.append("**All User Requests** (chronological):")
        for i, prompt in enumerate(prompts, 1):
            # Truncate very long prompts but preserve enough for scope checking
            truncated = prompt[:500] + "..." if len(prompt) > 500 else prompt
            lines.append(f"  {i}. {truncated}")
        lines.append("")
        # Also highlight the most recent for quick reference
        lines.append("**Most Recent User Request**:")
        lines.append(f"> {prompts[-1][:500]}")
        lines.append("")

    # Active skill context (if any)
    skill = gate_ctx.get("skill")
    if skill:
        lines.append(f"**Active Skill**: {skill}")
        lines.append("")

    # Recent tool usage WITH ARGUMENTS - enables action verification
    tools = gate_ctx.get("tools", [])
    if tools:
        lines.append("**Recent Tool Calls** (with arguments):")
        for tool in tools[-10:]:  # Last 10 tools
            tool_name = tool["name"]  # Required field - fail if missing
            tool_input = tool.get("input") or {}
            # Format tool arguments, truncate at 200 chars
            if tool_input:
                # Summarize key arguments
                arg_parts = []
                for k, v in list(tool_input.items())[:5]:  # Max 5 args shown
                    v_str = str(v)
                    if len(v_str) > 50:
                        v_str = v_str[:50] + "..."
                    arg_parts.append(f"{k}={v_str}")
                args_str = ", ".join(arg_parts)
                if len(args_str) > 200:
                    args_str = args_str[:200] + "..."
                lines.append(f"  - {tool_name}({args_str})")
            else:
                lines.append(f"  - {tool_name}()")
        lines.append("")

    # Files modified/read
    files = gate_ctx.get("files", [])
    if files:
        lines.append("**Files Accessed**:")
        for f in files[-10:]:  # Last 10 files
            # Handle both legacy list[str] shape and newer list[dict] shape
            if isinstance(f, dict) and "action" in f and "path" in f:
                lines.append(f"  - [{f['action']}] {f['path']}")
            else:
                path_str = str(f)
                if path_str:
                    lines.append(f"  - {path_str}")
        lines.append("")

    # Tool errors (important for compliance - Type A detection)
    errors = gate_ctx.get("errors", [])
    if errors:
        lines.append("**Tool Errors** (check for workaround attempts after these):")
        for e in errors[-5:]:
            lines.append(f"  - {e['tool_name']}: {e['error']}")
        lines.append("")

    # FULL agent responses for last 3 turns - enables phrase pattern detection
    # ("I'll just...", "While I'm at it...", etc.)
    conversation = gate_ctx.get("conversation", [])
    if conversation:
        lines.append("**Recent Agent Responses** (full text for phrase detection):")
        # Extract only agent responses, show last 3 with more content
        agent_responses = [
            turn for turn in conversation if (isinstance(turn, str) and turn.startswith("[Agent]:"))
        ]
        for turn in agent_responses[-3:]:  # Last 3 agent responses
            # String format: "[Agent]: content"
            content = turn[8:] if turn.startswith("[Agent]:") else turn
            # Allow up to 1000 chars per response for phrase detection
            if len(content) > 1000:
                content = content[:1000] + "..."
            if content.strip():
                lines.append(f"  {content.strip()}")
                lines.append("")

        # Also show recent conversation flow (condensed)
        lines.append("**Recent Conversation Summary**:")
        for turn in conversation[-5:]:
            # Handle both string and dict formats
            if isinstance(turn, dict):
                role = turn["role"]  # Required - fail if missing
                content = turn["content"][:200]  # Required - fail if missing
                lines.append(f"  [{role}]: {content}...")
            else:
                # String format - role unknown
                content = str(turn)[:200]
                if content:
                    lines.append(f"  [unknown]: {content}...")
        lines.append("")

    if not lines:
        return "(No session context extracted)"

    return "\n".join(lines)


def build_audit_session_context(
    transcript_path: Path | str,
    *,
    entries: list[Any] | None = None,
    max_turns: int | None = None,
) -> str:
    """Build deep session context for audit and compliance review.

    Unlike build_rich_session_context (designed for scope-drift detection with
    thin, wide context), this produces a chronological narrative of the
    session: user requests, agent reasoning, tool calls with results, and
    decisions made. The auditor needs to see what actually happened to provide
    a grounded verdict.

    Design choices:
    - Full detail WITHIN the window — every turn shown carries its tool calls,
      reasoning, and results (no historical/recent split that hides tool calls
      from older shown turns; aops-e4e90f31 truncated-read false-pass bug).
    - Agent reasoning text preserved at length (2000 chars) — auditor needs
      to see *why* decisions were made, not just what tools were called
    - Task/subagent prompts and results shown — these are major decision points
    - Edit diffs summarized — what changed matters for review
    - Noise filtered: TodoWrite, system-reminders, hook internals excluded
    - Tool results included for key tools (Task, Bash) — outcomes matter

    Windowing (aops-5bc65f76): the single windowed builder for both the
    RBG (PreToolUse cadence) and rbg-review (Stop) dispatches. When
    ``max_turns`` is set, only the LAST ``max_turns`` conversation turns are
    rendered — the window is the RBG cadence + 2 (n+2). Because RBG fires
    every n tool-calls, each n+2 window overlaps the previous one by 2 turns,
    so a clean sliding window covers every turn at full detail without a
    full-session re-send (does NOT reopen the #1869 false-PASS hole — that hole
    was truncation of detail WITHIN a shown turn, not bounding the window).
    ``max_turns=None`` (default) renders the whole session.

    Args:
        transcript_path: Path to session transcript JSONL file
        entries: Pre-parsed session entries to avoid redundant file I/O.
            If not provided, the transcript is parsed from disk.
        max_turns: If set, render only the last ``max_turns`` conversation
            turns (the n+2 cadence window). ``None`` renders all turns.

    Returns:
        Formatted markdown context suitable for review agent consumption
    """
    processor = SessionProcessor()

    if entries is None:
        path = Path(transcript_path)
        if not path.exists():
            return "(No transcript path available)"

        _, entries, _ = processor.parse_session_file(path, load_agents=False, load_hooks=False)

    if not entries:
        return "(Empty session)"

    turns = processor.group_entries_into_turns(entries, full_mode=True)
    if not turns:
        return "(No conversation turns found)"

    # Filter out non-conversation and meta-only turns first to get a clean list
    valid_turns = []
    for turn in turns:
        turn_type = turn.get("type") if isinstance(turn, dict) else None
        if turn_type in ("hook_context", "summary"):
            continue

        is_meta = turn.get("is_meta") if isinstance(turn, dict) else turn.is_meta
        assistant_sequence = (
            turn.get("assistant_sequence") if isinstance(turn, dict) else turn.assistant_sequence
        )
        if is_meta and not assistant_sequence:
            continue

        valid_turns.append(turn)

    # Window to the last n+2 turns when a cap is requested (aops-5bc65f76).
    # The RBG cadence guarantees overlapping windows, so trimming older
    # turns here loses no coverage while bounding token cost. max_turns=None
    # keeps the full session.
    if max_turns is not None and max_turns > 0 and len(valid_turns) > max_turns:
        valid_turns = valid_turns[-max_turns:]

    lines: list[str] = []

    # max_turns=None means the whole session is rendered (no windowing) — the
    # same "full" vs "abridged" distinction transcript_parser.py already makes
    # for the persisted transcript files (full_mode bypasses truncation there
    # too). Authorization fields must never be cut off in that full render.
    full_mode = max_turns is None

    # Noise tools the reviewer doesn't need to see individually
    _SKIP_TOOLS = {"TodoWrite", "Skill"}
    # Max chars for agent reasoning text per turn
    _AGENT_TEXT_LIMIT = 2000
    # Max chars for tool arguments
    _TOOL_ARG_LIMIT = 300
    # Max chars for tool results
    _TOOL_RESULT_LIMIT = 1000
    # Max chars for AskUserQuestion answers / ExitPlanMode approval responses
    # in windowed (abridged) mode — these are authorization decisions, not
    # bulk tool output, so they get a far more generous cap than
    # _TOOL_RESULT_LIMIT. Never truncated at all in full_mode.
    _AUTH_RESULT_LIMIT = 4000

    # Every turn in the (possibly windowed) set is rendered at full detail —
    # do NOT restore a historical/recent split within the window: hiding tool
    # calls from older shown turns lets violations in those turns pass the
    # rbg unseen (aops-e4e90f31 truncated-read false-pass bug). Bounding
    # the window via max_turns is safe (overlapping cadence windows); dropping
    # detail from a shown turn is not.
    turn_num = 0

    for turn in valid_turns:
        user_msg = turn.get("user_message") if isinstance(turn, dict) else turn.user_message
        is_meta = turn.get("is_meta") if isinstance(turn, dict) else turn.is_meta
        assistant_sequence = (
            turn.get("assistant_sequence") if isinstance(turn, dict) else turn.assistant_sequence
        )

        turn_num += 1

        # --- User message ---
        if user_msg and not is_meta:
            msg = user_msg.strip()
            # Clean command XML markup
            msg = _clean_prompt_text(msg)
            # Filter out system-injected context
            if not _is_system_injected_context(msg):
                # Generous truncation — user intent matters
                if len(msg) > 1000:
                    msg = msg[:1000] + "..."
                lines.append(f"#### Turn {turn_num}")
                lines.append(f"**User**: {msg}")
                lines.append("")

        # --- Assistant sequence ---
        if not assistant_sequence:
            continue

        # Collect agent text blocks (reasoning/communication)
        text_parts: list[str] = []
        tool_entries: list[str] = []

        for item in assistant_sequence:
            item_type = item.get("type")

            if item_type == "text":
                content = item.get("content", "").strip()
                if content:
                    text_parts.append(content)

            elif item_type == "tool":
                tool_name = item.get("tool_name", "")
                tool_input = item.get("tool_input", {})

                if tool_name in _SKIP_TOOLS:
                    continue

                # Format tool call with meaningful detail
                if tool_name in ("Agent", "Task"):
                    # Subagent calls are major decision points — show full prompt
                    desc = tool_input.get("description", "")
                    subagent = tool_input.get("subagent_type", "")
                    prompt = tool_input.get("prompt", "")
                    if len(prompt) > _TOOL_ARG_LIMIT:
                        prompt = prompt[:_TOOL_ARG_LIMIT] + "..."
                    tool_line = f"  - **{tool_name}**({subagent}): {desc}"
                    if prompt:
                        tool_line += f"\n    > {prompt}"
                    # Show result if available
                    result = item.get("result", "")
                    if result:
                        result_str = str(result)
                        if len(result_str) > _TOOL_RESULT_LIMIT:
                            result_str = result_str[:_TOOL_RESULT_LIMIT] + "..."
                        tool_line += f"\n    Result: {result_str}"

                elif tool_name in ("Edit", "Write"):
                    file_path = tool_input.get("file_path", "")
                    if tool_name == "Edit":
                        old = tool_input.get("old_string", "")
                        new = tool_input.get("new_string", "")
                        if len(old) > 200:
                            old = old[:200] + "..."
                        if len(new) > 200:
                            new = new[:200] + "..."
                        tool_line = f"  - **Edit** `{file_path}`"
                        if old or new:
                            tool_line += f"\n    `{old}` → `{new}`"
                    else:
                        tool_line = f"  - **Write** `{file_path}`"

                elif tool_name == "Read":
                    file_path = tool_input.get("file_path", "")
                    tool_line = f"  - **Read** `{file_path}`"

                elif tool_name == "Bash":
                    cmd = tool_input.get("command", "")
                    desc = tool_input.get("description", "")
                    if len(cmd) > _TOOL_ARG_LIMIT:
                        cmd = cmd[:_TOOL_ARG_LIMIT] + "..."
                    tool_line = f"  - **Bash**: `{cmd}`"
                    if desc:
                        tool_line += f" ({desc})"
                    # Show result/errors for bash
                    result = item.get("result", "")
                    if result:
                        result_str = str(result)
                        if len(result_str) > _TOOL_RESULT_LIMIT:
                            result_str = result_str[:_TOOL_RESULT_LIMIT] + "..."
                        tool_line += f"\n    Output: {result_str}"
                    if item.get("is_error"):
                        error = item.get("error", "")
                        if error:
                            tool_line += f"\n    ERROR: {error[:500]}"

                elif tool_name in ("Grep", "Glob"):
                    pattern = tool_input.get("pattern", "")
                    search_path = tool_input.get("path", "")
                    tool_line = f"  - **{tool_name}**(`{pattern}`"
                    if search_path:
                        tool_line += f", path={search_path}"
                    tool_line += ")"

                elif tool_name == "ExitPlanMode":
                    plan = tool_input.get(
                        "plan", ""
                    )  # allow-fallback: absent plan text just skips the "Plan:" line below
                    if len(plan) > _TOOL_ARG_LIMIT:
                        plan = plan[:_TOOL_ARG_LIMIT] + "..."
                    tool_line = "  - **ExitPlanMode**"
                    if plan:
                        tool_line += f"\n    Plan: {plan}"
                    # Render the approval/rejection response — this is the ONLY
                    # record that a plan was actually authorized before later
                    # tool calls (e.g. TaskCreate) execute it. Omitting it made
                    # custodiet/rbg misread authorized post-plan actions as
                    # unapproved scope expansion (#186).
                    result = item.get(
                        "result", ""
                    )  # allow-fallback: absent result just skips the "Response:" line below
                    if result:
                        result_str = str(result)
                        if not full_mode and len(result_str) > _AUTH_RESULT_LIMIT:
                            result_str = result_str[:_AUTH_RESULT_LIMIT] + "..."
                        tool_line += f"\n    Response: {result_str}"

                elif tool_name == "AskUserQuestion":
                    questions = tool_input.get("questions", [])
                    if questions:
                        q_text = questions[0].get("question", "") if questions else ""
                        tool_line = f"  - **AskUserQuestion**: {q_text}"
                    else:
                        tool_line = "  - **AskUserQuestion**"
                    # Render the user's free-text answer alongside the question.
                    # Without this, an auditor sees only the prompt and can never
                    # verify whether a subsequent action was actually authorized —
                    # the question/answer pair is the ONLY record of many
                    # authorization decisions in a session (bug: answer omitted
                    # from every audit snapshot regardless of when it was read).
                    result = item.get("result", "")
                    if result:
                        result_str = str(result)
                        if not full_mode and len(result_str) > _AUTH_RESULT_LIMIT:
                            result_str = result_str[:_AUTH_RESULT_LIMIT] + "..."
                        tool_line += f"\n    Answer: {result_str}"

                else:
                    # Generic tool — show name and key args
                    arg_parts = []
                    for k, v in list(tool_input.items())[:4]:
                        v_str = str(v)
                        if len(v_str) > 80:
                            v_str = v_str[:80] + "..."
                        arg_parts.append(f"{k}={v_str}")
                    args_str = ", ".join(arg_parts)
                    tool_line = f"  - **{tool_name}**({args_str})"

                tool_entries.append(tool_line)

        # Emit agent reasoning (joined, with generous limit)
        if text_parts:
            full_text = "\n".join(text_parts)
            if len(full_text) > _AGENT_TEXT_LIMIT:
                full_text = full_text[:_AGENT_TEXT_LIMIT] + "..."
            lines.append(f"**Agent**: {full_text}")
            lines.append("")

        # Emit tool calls
        if tool_entries:
            lines.append("Tools:")
            lines.extend(tool_entries)
            lines.append("")

    if not lines:
        return "(No meaningful session content extracted)"

    # The coverage sentinel (audit-complete) is appended by `custom_actions.py`
    # to ensure it is the genuine final line of the rendered file (#1976).

    return "\n".join(lines)


def _extract_gate_context_impl(
    transcript_path: Path,
    include: set[str],
    max_turns: int,
) -> dict[str, Any]:
    """Implementation of gate context extraction using SessionProcessor."""
    processor = SessionProcessor()
    _, entries, _ = processor.parse_session_file(
        transcript_path, load_agents=False, load_hooks=False
    )

    if not entries:
        return {}

    # Group into turns for consistent parsing
    turns = processor.group_entries_into_turns(entries, full_mode=True)

    result = {}

    # Extract prompts using Turns logic
    if "prompts" in include:
        result["prompts"] = _extract_and_expand_prompts(turns, max_turns)

    # For skill we can use raw entries or turns. TodoWrite needs raw entries currently.
    if "skill" in include:
        result["skill"] = _extract_recent_skill(entries)

    if "todos" in include:
        result["todos"] = _extract_todos(entries)

    if "intent" in include:
        # Improve intent extraction to look for first non-meta user turn
        result["intent"] = processor._extract_first_user_request(entries)

    if "tools" in include:
        # Extract tools from turns
        tools = []
        for turn in reversed(turns):
            assistant_sequence = (
                turn.get("assistant_sequence")
                if isinstance(turn, dict)
                else turn.assistant_sequence
            )
            if not assistant_sequence:
                continue
            for item in reversed(assistant_sequence):
                if item.get("type") == "tool":
                    tools.append(
                        {
                            "name": item.get("tool_name", "unknown"),
                            "input": item.get("tool_input", {}),
                            "content": item.get("content", ""),
                        }
                    )
            if len(tools) >= max_turns:  # approximate limits
                break
        result["tools"] = list(reversed(tools[:max_turns]))

    if "errors" in include:
        result["errors"] = _extract_errors(entries, max_turns)

    if "files" in include:
        result["files"] = _extract_files_modified(entries)

    if "conversation" in include:
        # Generate unified conversation log (ns-52v)
        # Returns list of strings [User]: ..., [Agent]: ...
        # Linear pass chronological
        chronological_lines = []
        for turn in turns:
            user_msg = turn.get("user_message") if isinstance(turn, dict) else turn.user_message
            is_meta = turn.get("is_meta") if isinstance(turn, dict) else turn.is_meta

            if user_msg and not is_meta:
                msg = user_msg.strip()
                if len(msg) > 400:
                    msg = msg[:400] + "..."
                chronological_lines.append(f"[User]: {msg}")

            assistant_sequence = (
                turn.get("assistant_sequence")
                if isinstance(turn, dict)
                else turn.assistant_sequence
            )
            if assistant_sequence:
                for item in assistant_sequence:
                    type_ = item.get("type")
                    if type_ == "text":
                        content = item.get("content", "").strip()
                        if content:
                            if len(content) > 400:
                                content = content[:400] + "..."
                            chronological_lines.append(f"[Agent]: {content}")
                    elif type_ == "tool":
                        tool_name = item.get("tool_name", "")
                        comp = item.get("content", "")
                        if not tool_name:
                            if "(" in comp:
                                tool_name = comp.split("(")[0]
                            else:
                                tool_name = comp

                        if tool_name not in ("TodoWrite", "Skill"):
                            # Truncate tool args
                            if len(comp) > 100:
                                comp = comp[:100] + "..."
                            chronological_lines.append(f"[Tool:{tool_name}]: {comp}")

        # Keep last N *lines*? Or turns?
        # Custodiet shows last 5 turns.
        # But if we return list of strings, Custodiet might just show last N output lines?
        # Or we return all lines for last N turns.

        # Let's return lines corresponding to last max_turns turns.
        # Recalculate:
        processed_turns = turns[-max_turns:] if len(turns) > max_turns else turns
        final_log = []
        for turn in processed_turns:
            # User
            user_msg = turn.get("user_message") if isinstance(turn, dict) else turn.user_message
            is_meta = turn.get("is_meta") if isinstance(turn, dict) else turn.is_meta
            if user_msg and not is_meta:
                msg = user_msg.strip()
                if len(msg) > 400:
                    msg = msg[:400] + "..."
                final_log.append(f"[User]: {msg}")

            # Assistant
            assistant_sequence = (
                turn.get("assistant_sequence")
                if isinstance(turn, dict)
                else turn.assistant_sequence
            )
            if assistant_sequence:
                for item in assistant_sequence:
                    type_ = item.get("type")
                    if type_ == "text":
                        content = item.get("content", "").strip()
                        if content:
                            if len(content) > 400:
                                content = content[:400] + "..."
                            final_log.append(f"[Agent]: {content}")
                    elif type_ == "tool":
                        tool_name = item.get("tool_name", "")
                        comp = item.get("content", "")
                        if not tool_name:
                            if "(" in comp:
                                tool_name = comp.split("(")[0]
                            else:
                                tool_name = comp

                        if tool_name not in ("TodoWrite", "Skill"):
                            # Extract content part for display
                            # comp includes Name(args).
                            # We want [Tool:Name]: args
                            # But keeping it simple [Tool:Name]: Name(args) is duplicative
                            # AC says: [Tool:Read]: ...

                            # If comp is "Read(file_path=...)"
                            # We want [Tool:Read]: file_path=...

                            display_args = comp
                            # Strip leading bullet if present
                            if display_args.startswith("- "):
                                display_args = display_args[2:]

                            if tool_name and display_args.startswith(tool_name):
                                display_args = display_args[len(tool_name) :].strip().strip("()")

                            if len(display_args) > 100:
                                display_args = display_args[:100] + "..."
                            final_log.append(f"[Tool:{tool_name}]: {display_args}")

        result["conversation"] = final_log

    return result


def _extract_recent_skill(entries: list[Any]) -> str | None:
    """Extract most recent Skill invocation."""
    for entry in reversed(entries):
        etype = entry.type if hasattr(entry, "type") else entry.get("type")
        if etype != "assistant":
            continue

        message = entry.message if hasattr(entry, "message") else entry.get("message", {})
        content = message.get("content", [])
        if not isinstance(content, list):
            continue

        for block in content:
            if isinstance(block, dict) and block.get("type") == "tool_use":
                if block.get("name") == "Skill":
                    return block.get("input", {}).get("skill")

    return None


def load_skill_scope(skill_name: str) -> str | None:
    """Load a skill/command's authorized scope from its definition file.

    Searches for skill definitions in standard locations and extracts
    the workflow section to provide context for compliance checking.

    Args:
        skill_name: Name of the skill (e.g., "learn", "daily")

    Returns:
        Brief description of what the skill authorizes, or None if not found.
    """

    plugin_root = get_plugin_root()

    # Sibling plugins whose commands/skills may have been extracted out of
    # aops-core (e.g. aops-pkb took /learn, /pull, /q, task-lifecycle, /daily,
    # /dump, /end_session, ...). Search core first, then siblings, so a
    # still-present core definition always wins.
    sibling_roots = [resolve_plugin_path(name) for name in ("aops-pkb", "aops-tools")]

    # Search locations for skill/command definitions
    search_paths = [
        plugin_root / "commands" / f"{skill_name}.md",
        plugin_root / "skills" / f"{skill_name}" / "SKILL.md",
    ]

    for sibling_root in sibling_roots:
        if sibling_root:
            search_paths.append(sibling_root / "commands" / f"{skill_name}.md")
            search_paths.append(sibling_root / "skills" / f"{skill_name}" / "SKILL.md")

    for path in search_paths:
        if path.exists():
            return _extract_skill_scope_from_file(path)

    return None


def _extract_skill_scope_from_file(path: Path) -> str | None:
    """Extract authorized scope summary from a skill/command definition file.

    Looks for:
    1. Frontmatter 'description' field
    2. First ## Workflow section (first 500 chars)

    Returns a brief summary suitable for RBG context.
    """
    try:
        content = path.read_text()
    except OSError:
        return None

    lines: list[str] = []

    # Extract description from YAML frontmatter
    if content.startswith("---"):
        parts = content.split("---", 2)
        if len(parts) >= 3:
            frontmatter = parts[1]
            for line in frontmatter.split("\n"):
                if line.startswith("description:"):
                    desc = line[len("description:") :].strip().strip("\"'")
                    lines.append(f"**Purpose**: {desc}")
                    break

    # Look for ## Workflow section and extract first few steps
    workflow_match = re.search(
        r"## Workflow\s*\n(.*?)(?=\n## |\Z)", content, re.DOTALL | re.IGNORECASE
    )
    if workflow_match:
        workflow_text = workflow_match.group(1).strip()
        # Extract numbered steps or subsections
        steps = re.findall(r"### \d+\.\s*([^\n]+)", workflow_text)
        if steps:
            lines.append("**Workflow steps**: " + ", ".join(steps[:6]))
        elif len(workflow_text) > 0:
            # Fallback: first 300 chars of workflow
            summary = workflow_text[:300].replace("\n", " ")
            if len(workflow_text) > 300:
                summary += "..."
            lines.append(f"**Workflow**: {summary}")

    if not lines:
        return None

    return "\n".join(lines)


def _extract_todos(entries: list[Any]) -> dict[str, Any] | None:
    """Extract current TodoWrite state with full todo list.

    Returns complete todo information for compliance checking,
    not just counts - rbg needs to see the full plan.
    """
    state = parse_todowrite_state(entries)
    if state is None:
        return None

    return {
        "counts": state.counts,
        "in_progress_task": state.in_progress_task,
        "todos": state.todos,  # Full list for drift analysis
    }


def _extract_errors(entries: list[Any], max_turns: int) -> list[dict[str, Any]]:
    """Extract recent tool errors with tool name and input context.

    Correlates tool_result errors with their corresponding tool_use blocks
    to provide actionable context for RBG compliance checking.
    """
    # First pass: build map of tool_use_id -> tool info
    tool_use_map: dict[str, dict[str, Any]] = {}
    for entry in entries:
        etype = entry.type if hasattr(entry, "type") else entry.get("type")
        if etype != "assistant":
            continue
        message = entry.message if hasattr(entry, "message") else entry.get("message", {})
        content = message.get("content", [])
        if not isinstance(content, list):
            continue
        for block in content:
            if isinstance(block, dict) and block.get("type") == "tool_use":
                tool_id = block.get("id", "")
                if tool_id:
                    tool_input = block.get("input", {})
                    # Extract key input for context
                    input_summary = _summarize_tool_input(block.get("name", ""), tool_input)
                    tool_use_map[tool_id] = {
                        "name": block.get("name", "unknown"),
                        "input_summary": input_summary,
                    }

    # Second pass: extract errors and correlate with tool info
    errors: list[dict[str, Any]] = []
    for entry in entries:
        etype = entry.type if hasattr(entry, "type") else entry.get("type")
        if etype != "user":
            continue

        message = entry.message if hasattr(entry, "message") else entry.get("message", {})
        content = message.get("content", [])
        if not isinstance(content, list):
            continue

        for item in content:
            if isinstance(item, dict) and item.get("type") == "tool_result":
                if item.get("is_error") or item.get("isError"):
                    tool_id = item.get("tool_use_id") or item.get("toolUseId") or ""
                    tool_info = tool_use_map.get(tool_id, {})
                    error_content = item.get("content", "")

                    errors.append(
                        {
                            "tool_name": tool_info.get("name", "unknown"),
                            "input_summary": tool_info.get("input_summary", ""),
                            "error": str(error_content)[:300],
                        }
                    )

    return errors[-max_turns:] if errors else []


def _extract_files_modified(entries: list[Any]) -> list[str]:
    """Extract unique list of files modified via Edit/Write tools.

    Used by RBG for scope assessment - are we touching files
    unrelated to the original request?
    """
    files: set[str] = set()

    for entry in entries:
        etype = entry.type if hasattr(entry, "type") else entry.get("type")
        if etype != "assistant":
            continue

        message = entry.message if hasattr(entry, "message") else entry.get("message", {})
        content = message.get("content", [])
        if not isinstance(content, list):
            continue

        for block in content:
            if isinstance(block, dict) and block.get("type") == "tool_use":
                tool_name = block.get("name", "")
                tool_input = block.get("input", {})

                # Track Edit and Write operations
                if tool_name in ("Edit", "Write"):
                    file_path = tool_input.get("file_path", "")
                    if file_path:
                        files.add(file_path)

    return sorted(files)


def _extract_text_from_content(content: Any) -> str:
    """Extract text from various content formats."""
    if isinstance(content, str):
        return content.strip()

    if isinstance(content, list):
        for block in content:
            if isinstance(block, dict) and block.get("type") == "text":
                return block.get("text", "").strip()

    return ""


def _load_agy_workspace_map() -> dict[str, str]:
    """Build conversation UUID → workspace path map from agy data files."""
    result: dict[str, str] = {}

    agy_dir = Path.home() / ".gemini" / "antigravity-cli"

    # Primary source: history.jsonl has conversationId + workspace per prompt
    history = agy_dir / "history.jsonl"
    if history.exists():
        try:
            for line in history.read_text().splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                except json.JSONDecodeError:
                    continue
                cid = entry.get("conversationId") or entry.get("conversation_id")
                workspace = entry.get("workspace")
                if cid and workspace:
                    result[cid] = workspace
        except OSError:
            pass

    # Fallback: last_conversations.json maps workspace → most-recent UUID
    last_convos = agy_dir / "cache" / "last_conversations.json"
    if last_convos.exists():
        try:
            data = json.loads(last_convos.read_text())
            for workspace, uuid in data.items():
                if isinstance(uuid, str) and uuid not in result:
                    result[uuid] = workspace
        except (json.JSONDecodeError, OSError):
            pass

    return result


def find_sessions(
    project: str | None = None,
    since: datetime | None = None,
    claude_projects_dir: Path | None = None,
    include_gemini: bool = True,
    include_antigravity: bool = True,
    include_cowork: bool = True,
) -> list[SessionInfo]:
    """
    Find all Claude Code, Gemini, Cowork, and optionally Antigravity sessions.

    Args:
        project: Filter to specific project (partial match)
        since: Only sessions modified after this time
        claude_projects_dir: Override default ~/.claude/projects/
        include_gemini: Whether to include sessions from ~/.gemini/tmp/
        include_antigravity: Whether to include sessions from ~/.gemini/antigravity{-cli,}/brain/
        include_cowork: Whether to include sessions from Claude Desktop Cowork

    Returns:
        List of SessionInfo, sorted by last_modified descending (newest first)
    """
    sessions = []
    seen_cowork_ids = set()

    # 1. Find Claude Code sessions (and ingested Cowork sessions)
    if claude_projects_dir is None:
        claude_projects_dir = Path.home() / ".claude" / "projects"

    # Search in ~/.claude/projects/ and (if include_cowork) framework-persisted Cowork logs
    cowork_logs_dir = (get_sessions_repo() / "cowork-logs") if include_cowork else None
    claude_dirs = [claude_projects_dir]
    if cowork_logs_dir is not None:
        claude_dirs.append(cowork_logs_dir)

    for project_base in claude_dirs:
        # Sessions ingested under cowork-logs/ originate from Cowork (normalised
        # into this dir by ingest_cowork.py); label them source="cowork" so
        # source filters and per-source metadata are correct. They were
        # previously mislabeled "claude" because this loop is shared with the
        # genuine ~/.claude/projects/ scan.
        base_source = "cowork" if project_base == cowork_logs_dir else "claude"
        if not project_base.exists():
            continue

        for project_dir in project_base.iterdir():
            if not project_dir.is_dir():
                continue

            # Skip hook log directories (e.g., -home-nic-writing-aops-hooks)
            if project_dir.name.endswith("-hooks"):
                continue

            project_name = project_dir.name

            # Filter by project if specified
            if project and project.lower() not in project_name.lower():
                continue

            # Find session files (exclude agent-* and *-hooks.jsonl files)
            for session_file in project_dir.glob("*.jsonl"):
                if session_file.name.startswith("agent-"):
                    continue
                if session_file.name.endswith("-hooks.jsonl"):
                    continue

                # Determine session_id
                session_id = session_file.stem
                if session_id == "session" and "cowork-logs" in str(session_file):
                    session_id = project_dir.name[:8]
                    seen_cowork_ids.add(session_id)

                # Get modification time
                mtime = datetime.fromtimestamp(session_file.stat().st_mtime, tz=UTC)

                # Filter by time if specified
                if since and mtime < since:
                    continue

                sessions.append(
                    SessionInfo(
                        path=session_file,
                        project=project_name,
                        session_id=session_id,
                        last_modified=mtime,
                        source=base_source,
                    )
                )

    # 1.5. Find raw Cowork sessions (cross-platform: macOS, Windows, Linux)
    if include_cowork:
        for root in cowork_source_roots():
            if not root.exists():
                continue

            for session_file in root.glob("**/*.jsonl"):
                if session_file.name not in ("session.jsonl", "audit.jsonl"):
                    continue

                parent_name = session_file.parent.name
                conv_dir = (
                    session_file.parent.parent if parent_name == "outputs" else session_file.parent
                )
                dir_name = conv_dir.name

                if not dir_name.startswith("local_"):
                    continue

                # Skip the persistent agent ditto session
                if "local_ditto_" in dir_name:
                    continue

                session_id = dir_name.replace("local_", "")[:8]

                if session_id in seen_cowork_ids:
                    continue

                # Try to get a descriptive project name from the metadata JSON
                # Structure: <root>/<user-uuid>/<org-uuid>/local_<conv-uuid>/...
                # Metadata JSON is sibling to the conv dir: org_dir/local_<conv-uuid>.json
                project_name = "cowork"
                org_dir = conv_dir.parent
                metadata_json = org_dir / f"{dir_name}.json"
                if metadata_json.exists():
                    try:
                        meta = json.loads(metadata_json.read_text())
                        title = meta.get(
                            "title", ""
                        )  # allow-fallback: optional metadata field, empty title keeps default "cowork" name
                        if title:
                            words = title.lower().split()[:3]
                            project_name = "cowork-" + "-".join(w for w in words if w.isalnum())
                    except (OSError, ValueError):
                        pass

                # Filter by project if specified
                if project and project.lower() not in project_name.lower():
                    continue

                mtime = datetime.fromtimestamp(session_file.stat().st_mtime, tz=UTC)

                if since and mtime < since:
                    continue

                seen_cowork_ids.add(session_id)
                sessions.append(
                    SessionInfo(
                        path=session_file,
                        project=project_name,
                        session_id=session_id,
                        last_modified=mtime,
                        source="cowork",
                    )
                )

    # 2. Find Gemini sessions
    if include_gemini:
        # Search both standard location and framework-persisted locations
        search_dirs = [Path.home() / ".gemini" / "tmp", get_sessions_repo()]

        for base_dir in search_dirs:
            if not base_dir.exists():
                continue

            # Gemini structure: ~/.gemini/tmp/{hash}/chats/session-*.{json,jsonl}
            # Or in framework: $AOPS_SESSIONS/**/.gemini/tmp/{slug}/chats/session-*.{json,jsonl}
            for chat_file in itertools.chain(
                base_dir.glob("**/chats/session-*.json"),
                base_dir.glob("**/chats/session-*.jsonl"),
            ):
                # Determine session_id from filename or content
                # session-2026-01-08T08-18-a5234d3e -> a5234d3e
                session_id = chat_file.stem
                if session_id.startswith("session-") and "-" in session_id:
                    session_id = session_id.split("-")[-1]

                # Get project from parent of chats dir (the hash or named dir)
                hash_dir = chat_file.parent.parent.name
                project_name = normalize_gemini_project(hash_dir)

                # Filter by project if specified
                if project and project.lower() not in project_name.lower():
                    continue

                # Get modification time
                mtime = datetime.fromtimestamp(chat_file.stat().st_mtime, tz=UTC)

                # Filter by time if specified
                if since and mtime < since:
                    continue

                sessions.append(
                    SessionInfo(
                        path=chat_file,
                        project=project_name,
                        session_id=session_id,
                        last_modified=mtime,
                        source="gemini",
                    )
                )

    # 3. Find Antigravity / agy brain sessions
    if include_antigravity:
        uuid_to_workspace = _load_agy_workspace_map()

        antigravity_brain_dirs = [
            Path.home() / ".gemini" / "antigravity-cli" / "brain",
            Path.home() / ".gemini" / "antigravity" / "brain",
        ]

        seen_uuids: dict[str, SessionInfo] = {}
        for antigravity_brain_dir in antigravity_brain_dirs:
            if not antigravity_brain_dir.exists():
                continue

            for brain_dir in antigravity_brain_dir.iterdir():
                if not brain_dir.is_dir():
                    continue

                # Older antigravity/IDE sessions store top-level markdown
                # artifacts; the newer antigravity-cli flavour stores a
                # structured transcript under .system_generated/logs/ and no
                # top-level markdown. Accept either as evidence of a session.
                md_files = list(brain_dir.glob("*.md"))
                logs_dir = brain_dir / ".system_generated" / "logs"
                transcript_files = [
                    p
                    for p in (
                        logs_dir / "transcript_full.jsonl",
                        logs_dir / "transcript.jsonl",
                    )
                    if p.exists()
                ]
                if not md_files and not transcript_files:
                    continue

                full_uuid = brain_dir.name
                session_id = full_uuid[:8] if len(full_uuid) > 8 else full_uuid

                workspace = uuid_to_workspace.get(full_uuid)
                if workspace:
                    project_name = Path(workspace).name
                else:
                    project_name = "antigravity"

                if project and project.lower() not in project_name.lower():
                    continue

                mtime = max(
                    datetime.fromtimestamp(f.stat().st_mtime, tz=UTC)
                    for f in (md_files + transcript_files)
                )

                if since and mtime < since:
                    continue

                info = SessionInfo(
                    path=brain_dir,
                    project=project_name,
                    session_id=session_id,
                    last_modified=mtime,
                    source="antigravity",
                )

                if full_uuid in seen_uuids:
                    if mtime > seen_uuids[full_uuid].last_modified:
                        seen_uuids[full_uuid] = info
                else:
                    seen_uuids[full_uuid] = info

        sessions.extend(seen_uuids.values())

    # 4. Find Polecat/Crew sessions
    sessions_repo = get_sessions_repo()
    for category in ["polecats", "crew"]:
        cat_dir = sessions_repo / category
        if cat_dir.exists():
            for worker_dir in cat_dir.iterdir():
                if not worker_dir.is_dir():
                    continue

                # Each worker_dir is either a task-id or a crew-name
                # Use prefix to avoid project name collisions
                worker_project = f"{category.rstrip('s')}-{worker_dir.name}"

                # Filter by project if specified
                if project and project.lower() not in worker_project.lower():
                    continue

                # Claude session directory — mounted via -v ...:/home/worker/.claude/projects
                claude_sessions_dir = worker_dir / "claude-sessions"
                if not claude_sessions_dir.exists():
                    # Fallback: maybe it's directly in the worker_dir?
                    claude_sessions_dir = worker_dir

                # Find session files in both project subdirs and directly in the dir
                # (Support both standard Claude and flat layouts)
                # rglob finds JSONL files at any depth — needed because Claude stores
                # sessions in a -workspace/ subdir one level deeper than Gemini.
                potential_session_files = []
                if claude_sessions_dir.exists():
                    # Check for sessions in project subdirs (recurse to catch -workspace/)
                    for project_dir in claude_sessions_dir.iterdir():
                        if project_dir.is_dir() and not project_dir.name.endswith("-hooks"):
                            potential_session_files.extend(project_dir.rglob("*.jsonl"))
                            potential_session_files.extend(project_dir.rglob("*.json"))
                    # Check for sessions directly in the dir
                    potential_session_files.extend(claude_sessions_dir.glob("*.jsonl"))
                    potential_session_files.extend(claude_sessions_dir.glob("*.json"))

                for session_file in potential_session_files:
                    if (
                        session_file.name.startswith("agent-")
                        or session_file.name.endswith("-hooks.jsonl")
                        or session_file.name.endswith("-hooks.json")
                        or session_file.name.endswith("-claude-session.json")
                        or session_file.name.endswith("-session.json")
                    ):
                        continue

                    # Determine session_id
                    session_id = session_file.stem

                    # Get modification time
                    mtime = datetime.fromtimestamp(session_file.stat().st_mtime, tz=UTC)

                    # Filter by time if specified
                    if since and mtime < since:
                        continue

                    source = "gemini" if session_file.suffix == ".json" else "claude"

                    sessions.append(
                        SessionInfo(
                            path=session_file,
                            project=worker_project,
                            session_id=session_id,
                            last_modified=mtime,
                            source=source,
                        )
                    )

    # 4b. Find GitHub Actions sessions
    # Synced from gh artifacts by sync_gha_sessions.py into:
    #   $AOPS_SESSIONS/github/<repo>/<run_id>/<attempt>/<workspace>/<uuid>.jsonl
    # Including these in batch mode means an offline re-run (e.g. after an
    # extraction-logic change) refreshes GHA summaries alongside everything
    # else, instead of requiring a separate sync_gha_sessions invocation.
    github_root = sessions_repo / "github"
    if github_root.exists():
        for jsonl_file in github_root.rglob("*.jsonl"):
            if jsonl_file.name.endswith("-hooks.jsonl"):
                continue
            if jsonl_file.name.startswith("agent-"):
                continue

            # Project = repo slug (first segment under github/)
            try:
                rel = jsonl_file.relative_to(github_root)
                project_name = rel.parts[0] if rel.parts else "github"
            except ValueError:
                project_name = "github"

            if project and project.lower() not in project_name.lower():
                continue

            session_id = jsonl_file.stem
            mtime = datetime.fromtimestamp(jsonl_file.stat().st_mtime, tz=UTC)
            if since and mtime < since:
                continue

            sessions.append(
                SessionInfo(
                    path=jsonl_file,
                    project=project_name,
                    session_id=session_id,
                    last_modified=mtime,
                    source="claude",
                )
            )

    # Sort by last modified, newest first
    sessions.sort(key=lambda s: s.last_modified, reverse=True)
    return sessions


def get_session_state(session: SessionInfo, aca_data: Path) -> SessionPipelineState:
    """Determine the current processing state of a session.

    Authoritative logic for idempotency and re-processing requirements.
    """

    session_id = session.session_id
    session_prefix = session_id[:8] if len(session_id) >= 8 else session_id

    # 1. Check for Transcript
    # Primary: $AOPS_SESSIONS/transcripts/, fallback: $ACA_DATA/sessions/claude/
    if session.source == "gemini":
        transcript_dirs = [get_transcripts_dir(), aca_data / "sessions" / "gemini"]
    else:
        transcript_dirs = [get_transcripts_dir(), aca_data / "sessions" / "claude"]

    transcript_path = None
    for transcript_dir in transcript_dirs:
        if transcript_dir.exists():
            # Match session ID in both new (v4.0.0: date-HHMM-ID-...) and old (v3.x: date-HH-proj-ID-...) formats.
            # Walks both flat legacy and rotated YYYY-MM/ layouts (aops-b975b185).
            matches = list(iter_rotated_files(transcript_dir, f"*-*-{session_prefix}*-abridged.md"))
            if matches:
                transcript_path = matches[0]
                break

    # Missing transcript or session updated since last transcript
    if not transcript_path:
        return SessionPipelineState.PENDING_TRANSCRIPT

    if session.path.stat().st_mtime > transcript_path.stat().st_mtime:
        return SessionPipelineState.PENDING_TRANSCRIPT

    # 2. Check for Mining JSON (unified session file)
    # Primary: $AOPS_SESSIONS/summaries/, fallback: $ACA_DATA/sessions/summaries/
    has_mining = False
    for insights_dir in (get_summaries_dir(), aca_data / "sessions" / "summaries"):
        if insights_dir.exists():
            # Support various formats (with/without slug, project, hour)
            # Match anything containing the session_prefix and ending in .json.
            # Walks both flat legacy and rotated YYYY-MM/ layouts (aops-b975b185).
            matches = list(iter_rotated_files(insights_dir, f"*{session_prefix}*.json"))
            if matches:
                has_mining = True
                break

    if not has_mining:
        return SessionPipelineState.PENDING_MINING

    return SessionPipelineState.PROCESSED
