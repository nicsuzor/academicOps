"""Session path utilities - single source of truth for session file locations.

This module provides centralized path generation for session files to avoid
circular dependencies and ensure consistent path structure across all components.

Session files are stored in ~/writing/sessions/status/ as YYYYMMDD-HH-sessionID.json
where HH is the 24-hour local time when the session was created.

Scope (vs :mod:`lib.paths`):
    This module owns **per-session runtime artifacts** — the status-JSON,
    hook-log and gate-file paths for one live session, derived from the session
    id + creation time + launch surface (incl. polecat-sandbox redirection).
    Filenames are generated via :mod:`lib.session_naming`; this module decides
    *which directory* those artifacts land in.

    :mod:`lib.paths` owns the **data-repo / plugin-install layout** (plugin
    root, data dir, summaries/transcripts dirs) — locations that are a function
    of install layout, not of any single session.
"""

import os
import sys
from datetime import datetime, timedelta
from pathlib import Path

from lib import session_naming


def _parse_date_arg(date: str | None) -> datetime | None:
    """Parse a date/ISO-8601 string into a datetime, or None to let callers default to now.

    If a date-only string (YYYY-MM-DD) is provided, it defaults the time to the
    current hour/minute to avoid the 00:00 collision in filenames.
    """
    if date is None:
        return None
    try:
        dt = datetime.fromisoformat(date)
        # If it's just a date (no time component), fromisoformat might return
        # a datetime at 00:00:00. We check if time is exactly 00:00:00 and if so,
        # merge with current time to avoid the filename collision.
        if dt.hour == 0 and dt.minute == 0 and dt.second == 0 and len(date) <= 10:
            now = datetime.now().astimezone()
            dt = dt.replace(
                hour=now.hour,
                minute=now.minute,
                second=now.second,
                microsecond=now.microsecond,
                tzinfo=now.tzinfo,
            )
    except ValueError:
        # Fallback for non-ISO formats or other parsing issues
        return None

    # Only attach local timezone for naive datetimes; preserve explicit tz as-is
    return dt if dt.tzinfo is not None else dt.astimezone()


def _is_polecat_sandbox() -> bool:
    """True if running inside a polecat or crew container.

    Reads the resolved operational signal the dispatcher injects
    (``AOPS_POLECAT_CONTAINER``) rather than a self-identifying session-type
    label — the container no longer needs to know "who it is" (aops-b368109a).
    """
    return os.environ.get("AOPS_POLECAT_CONTAINER") == "1"


def _polecat_claude_state_dir(project_folder: str, subsystem: str) -> Path:
    """Return a writable directory for Claude hook/state/gate files inside a polecat container.

    Polecat sets ``HOME=/home/worker`` in the image and ``chmod 777`` on
    ``/home/worker`` so the host-UID worker can write there. After the run,
    polecat extracts ``/home/worker/.claude/projects/`` to the host session
    directory, so writes inside this path land back on the host.

    When ``HOME`` is misconfigured or ``/home/worker`` is unavailable, falls
    back to ``/tmp/aops-<subsystem>-<uid>/<project>/`` — still writable in the
    sandbox, but not extracted to the host.

    Args:
        project_folder: Sanitized Claude project folder name.
        subsystem: ``hooks``, ``state``, or ``gates`` — used only in the /tmp
            fallback path so the three subsystems don't collide.

    Returns:
        Writable directory (created if needed). Never raises.
    """
    container_home = Path("/home/worker")
    if container_home.is_dir() and os.access(container_home, os.W_OK):
        candidate = container_home / ".claude" / "projects" / project_folder
        try:
            candidate.mkdir(parents=True, exist_ok=True)
            return candidate
        except (PermissionError, OSError) as e:
            print(
                f"WARNING: polecat state dir {candidate} inaccessible ({e}); "
                f"falling back to /tmp — data will NOT be extracted to host",
                file=sys.stderr,
            )
    fallback = Path("/tmp") / f"aops-{subsystem}-{os.getuid()}" / project_folder
    fallback.mkdir(parents=True, exist_ok=True)
    return fallback


def get_claude_project_folder() -> str:
    """Get Claude Code project folder name from project directory.

    Uses CLAUDE_PROJECT_DIR env var if set (available during hook execution),
    otherwise falls back to cwd. This is critical for plugin-based hooks that
    run from the plugin cache directory rather than the project directory.

    Converts absolute path to sanitized folder name matching Claude Code's format:
    /home/user/.project -> -home-user-_project

    Claude Code replaces:
    - '/' with '-'
    - '.' with '_'

    Returns:
        Project folder name with leading dash and sanitized characters
    """
    # CLAUDE_PROJECT_DIR is set by Claude Code during hook execution
    # and contains the absolute path to the project root
    project_dir = os.environ.get("CLAUDE_PROJECT_DIR")
    if project_dir:
        project_path = Path(project_dir).resolve()
    else:
        # Fallback for non-hook contexts (e.g., direct script execution)
        project_path = Path.cwd().resolve()
    # Match Claude Code path sanitization: '/' -> '-', '.' -> '_'
    return "-" + str(project_path)[1:].replace("/", "-").replace(".", "_")


def _is_gemini_session(session_id: str | None, transcript_path: str | None = None) -> bool:
    """Detect if this is a Gemini CLI session.

    Detection methods (NO FALLBACKS — a session must definitively declare
    itself; we no longer heuristically match a "gemini-" session-id prefix or a
    polecat ``AOPS_SESSION_STATE_DIR``):
    1. GEMINI_SESSION_ID env var is set (Gemini CLI always provides this)
    2. transcript_path contains "/.gemini/"

    Anything else is NOT treated as Gemini here. The explicit ``--client``
    signal (handled by the caller in ``get_session_status_dir``) is what routes
    a gemini/agy session that lacks these signals; ``AOPS_SESSION_STATE_DIR`` is
    consumed directly by ``get_session_status_dir`` and never needs detection.

    Args:
        session_id: Session ID (unused for detection; kept for the call shape)
        transcript_path: Optional transcript path for Gemini detection

    Returns:
        True if this is a Gemini session
    """
    # Gemini CLI always sets GEMINI_SESSION_ID - most reliable detection
    if os.environ.get("GEMINI_SESSION_ID"):
        return True

    if transcript_path is not None and "/.gemini/" in transcript_path:
        return True

    # NO FALLBACKS: We no longer heuristically match 'gemini-' session IDs or
    # polecat state directories. A session must definitively declare itself.
    return False


def _gemini_workspace_name(cwd: str | None = None) -> str:
    """Resolve Gemini CLI's workspace dir name for the current project.

    Recent Gemini CLI versions store per-project state under
    ``~/.gemini/tmp/<workspace>/`` where ``<workspace>`` is the basename of
    the project directory (not a hash). Earlier versions used ``sha256(cwd)``;
    we no longer compute that fallback because writing to a different dir than
    Gemini itself uses splits artefacts across two locations and pollutes
    ``~/.gemini/tmp/`` with orphan dirs.

    The hook wrapper runs through ``uv --directory <HOOK_DIR>`` which chdirs
    the Python process into the extension directory, so ``os.getcwd()`` is the
    extension dir, not the user's project. ``$PWD`` is preserved across exec
    and so still points at the user's project — that's the value Gemini uses.
    """
    if cwd is None:
        cwd = os.environ.get("PWD") or os.getcwd()
    return Path(cwd).name


def _get_gemini_status_dir(transcript_path: str | None = None) -> Path | None:
    """Get Gemini status directory from GEMINI_SESSION_ID or ANTIGRAVITY_CONVERSATION_ID.

    (Note: transcript_path and AOPS_SESSION_STATE_DIR are now handled natively
    in get_session_status_dir and do not fall through to here).

    Resolution order:
    1. ~/.gemini/tmp/<basename>/ when GEMINI_SESSION_ID is set (Gemini CLI layout).
    2. ~/.gemini/antigravity-cli/brain/<id>/.system_generated/ when
       ANTIGRAVITY_CONVERSATION_ID is set (Antigravity CLI layout).

    Returns the directory or None if not detectable.
    """
    # 1. Derive from cwd basename — matches Gemini CLI's per-project layout.
    if os.environ.get("GEMINI_SESSION_ID"):
        return Path.home() / ".gemini" / "tmp" / _gemini_workspace_name()

    # 2. Antigravity CLI (agy) fallback. AGY sanitizes its environment (stripping
    #    AOPS_SESSION_STATE_DIR) but explicitly preserves ANTIGRAVITY_CONVERSATION_ID.
    conv_id = os.environ.get("ANTIGRAVITY_CONVERSATION_ID")
    if conv_id:
        return Path.home() / ".gemini" / "antigravity-cli" / "brain" / conv_id / ".system_generated"

    return None


def get_gemini_logs_dir(transcript_path: str | None = None) -> Path | None:
    """Get Gemini logs directory from transcript_path.

    Returns the logs/ folder within the Gemini state directory.
    """
    state_dir = _get_gemini_status_dir(transcript_path)
    if state_dir:
        logs_dir = state_dir / "logs"
        logs_dir.mkdir(parents=True, exist_ok=True)
        return logs_dir
    return None


def _env_path_belongs_to_session(env_path: str, session_id: str) -> bool:
    """False only if a pinned env path is a canonical artefact of a DIFFERENT session.

    Pinned paths (``AOPS_HOOK_LOG_PATH``, ``AOPS_GATE_FILE_*``) are set at
    SessionStart and inherited by child processes. A child that is a DIFFERENT
    session (e.g. agy spawned from a Claude session, or a polecat sub-session)
    must not honour the parent's path — it would write into the wrong session's
    log (observed cross-contamination).

    We reject ONLY when the path's filename is a canonical session artefact whose
    short-hash differs from this session. An arbitrary path (explicit operator
    override, test temp file) is honoured as before — this guard narrows behaviour
    to the contamination case only. The session hash is read positionally from the
    canonical ``YYYYMMDD-HHMM-<hash>-...`` prefix, NOT via parse_session_filename,
    so the guard needs no polecat config (it must work in any hook environment).
    """
    parts = Path(env_path).name.split("-")
    is_canonical = (
        len(parts) >= 3
        and len(parts[0]) == 8
        and parts[0].isdigit()  # YYYYMMDD
        and len(parts[1]) == 4
        and parts[1].isdigit()  # HHMM
    )
    if not is_canonical:
        return True  # arbitrary override, honour it
    try:
        short = session_naming.get_session_short_hash(session_id)
    except ValueError:
        return True
    return parts[2] == short


def _find_session_anchor_base(session_id: str, status_dir: Path) -> str | None:
    """Return the canonical base name for ``session_id`` by scanning ``status_dir``.

    Every per-session artefact (state ``.json``, ``-hooks.jsonl``, gate ``.md``)
    must share ONE base name so a session never splits across filenames. The base
    is normally pinned at SessionStart (``AOPS_HOOK_LOG_PATH`` etc.), but agy has
    no SessionStart, and even on Claude the volatile inputs that feed a fresh base
    (cwd-derived repo name, crew, wall-clock minute) can differ between hook
    invocations — e.g. a hook running from the symlinked plugin dir resolves repo
    ``aops-antigravity`` while another resolves ``aops-core``, splitting the
    session across two bases (aops-… #390 fallout).

    This anchor removes that dependency: it discovers the base purely from artefacts
    already on disk for the session's short-hash, matching BOTH state files and hook
    logs (not just state), and chooses **deterministically** — the lexically
    smallest base, i.e. the earliest ``YYYYMMDD-HHMM`` then lexical tiebreak. The
    choice is independent of mtime and of which artefact type was written first, so
    every writer converges on the same base even if a prior run already split it.
    """
    if not status_dir.is_dir():
        return None
    short = session_naming.get_session_short_hash(session_id)
    today = datetime.now().astimezone().strftime("%Y%m%d")
    yesterday = (datetime.now().astimezone() - timedelta(days=1)).strftime("%Y%m%d")

    # Strip a known artefact suffix (variant+ext) to recover the shared base.
    # Done by string-suffix, NOT parse_session_filename, so anchoring never needs
    # the polecat provider set / config (it must work in any environment, incl.
    # bare hooks with no AOPS_SESSIONS). Longest suffix first so "-hooks.jsonl"
    # wins over a bare ".json".
    suffixes = sorted(
        {f"{a['variant']}{a['ext']}" for a in session_naming.ARTIFACT_TYPES.values()},
        key=len,
        reverse=True,
    )

    def _to_base(name: str) -> str | None:
        for suffix in suffixes:
            if suffix and name.endswith(suffix):
                return name[: -len(suffix)]
        return None

    bases: set[str] = set()
    for date_compact in (today, yesterday):
        # Unified format, any artefact type (state .json, -hooks.jsonl, etc.).
        for pattern in (
            f"{date_compact}-????-{short}-*.json",
            f"{date_compact}-????-{short}-*.jsonl",
        ):
            for p in status_dir.glob(pattern):
                if p.name.startswith("aops-"):  # temp/swap files
                    continue
                base = _to_base(p.name)
                if base is not None:
                    bases.add(base)
    if not bases:
        return None
    # Deterministic anchor: smallest base = earliest YYYYMMDD-HHMM, lexical tiebreak.
    return min(bases)


def _canonical_artifact_path(
    session_id: str,
    transcript_path: str | None,
    date: str | None,
    artifact_type: str,
    client_type: str | None = None,
) -> Path:
    """Build a session artefact path anchored on the existing state file.

    All artefacts (state, hooks, gate context) for one session share a single
    base name — this function locates the canonical base via the state file on
    disk and swaps in the requested artefact's variant/extension. If no state
    file exists yet (SessionStart, before save), a fresh filename is generated
    from ``date`` (or ``now``).
    """
    status_dir = get_session_status_dir(session_id, transcript_path, client_type)

    art = session_naming.ARTIFACT_TYPES[artifact_type]

    base = _find_session_anchor_base(session_id, status_dir)
    if base is not None:
        return status_dir / f"{base}{art['variant']}{art['ext']}"

    filename = session_naming.generate_session_filename(
        session_id,
        timestamp=_parse_date_arg(date),
        artifact_type=artifact_type,
        crew_name=session_naming.resolve_crew_name(),
        # Thread the explicit --client signal into the provider component so an
        # agy session's artefacts are named "...-antigravity-..." not
        # "...-claude-..." (aops-7697a478). Authoritative over ambient env.
        provider=session_naming.get_provider_name(client_type=client_type),
        task_id=os.environ.get("AOPS_TASK_ID"),
    )
    return status_dir / filename


def get_hook_log_path(
    session_id: str,
    transcript_path: str | None = None,
    date: str | None = None,
    client_type: str | None = None,
) -> Path:
    """Get the path for the per-session hook log file.

    Layout:
    - Claude: ``~/.claude/projects/<project>/<base>-hooks.jsonl``
    - Gemini: ``~/.gemini/tmp/<workspace>/<base>-hooks.jsonl``

    Resolution order:
    1. ``AOPS_HOOK_LOG_PATH`` env var — but ONLY when it belongs to THIS session
       (its filename carries this session's short-hash). The guard matters because
       the var is inherited by child processes: launching agy from inside a Claude
       session would otherwise make agy's hooks write into the Claude session's log
       (observed cross-contamination). agy has no SessionStart and never sets it.
    2. The on-disk anchor (``_find_session_anchor_base``) — works without any env or
       SessionStart, so agy converges on one file.

    Args:
        session_id: Session ID from Claude Code or Gemini CLI
        transcript_path: Optional transcript path for Gemini detection
        date: Optional date in YYYY-MM-DD format (defaults to today)

    Returns:
        Path to the hook log file
    """
    if env_hook_log_path := os.environ.get("AOPS_HOOK_LOG_PATH"):
        if _env_path_belongs_to_session(env_hook_log_path, session_id):
            return Path(env_hook_log_path)

    return _canonical_artifact_path(session_id, transcript_path, date, "hooks", client_type)


def get_session_status_dir(
    session_id: str | None = None,
    transcript_path: str | None = None,
    client_type: str | None = None,
) -> Path:
    """Get session status directory from AOPS_SESSION_STATE_DIR, transcript_path, or client fallbacks.

    Resolution order (NO silent fallbacks — a session that can't be placed
    raises; it is NEVER guessed into the wrong harness's directory):

    1. ``AOPS_SESSION_STATE_DIR`` env var — set by the router at SessionStart.
    2. ``transcript_path`` — when passed in the JSON payload (Claude Code, Gemini CLI),
       this is immune to environment sanitization. It deterministically anchors the
       status directory adjacent to the client's own session log.
    3. Gemini-family (regular Gemini CLI + Antigravity/agy) environment fallbacks
       like GEMINI_SESSION_ID or ANTIGRAVITY_CONVERSATION_ID.
    4. Claude Code legacy fallback — deriving from cwd.

    Args:
        session_id: Optional session ID for client detection.
        transcript_path: Optional transcript path (highly preferred).
        client_type: Explicit hook-caller identity from ``--client`` ("claude" | "gemini" | "agy").

    Returns:
        Path to session status directory (created if doesn't exist)
    """
    # 1. Prefer explicit env var from router (must be non-empty)
    state_dir = os.environ.get("AOPS_SESSION_STATE_DIR")
    if state_dir:
        status_dir = Path(state_dir)
        status_dir.mkdir(parents=True, exist_ok=True)
        return status_dir

    # 2. Unified transcript-path resolution: put files next to the client's own files
    # This channel is immune to environment sanitization because it comes from the JSON payload.
    if transcript_path:
        tp = Path(transcript_path)
        if client_type in ("gemini", "agy") or _is_gemini_session(session_id, transcript_path):
            status_dir = tp.parent.parent
        else:
            status_dir = tp.parent

        status_dir.mkdir(parents=True, exist_ok=True)
        return status_dir

    # 3. Gemini-family fallback (e.g. SessionStart where transcript_path is not yet set or AGY)
    #    A gemini/agy session MUST resolve to its real ~/.gemini dir or fail loud — it must
    #    NEVER fall through to the Claude branch (NO FALLBACKS, aops-bc8e18c5).
    if client_type in ("gemini", "agy") or _is_gemini_session(session_id, transcript_path):
        gemini_dir = _get_gemini_status_dir(transcript_path)
        if gemini_dir is not None:
            gemini_dir.mkdir(parents=True, exist_ok=True)
            return gemini_dir

        raise ValueError(
            f"Gemini/agy session (client={client_type!r}) but cannot determine status "
            "directory: no AOPS_SESSION_STATE_DIR, no transcript_path, no GEMINI_SESSION_ID, "
            "and no ANTIGRAVITY_CONVERSATION_ID. Refusing to fall back to the Claude project dir."
        )

    # 4. Claude Code session fallback — explicit claude client, or a non-hook caller UUID match
    import re

    is_claude_uuid = bool(
        session_id
        and re.match(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", session_id)
    )
    if client_type == "claude" or (client_type is None and is_claude_uuid):
        project_folder = get_claude_project_folder()
        if _is_polecat_sandbox():
            return _polecat_claude_state_dir(project_folder, "state")
        status_dir = Path.home() / ".claude" / "projects" / project_folder
        status_dir.mkdir(parents=True, exist_ok=True)
        return status_dir

    # 5. Fail loud (NO FALLBACKS)
    raise ValueError(
        f"Could not definitively determine session status directory for session_id "
        f"'{session_id}' (client={client_type!r}). Session did not match Gemini/agy "
        "and did not match Claude. Failing fast per NO-FALLBACKS axiom."
    )


def get_session_file_path(
    session_id: str,
    date: str | None = None,
    transcript_path: str | None = None,
    client_type: str | None = None,
) -> Path:
    """Get session state file path (flat structure).

    Returns: ~/writing/sessions/status/YYYYMMDD-HH-sessionID.json

    Args:
        session_id: Session identifier from AOPS_SESSION_ID
        date: Date in YYYY-MM-DD format or ISO 8601 with timezone (defaults to now local time).
              The hour component is extracted from ISO 8601 dates (e.g., 2026-01-24T17:30:00+10:00).
              For simple YYYY-MM-DD dates, the current hour (local time) is used.
        transcript_path: Optional transcript path for Gemini detection.

    Returns:
        Path to session state file
    """
    # Delegate to the anchor-aware resolver so the state file shares the session's
    # single canonical base. Previously this generated a FRESH name every call from
    # volatile inputs (cwd-derived repo name via get_repo_name, crew, wall-clock
    # minute) — so when a later hook ran from a different cwd the repo flipped
    # (e.g. aops-core ↔ aops-antigravity) and SessionState.save() wrote a SECOND
    # state file, splitting the session. Anchoring reuses the first base instead.
    return _canonical_artifact_path(session_id, transcript_path, date, "insights", client_type)


def get_session_directory(
    session_id: str, date: str | None = None, base_dir: Path | None = None
) -> Path:
    """Get session directory path (single source of truth).

    Returns: ~/writing/sessions/status/ (centralized flat directory)

    NOTE: This function now returns the centralized status directory.
    Session files are named YYYYMMDD-HH-sessionID.json directly in this directory.
    The base_dir parameter is preserved for test isolation only.

    Args:
        session_id: Session identifier from AOPS_SESSION_ID
        date: Date in YYYY-MM-DD or ISO 8601 format (defaults to now local time)
        base_dir: Override base directory (primarily for test isolation)

    Returns:
        Path to session directory (created if doesn't exist)

    Examples:
        >>> get_session_directory("abc123")
        PosixPath('/home/user/writing/sessions/status')
    """
    if base_dir is not None:
        # Test isolation mode - use old structure for compatibility
        # We use get_session_filename without suffix to get the folder name
        folder_name = session_naming.get_session_filename(session_id, date=date, suffix="")
        project_folder = get_claude_project_folder()
        session_dir = base_dir / project_folder / folder_name
        session_dir.mkdir(parents=True, exist_ok=True)
        return session_dir

    # Production mode - use centralized status directory
    return get_session_status_dir(session_id)


def find_recent_hooks_logs(n: int) -> list[Path]:
    """Find the N most recent hooks log files across all Claude projects.

    Skips test fixtures (paths containing 'pytest' or '/tmp-tmp').
    Returns paths sorted by modification time, most recent first.

    Args:
        n: Maximum number of log paths to return

    Returns:
        List of up to n Path objects to hooks JSONL files
    """
    claude_projects = Path.home() / ".claude" / "projects"
    if not claude_projects.exists():
        return []

    hooks_logs: list[tuple[float, Path]] = []
    for log_path in claude_projects.rglob("*-hooks.jsonl"):
        if "pytest" in str(log_path) or "/tmp-tmp" in str(log_path):
            continue
        try:
            mtime = log_path.stat().st_mtime
            hooks_logs.append((mtime, log_path))
        except OSError:
            continue

    hooks_logs.sort(key=lambda x: x[0], reverse=True)
    return [path for _, path in hooks_logs[:n]]


GATE_NAMES = ("exit_reflection", "hydration", "ida")


def get_gate_file_path(
    gate: str,
    session_id: str,
    transcript_path: str | None = None,
    date: str | None = None,
    client_type: str | None = None,
) -> Path:
    """Get the path for a gate context file.

    Writes to the same directory as hook log files:
    - Claude: ~/.claude/projects/<project>/YYYYMMDD-HH-<shorthash>-<gate>.md
    - Gemini: ~/.gemini/tmp/<hash>/logs/YYYYMMDD-HH-<shorthash>-<gate>.md

    Checks AOPS_GATE_FILE_<GATE> env var first for session-stable path.

    Args:
        gate: Gate name (exit_reflection, hydration, ida)
        session_id: Session ID from Claude Code or Gemini CLI
        transcript_path: Optional transcript path for Gemini detection
        date: Optional date in YYYY-MM-DD format (defaults to today)

    Returns:
        Path to the gate context file
    """
    env_var = f"AOPS_GATE_FILE_{gate.upper()}"
    if env_path := os.environ.get(env_var):
        # Honour the pinned path only when it names THIS session (the var is
        # inherited by child processes — a different session must not reuse it).
        if _env_path_belongs_to_session(env_path, session_id):
            return Path(env_path)

    # Anchor on any existing artefact so all files share one base name.
    status_dir = get_session_status_dir(session_id, transcript_path, client_type)
    base = _find_session_anchor_base(session_id, status_dir)
    if base is not None:
        return status_dir / f"{base}-{gate}.md"

    # SessionStart fallback: build a fresh base before any artefact exists.
    base = session_naming.generate_base_name(
        session_id,
        timestamp=_parse_date_arg(date),
        slug="session",
        crew_name=session_naming.resolve_crew_name(),
        task_id=os.environ.get("AOPS_TASK_ID"),
    )
    return status_dir / f"{base}-{gate}.md"


def get_all_gate_file_paths(
    session_id: str,
    transcript_path: str | None = None,
    date: str | None = None,
    client_type: str | None = None,
) -> dict[str, Path]:
    """Get paths for all gate context files.

    Returns:
        Dict mapping gate name to file path
    """
    return {
        gate: get_gate_file_path(gate, session_id, transcript_path, date, client_type)
        for gate in GATE_NAMES
    }


def get_pid_session_map_path() -> Path:
    """Get path for PID -> SessionID mapping file.

    Used by router to bootstrap session ID from process ID when not provided.
    Stores simple JSON: {"session_id": "..."}
    """
    # PID session maps are ephemeral runtime files, always use /tmp
    return Path("/tmp") / f"session-{os.getppid()}.json"


def cowork_source_roots() -> list[Path]:
    """Get cross-platform paths for raw Cowork (Claude Desktop) session roots."""
    roots = []
    if sys.platform == "darwin":
        roots.append(
            Path.home() / "Library" / "Application Support" / "Claude" / "local-agent-mode-sessions"
        )
    elif sys.platform == "win32":
        appdata = os.environ.get("APPDATA")
        if appdata:
            roots.append(Path(appdata) / "Claude" / "local-agent-mode-sessions")
    else:
        roots.append(Path.home() / ".config" / "Claude" / "local-agent-mode-sessions")
    return roots
