"""Shared utilities for hook implementations.

Provides DRY infrastructure for:
- Temp file management (unified temp directory, write, cleanup)
- Session ID extraction
- Subagent detection
- Hook output formatting

All gates should use these utilities instead of duplicating code.
"""

from __future__ import annotations

import os
from typing import Any, TypedDict


class HookOutput(TypedDict, total=False):
    """Standard hook output format."""

    hookSpecificOutput: dict[str, Any]


def get_session_id(input_data: dict[str, Any] | None = None) -> str:
    """Get session ID from hook input data or environment.

    Args:
        input_data: Hook input data dict

    Returns:
        Session ID string, or empty string if not found and not required

    Raises:
        ValueError: If require=True and session_id not found
    """
    session_id = None
    if input_data:
        session_id = input_data.get("session_id")
    if not session_id:
        session_id = os.environ.get("AOPS_SESSION_ID")
    if not session_id:
        raise ValueError(
            "session_id is required in hook input_data or AOPS_SESSION_ID env var. "
            "If you're seeing this error, the hook invocation is missing required context."
        )
    return session_id


import re

# Claude Code subagent IDs are short lowercase hex strings (e.g., aafdeee, adc71f1).
# This pattern matches them without false-positiving on UUIDs, Gemini session IDs,
# or other formats that contain hyphens, timestamps, or non-hex characters.
_SUBAGENT_ID_RE = re.compile(r"^[0-9a-f]{5,16}$")


def is_subagent_session(input_data: dict[str, Any] | None = None) -> bool:
    """Check if this is a subagent session.

    Uses multiple detection methods since env vars may not be passed to hook subprocesses:
    0. Explicit 'is_subagent' flag in input_data
    0a. Gemini 'is_sidechain' or 'isSidechain' flags in input_data
    1. CLAUDE_SUBAGENT_TYPE env var
    2. Session ID is a short hex string (subagent IDs like aafdeee vs main session UUIDs)
    3. agent_id/agent_type fields in hook payload
    4. Transcript path contains /subagents/ or /agent-
    5. Parent session ID is present

    Args:
        input_data: Hook input data containing session_id, transcript_path, etc.

    Returns:
        True if this appears to be a subagent session
    """
    if input_data and (
        input_data.get("is_subagent")
        or input_data.get("is_sidechain")
        or input_data.get("isSidechain")
    ):
        return True

    # Method 1: Check for agent_id/agent_type fields in hook payload.
    if input_data:
        if input_data.get("agent_id") or input_data.get("agentId"):
            return True
        if input_data.get("agent_type") or input_data.get("agentType"):
            return True

    # Method 2: Check if session_id matches the short hex format of subagent IDs.
    # Main sessions use full UUIDs (e.g., f4e3f1cb-775c-4aaf-8bf6-4e18a18dad3d).
    # Subagent sessions use short hex IDs (e.g., aafdeee, adc71f1).
    try:
        session_id = get_session_id(input_data)
        if _SUBAGENT_ID_RE.match(session_id):
            return True
    except ValueError:
        pass

    # Method 3: Env vars (check all known variants).
    # CLAUDE_AGENT_TYPE is deliberately NOT checked here: it is set by the
    # `--agent` flag / settings.json "agent" key to select a TOP-LEVEL
    # session's persona (e.g. ~/junior/.claude/settings.json "agent":
    # "aops-core:junior"), not to signal that the current process is a
    # spawned subagent. Treating it as subagent evidence misclassified
    # whole interactive head sessions as subagents, which fail-silently
    # suppressed gate evaluation for their entire lifetime (aops_571771b4,
    # issue #2182). CLAUDE_SUBAGENT_TYPE is a distinct, subagent-specific
    # signal and is still honored.
    if os.environ.get("CLAUDE_SUBAGENT_TYPE"):
        return True
    if os.environ.get("CLAUDE_PARENT_SESSION_ID"):
        return True

    # Method 4: Check transcript path or CWD for /subagents/ directory
    # Also check actual CWD as fallback since subagents run in dedicated dirs
    paths_to_check = []

    if input_data:
        paths_to_check.append(str(input_data.get("transcript_path", "")))
        paths_to_check.append(str(input_data.get("cwd", "")))

    # Fallback to current process CWD (hooks run in subagent context)
    try:
        paths_to_check.append(os.getcwd())
    except OSError:
        # Best-effort CWD detection; if the working directory is missing or
        # inaccessible, we can safely continue without adding it.
        pass

    for path in paths_to_check:
        if not path:
            continue
        if "/subagents/" in path:
            return True
        if "/agent-" in path:
            return True

    return False


# ============================================================================
# Hook Output Helpers
# ============================================================================


def make_deny_output(
    message: str,
    event_name: str = "PreToolUse",
) -> HookOutput:
    """Build JSON output for deny/block decision.

    Args:
        message: Block message to display
        event_name: Hook event name (default: "PreToolUse")

    Returns:
        Hook output dict with permissionDecision: deny
    """
    return {
        "hookSpecificOutput": {
            "hookEventName": event_name,
            "permissionDecision": "deny",
            "additionalContext": message,
        }
    }


def make_allow_output(
    message: str = "",
    event_name: str = "PreToolUse",
) -> HookOutput:
    """Build JSON output for allow with optional context.

    Args:
        message: Optional context message
        event_name: Hook event name (default: "PreToolUse")

    Returns:
        Hook output dict with permissionDecision: allow
    """
    if not message:
        return {}

    return {
        "hookSpecificOutput": {
            "hookEventName": event_name,
            "permissionDecision": "allow",
            "additionalContext": message,
        }
    }


def make_context_output(
    message: str,
    event_name: str = "PostToolUse",
    wrap_in_reminder: bool = True,
) -> HookOutput:
    """Build JSON output for injecting context (no permission decision).

    Args:
        message: Context message to inject
        event_name: Hook event name (default: "PostToolUse")
        wrap_in_reminder: If True, wrap message in <system-reminder> tags

    Returns:
        Hook output dict with additionalContext
    """
    if wrap_in_reminder:
        message = f"<system-reminder>\n{message}\n</system-reminder>"

    return {
        "hookSpecificOutput": {
            "hookEventName": event_name,
            "additionalContext": message,
        }
    }


def make_empty_output() -> dict:
    """Return empty output dict (allow without context).

    Returns:
        Empty dict {} which signals allow
    """
    return {}


# ============================================================================
# Task ID Extraction
# ============================================================================


def get_task_id_from_result(tool_result: dict[str, Any]) -> str | None:
    """Extract task_id from MCP tool result.

    Supports both Claude and Gemini response formats:
    - Claude: {"success": true, "task": {"id": "..."}}
    - Gemini: {"returnDisplay": '{"task": {"id": "..."}}'} (JSON in string)

    Args:
        tool_result: The tool_result dict from hook input

    Returns:
        Task ID string or None if not found
    """
    import json as _json

    # Handle Gemini tool_response structure (JSON in returnDisplay string)
    if "returnDisplay" in tool_result:
        try:
            content = tool_result["returnDisplay"]
            if isinstance(content, str):
                data = _json.loads(content)
                return data.get("task", {}).get("id")
        except (_json.JSONDecodeError, TypeError):
            pass

    # MCP task tools return {"success": true, "task": {"id": "...", ...}}
    task = tool_result.get("task", {})
    return task.get("id")
