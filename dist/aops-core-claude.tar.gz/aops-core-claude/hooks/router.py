#!/usr/bin/env -S uv run python
"""
Universal Hook Router.

Handles hook events from Claude Code and Antigravity (agy).
Consolidates multiple hooks per event into a single invocation.

Architecture:
- Loads Pydantic SessionState object at start.
- Passes SessionState to all gates via gate_registry.
- Saves SessionState at end.
- GateResult objects used internally, converted to JSON only at final output.
"""

import json
import os
import sys
import tempfile
import uuid
from collections import deque
from datetime import datetime
from pathlib import Path
from typing import Any

# --- Path Setup ---
HOOK_DIR = Path(__file__).parent  # aops-core/hooks
AOPS_CORE_DIR = HOOK_DIR.parent  # aops-core

# Force the plugin's OWN lib/hooks to the FRONT of sys.path so they always win,
# even when a *stale* aops-core copy is on PYTHONPATH (e.g. another client's
# plugin cache) or `uv run` already injected the project root at a low-priority
# position. A plain "insert only if absent" guard is insufficient: on the
# cold-start fallback path `uv run` adds the project root behind the PYTHONPATH
# entry, the guard then skips the insert, and the stale copy shadows our `lib` —
# loading an old session_naming and crashing the first PreToolUse (aops-7697a478).
_core_path = str(AOPS_CORE_DIR)
sys.path = [_core_path] + [p for p in sys.path if p != _core_path]

try:
    import lib.session_naming as session_naming
    from lib.gate_model import GateResult, GateVerdict
    from lib.gates.engine import GenericGate
    from lib.gates.registry import GateRegistry
    from lib.hook_context import HookContext
    from lib.hook_utils import is_subagent_session
    from lib.session_naming import get_session_short_hash
    from lib.session_paths import get_pid_session_map_path
    from lib.session_state import SessionState
    from lib.tool_categories import extract_subagent_type

    from hooks import client_spec
    from hooks.schemas import (
        CanonicalHookOutput,
        ClaudeGeneralHookOutput,
        ClaudeHookSpecificOutput,
        ClaudeStopHookOutput,
        ResolvedDecision,
    )
    from hooks.unified_logger import log_hook_event
except ImportError as e:
    # Fail fast if schemas missing
    print(f"CRITICAL: Failed to import: {e}", file=sys.stderr)
    sys.exit(1)


# --- Configuration ---

DEBUG_LOG_DIR = Path("/tmp")

# Claude Code only accepts hookSpecificOutput for these events. Emitting it for
# other events causes the entire payload to be rejected.
_CLAUDE_HSO_EVENTS = {"PreToolUse", "UserPromptSubmit", "PostToolUse", "PostToolBatch"}

# Pause detection (Claude Code 2.1.145+ `background_tasks` / `session_crons`).
# A session that yields while waiting on backgrounded work is NOT claiming
# "done", so its exit gates (exit_reflection/ida) are suppressed — see
# _dispatch_gates and specs/ENFORCEMENT-MAP.md.
#
# Both sets are ALLOWLISTS so the gate fails SAFE (fires) on anything unknown —
# suppressing a compliance chokepoint on an unrecognized value is the dangerous
# direction. `shell` tasks run inline and do NOT wake the session, so they are
# deliberately excluded from the waking set. Enumerated against real captured
# hook payloads (8107 background_tasks items across 8650 Stop payloads): the
# only observed types were {shell, subagent, workflow} and the only observed
# status was "running" — Claude Code prunes terminal tasks before emitting the
# array. Requiring an active status guards the latent fail-open where a
# completed/failed task lingers and silently disarms the exit gates. When a new
# waking type or active status is genuinely observed in the wild, add it here.
_WAKING_TASK_TYPES = {"subagent", "workflow", "monitor"}
_ACTIVE_TASK_STATUSES = {"running"}


def _clean_advisory(text: str | None) -> str | None:
    """None-safe whitespace trim for advisory / reason text.

    The legacy `<SYSTEM HOOK INSTRUCTION>` marker scaffold was removed
    2026-06-27 (see lib/gates/engine.py): it meant nothing to Claude Code, read
    as a smuggled system instruction, and risked tripping the client's own
    hook-injection rejection. Advisory text now stands on its own, so there is
    nothing to strip but surrounding whitespace.
    """
    return text.strip() if text else text


def _debug_log_path(session_id: str | None) -> Path:
    """Return per-session debug log path.

    DEBUG_HOOKS=1 raw-input dump. Lives next to the session state file in
    ``$AOPS_SESSION_STATE_DIR`` (per-provider tmp dir) — never in
    ``$AOPS_SESSIONS``, which is reserved for parsed transcripts/summaries
    that get committed and synced.
    """
    slug = session_id if session_id else "unknown"
    state_dir = os.environ.get("AOPS_SESSION_STATE_DIR")
    if state_dir:
        log_dir = Path(state_dir)
        log_dir.mkdir(parents=True, exist_ok=True)
        return log_dir / f"cc_hooks_{slug}.jsonl"
    return DEBUG_LOG_DIR / f"cc_hooks_{slug}.jsonl"


def _debug_log_input(raw_input: dict[str, Any], args: Any) -> None:
    """Append raw hook input to debug JSONL file if DEBUG_HOOKS=1."""
    if not os.environ.get("DEBUG_HOOKS"):
        return
    try:
        session_id = raw_input.get("session_id") or os.environ.get("AOPS_SESSION_ID")
        entry = {
            "ts": datetime.now().isoformat(),
            "session_id": session_id,
            "client": getattr(args, "client", None),
            "event": getattr(args, "event", None),
            "input": raw_input,
            "environ": dict(os.environ),
        }
        with _debug_log_path(session_id).open("a") as f:
            f.write(json.dumps(entry) + "\n")
    except Exception as e:
        print(f"DEBUG_LOG error: {e}", file=sys.stderr)


# Inbound wire-event → internal canonical name mapping is the SSoT's job:
# ``client_spec.to_internal_event(client, wire)`` (Table 1 of
# specs/hooks/CLIENT-TRANSLATION.md). normalize_input() calls it with the
# resolved ``--client``; the per-client map replaces the old flat
# ``GEMINI_EVENT_MAP`` union (which recognised every client's names regardless
# of caller). Production always supplies ``--client`` (main() raises otherwise),
# so the per-client lookup is exact; only legacy/test callers pass no client and
# fall back to identity.

# --- Gate Status Display ---


def format_gate_status_icons(state: SessionState) -> str:
    """Format current gate statuses as a lifecycle-aware icon strip.

    Only shows gates when they need attention:
    - ≡    exit-reflection complete (gate OPEN + sticky — a legal exit fired
           this turn: auditor ran, honest release_task, or /end-session/
           /dump/continue)
    - ▶ T-id  active task bound
    - ✓    nothing needs attention

    The former RBG countdown icon (◇ N / ◇ overdue) tracked the turn-based
    `rbg` PreToolUse counter — retired entirely (aops_4c2949d9, nothing fires
    mid-session on any surface any more); there is no replacement icon for it.
    """
    parts: list[str] = []

    # exit_reflection: show ≡ while sticky-open (a legal exit fired this
    # turn) but not yet re-armed — mirrors the retired handover gate's icon.
    exit_reflection = state.gates.get("exit_reflection")
    if exit_reflection and exit_reflection.status == "open" and exit_reflection.sticky:
        parts.append("≡")

    # Active task
    if state.main_agent.current_task:
        parts.append(f"▶ {state.main_agent.current_task}")

    return " ".join(parts) if parts else ""


# --- Session Management ---


def get_parent_pid(pid: int) -> int | None:
    """Get parent PID cross-platform (supports Linux and macOS)."""
    try:
        import sys

        if sys.platform == "darwin":
            import subprocess

            output = subprocess.check_output(
                ["ps", "-o", "ppid=", "-p", str(pid)], encoding="utf-8"
            )
            return int(output.strip())
        else:
            with open(f"/proc/{pid}/stat") as f:
                return int(f.read().split()[3])
    except Exception:
        return None


def get_session_data() -> dict[str, Any]:
    """Read session metadata, traversing up process tree if necessary."""
    try:
        # Try direct PPID first (fast path)
        session_file = get_pid_session_map_path()
        if session_file.exists():
            return json.loads(session_file.read_text().strip())

        # Fallback: walk up process tree
        pid = os.getppid()
        while pid and pid > 1:
            session_file = Path("/tmp") / f"session-{pid}.json"
            if session_file.exists():
                try:
                    data = json.loads(session_file.read_text().strip())
                    if data:
                        return data
                except json.JSONDecodeError:
                    pass
            pid = get_parent_pid(pid)
    except Exception as e:
        print(f"WARNING: Failed to read session data: {e}", file=sys.stderr)
    return {}


def persist_session_data(data: dict[str, Any]) -> None:
    """Write session metadata atomically."""
    try:
        session_file = get_pid_session_map_path()
        existing = get_session_data()
        existing.update(data)

        # Atomic write
        fd, temp_path = tempfile.mkstemp(dir=str(session_file.parent), text=True)
        try:
            with os.fdopen(fd, "w") as f:
                json.dump(existing, f)
            Path(temp_path).rename(session_file)
        except Exception as e:
            Path(temp_path).unlink(missing_ok=True)
            print(f"CRITICAL: Failed to persist session data: {e}", file=sys.stderr)
            raise
    except OSError as e:
        print(f"WARNING: OSError in persist_session_data: {e}", file=sys.stderr)


# --- Router Logic ---


class HookRouter:
    def __init__(self):
        self.session_data = get_session_data()
        self._execution_timestamps = deque(maxlen=20)  # Store last 20 timestamps

    @staticmethod
    def _normalize_json_field(value: Any) -> Any:
        """Normalize a field that may be a JSON string to its parsed form."""
        if isinstance(value, str):
            try:
                return json.loads(value)
            except json.JSONDecodeError:
                return value
        return value

    def normalize_input(
        self,
        raw_input: dict[str, Any],
        cli_event: str | None = None,
        client_type: str | None = None,
    ) -> HookContext:
        """Create a normalized HookContext from raw input.

        Args:
            raw_input: The raw stdin payload from the hook caller.
            cli_event: Event name when invoked with the event as a positional
                arg rather than in stdin (e.g. agy).
            client_type: Hook caller identity ("claude" or "agy"), normally
                taken from the ``--client`` flag. Stored on the resulting
                HookContext so JSONL log entries can distinguish callers
                instead of showing ``model=unknown``.
        """

        # 1. Determine Event Name — resolved through the client_spec SSoT.
        # agy passes the wire event positionally (cli_event); it may also
        # carry it in stdin as hook_event_name. The per-client inbound map
        # turns the wire name into the internal canonical name (Claude is
        # identity). to_internal_event falls back to identity for an unmapped
        # wire name or a missing client, matching the prior union's behaviour.
        raw_event = cli_event or raw_input.get("hook_event_name")
        wire_event = raw_event or ""  # allow-fallback: identity for an absent event name
        client = client_type or ""  # allow-fallback: identity map when no --client (test/legacy)
        hook_event = client_spec.to_internal_event(client, wire_event)

        # 2. Determine Session ID
        session_id = raw_input.get("session_id") or raw_input.get("conversationId")
        if not session_id:
            session_id = self.session_data.get("session_id") or os.environ.get("AOPS_SESSION_ID")

        if not session_id and hook_event == "SessionStart":
            timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            short_uuid = str(uuid.uuid4())[:8]
            session_id = f"{client or 'unknown'}-{timestamp}-{short_uuid}"

        if not session_id:
            session_id = f"unknown-{str(uuid.uuid4())[:8]}"

        # 3. Determine Agent ID and Subagent Type
        # Check both payload and persisted session data (for subagent tool calls)
        agent_id = (
            raw_input.get("agent_id")
            or raw_input.get("agentId")
            or self.session_data.get("agent_id")
        )
        subagent_type = (
            raw_input.get("subagent_type")
            or raw_input.get("agent_type")
            or self.session_data.get("subagent_type")
        )

        # Prefer explicit env var if set
        if not subagent_type:
            subagent_type = os.environ.get("CLAUDE_SUBAGENT_TYPE")

        # 4. Transcript Path / Temp Root
        transcript_path = raw_input.get("transcript_path") or raw_input.get("transcriptPath")

        # Request Tracing (aops-32068a2e)
        trace_id = raw_input.get("trace_id") or str(uuid.uuid4())

        # 5. Tool Data
        tool_name = raw_input.get("tool_name")
        raw_ti = raw_input.get("tool_input", {})  # allow-fallback: type-coerced below

        # Antigravity (agy) hook compatibility: tool details ride in a `toolCall`
        # object. The REAL agy 1.0.7 Pre/PostToolUse payload places it at the
        # ROOT of the stdin object — `{"stepIdx":N,"toolCall":{"name":...,
        # "args":{...}},"workspacePaths":[...]}` (#1800; verified against the live
        # hook log for session 6d3d5783). The earlier double-nested
        # `raw_input.raw_input.toolCall` lookup never matched, so ctx.tool_name was
        # None on every agy tool event, defeating rbg/handover
        # tool-name matching. Prefer the root-level object; keep the nested form as
        # a defensive fallback for any wrapper that re-nests the payload.
        if not tool_name:
            tool_call = raw_input.get("toolCall")
            if not isinstance(tool_call, dict):
                nested_raw = raw_input.get("raw_input")
                tool_call = nested_raw.get("toolCall") if isinstance(nested_raw, dict) else None
            if isinstance(tool_call, dict):
                tool_name = tool_call.get("name") or tool_name
                raw_ti = tool_call.get("args") or raw_ti

        tool_input = self._normalize_json_field(raw_ti)
        if not isinstance(tool_input, dict):
            tool_input = {}

        # Normalize tool_result and toolResult in raw_input (for PostToolUse/SubagentStop)
        tool_output = {}
        raw_tool_output = (
            raw_input.get("tool_result")
            or raw_input.get("toolResult")
            or raw_input.get("tool_response")
            or raw_input.get("subagent_result")
        )

        # Antigravity (agy) hook compatibility: the real agy 1.0.7 PostToolUse
        # payload conveys the tool result at the ROOT of the stdin object — there
        # is no separate result envelope; success/failure rides in the root-level
        # `error` string (empty on success) alongside the root `toolCall` (#1800,
        # same live-log mechanism as the tool_name fix above). Mirror the
        # root-first / nested-fallback order used for `toolCall`.
        if not raw_tool_output:
            raw_tool_output = (
                raw_input.get("toolResult")
                or raw_input.get("tool_response")
                or raw_input.get("subagent_result")
                or raw_input.get("error")
            )
        if not raw_tool_output:
            nested_raw = raw_input.get("raw_input")
            if isinstance(nested_raw, dict):
                raw_tool_output = (
                    nested_raw.get("tool_result")
                    or nested_raw.get("toolResult")
                    or nested_raw.get("tool_response")
                    or nested_raw.get("subagent_result")
                )

        if raw_tool_output:
            tool_output = self._normalize_json_field(raw_tool_output)

        # 6. Extract subagent_type from spawning tools
        # Uses the SPAWN_TOOLS table in gate_config for cross-platform detection
        # (Claude Task/Skill, Gemini delegate_to_agent/activate_skill, extensible
        # to Codex/Copilot). _subagent_type_from_skill prevents Skill invocations
        # from being misclassified as subagent sessions.
        _subagent_type_from_spawn_tool = False
        _subagent_type_from_skill = False
        if not subagent_type:
            extracted, is_skill = extract_subagent_type(tool_name, tool_input)
            if extracted:
                subagent_type = extracted
                _subagent_type_from_skill = is_skill
                _subagent_type_from_spawn_tool = not is_skill

        # 7. Detect Subagent Session
        # Call is_subagent_session BEFORE popping fields from raw_input
        is_subagent = is_subagent_session(raw_input)

        # If we have subagent info from PID map or explicit flags, treat as subagent.
        # Skip the override for:
        #  - Skill/activate_skill calls (run in main session)
        #  - Spawn tool calls like Agent(...) (main session dispatching a subagent)
        #  - SubagentStart/SubagentStop events (main session events about subagents)
        if (
            not is_subagent
            and not _subagent_type_from_skill
            and not _subagent_type_from_spawn_tool
            and (
                subagent_type
                or agent_id
                or raw_input.get("is_sidechain")
                or raw_input.get("isSidechain")
            )
        ):
            is_subagent = True

        # SubagentStart/SubagentStop fire in the MAIN agent's context ABOUT a
        # subagent. They carry agent_id/agent_type metadata which causes false
        # positives above. Override: these are never subagent events.
        if hook_event in ("SubagentStart", "SubagentStop"):
            is_subagent = False

        # Worker gate posture for polecat-launched agy headless sessions
        # (aops-7781ab3c). An agy worker dispatched by `polecat run --model
        # antigravity` is an autonomous task session that cannot respond to
        # interactive compliance gate prompts (e.g. dispatch rbg mid-run).
        # Classify it as a subagent so _dispatch_gates skips PreToolUse gate
        # evaluation — the same worker posture Claude Code polecat task workers
        # get. Stop/PostInvocation (both mapped to hook_event="Stop") remain
        # exempt from the subagent skip, so the handover gate can still fire.
        # AOPS_AGY_CLIENT=1 is set explicitly by polecat/cli.py when launching
        # an agy worker container — it is NOT present in other polecat workers'
        # environments, so it never bleeds into test subprocesses.
        if client_type == "agy" and os.environ.get("AOPS_AGY_CLIENT") == "1":
            is_subagent = True

        # 8. Persist session data on session start only (not subagent start, as multiple
        # subagents may run simultaneously and would clobber each other's entries)
        if hook_event == "SessionStart":
            persist_session_data(
                {"session_id": session_id, "agent_id": agent_id, "subagent_type": subagent_type}
            )

        # 9. Precompute values
        short_hash = get_session_short_hash(session_id)

        # 10. Metadata (aops-d9ba7159)
        machine = session_naming.get_machine_name()
        repo = session_naming.get_repo_name()
        crew = session_naming.resolve_crew_name()
        provider = session_naming.get_provider_name(client_type=client_type)
        task_id = os.environ.get("AOPS_TASK_ID")

        # 10b. Pause detection (Claude Code 2.1.145+). A session is "paused" —
        # yielding while it waits to be woken — if it has any pending cron, or a
        # waking background task in an active state. `.get(..., [])` degrades to
        # False on older Claude Code and on agy/Gemini (which carry neither
        # field), so this is a no-op there. See _WAKING_TASK_TYPES /
        # _ACTIVE_TASK_STATUSES for the fail-safe allowlist rationale.
        background_tasks = raw_input.get(
            "background_tasks", []
        )  # allow-fallback: optional Claude Code 2.1.145+ field
        session_crons = raw_input.get(
            "session_crons", []
        )  # allow-fallback: optional Claude Code 2.1.145+ field
        # Coerce a malformed (non-list) value to [] so a bad optional field can
        # never crash the Stop hot-path — is_paused stays False (gates fire).
        if not isinstance(background_tasks, list):
            background_tasks = []
        if not isinstance(session_crons, list):
            session_crons = []
        is_paused = False
        if session_crons:
            is_paused = True
        else:
            for task in background_tasks:
                # Skip malformed items defensively — a non-dict entry must never
                # crash the Stop hot-path nor silently suppress a compliance gate.
                if not isinstance(task, dict):
                    continue
                if (
                    task.get("type") in _WAKING_TASK_TYPES
                    and task.get("status") in _ACTIVE_TASK_STATUSES
                ):
                    is_paused = True
                    break

        # 11. Build Context and POP processed fields from raw_input
        # We pop now so the remainder in ctx.raw_input is "extra" data
        processed_fields = [
            "hook_event_name",
            "session_id",
            "conversationId",
            "transcript_path",
            "transcriptPath",
            "artifact_directory_path",
            "artifactDirectoryPath",
            "trace_id",
            "tool_name",
            "tool_input",
            "tool_result",
            "toolResult",
            "tool_response",
            "subagent_result",
            "agent_id",
            "agentId",
            "slug",
            "cwd",
            "is_sidechain",
            "isSidechain",
            "subagent_type",
            "agent_type",
            "background_tasks",
            "session_crons",
        ]
        slug = raw_input.get("slug")
        cwd = raw_input.get("cwd")

        for field in processed_fields:
            raw_input.pop(field, None)

        return HookContext(
            session_id=session_id,
            trace_id=trace_id,
            hook_event=hook_event,
            agent_id=agent_id,
            slug=slug,
            client_type=client_type,
            is_subagent=is_subagent,
            subagent_type=subagent_type,
            background_tasks=background_tasks,
            session_crons=session_crons,
            is_paused=is_paused,
            # Metadata (aops-d9ba7159)
            machine=machine,
            provider=provider,
            crew=crew,
            repo=repo,
            task_id=task_id,
            # Precomputed values
            session_short_hash=short_hash,
            # Event Data
            tool_name=tool_name,
            tool_input=tool_input,
            tool_output=tool_output,
            transcript_path=transcript_path,
            cwd=cwd,
            raw_input=raw_input,
        )

    @staticmethod
    def _is_task_notification(ctx: HookContext) -> bool:
        """Detect task-notification prompts (background task completions).

        These are internal Claude Code plumbing, not real user input.
        The prompt field contains <task-notification>...</task-notification>.
        """
        prompt = ctx.raw_input.get("prompt", "")  # allow-fallback: empty cannot match prefix
        return isinstance(prompt, str) and prompt.lstrip().startswith("<task-notification>")

    def _run_lightweight_hydrator(
        self, ctx: HookContext, state: SessionState, merged_result: CanonicalHookOutput
    ) -> None:
        """Inject non-blocking UserPromptSubmit context: routing hint + PKB nudge.

        Coverage matrix (deliberate — see D2 [[aops-1e16725d]]):

        | Surface                         | Routing hint | PKB nudge |
        | ------------------------------- | :----------: | :-------: |
        | Main session                    |      ✓       |     ✓     |
        | Task() subagent / sidechain     |      ✗       |     ✓     |
        | Background task-notification    |      ✗       |     ✗     |

        - Routing hint (`hydration.warn`) is a MAIN-SESSION concern only:
          subagents are spawned with an explicit toolset by their parent and
          do not route skills, so the routing table is noise for them.
        - PKB nudge (`pkb.nudge`, T0) fires for EVERY real user prompt — main
          session AND subagents. It is one static line (no NLP, no MCP call),
          so the D2 over-injection failure mode does not apply and broad
          coverage IS the goal: a Task() subagent that confabulates instead of
          searching the PKB is exactly the retrieval gap T0 exists to close.
          Subagent coverage is intentional, not an accident of the routing
          hint's subagent skip (the prior early-return suppressed it).
        - Task-notification prompts are internal plumbing, not real user input
          — inject nothing for either surface.
        """
        # Background notifications are not real user input — inject nothing.
        if self._is_task_notification(ctx):
            return

        from lib.template_registry import TemplateRegistry

        # Routing table hint — main session only.
        if not ctx.is_subagent:
            try:
                variables = {
                    "session_id": ctx.session_id,
                }
                hint = TemplateRegistry.instance().render("hydration.warn", variables)
                if hint:
                    if merged_result.context_injection:
                        merged_result.context_injection = (
                            f"{merged_result.context_injection}\n\n{hint}"
                        )
                    else:
                        merged_result.context_injection = hint
            except Exception as e:
                print(f"WARNING: lightweight_hydrator error: {e}", file=sys.stderr)

        # T0: static PKB-search nudge — injected on every real user prompt,
        # including subagents. No logic, no heuristics; the line nudges, the
        # agent decides relevance.
        try:
            nudge = TemplateRegistry.instance().render("pkb.nudge")
            if nudge:
                if merged_result.context_injection:
                    merged_result.context_injection = (
                        f"{merged_result.context_injection}\n\n{nudge}"
                    )
                else:
                    merged_result.context_injection = nudge
        except Exception as e:
            print(f"WARNING: pkb_nudge injection error: {e}", file=sys.stderr)

    @staticmethod
    def _build_ups_diagnostic(ctx: HookContext) -> dict[str, Any]:
        """Diagnostic snapshot of a UserPromptSubmit's origin signal.

        aops_2597b5ff scope D — the instrument for catching WHAT re-arms the
        exit-tier Stop gate (formerly rbg-review; consolidated into
        exit_reflection, aops_4c2949d9) with no human prompt. Nic's
        CORRECTION (2026-07-09): template-appearance is NOT proof of
        no-re-arm; his leading unverified hypothesis is that in the
        interactive head, a ``[SYSTEM NOTIFICATION - NOT USER INPUT]``
        preamble ahead of ``<task-notification>`` makes
        ``_is_task_notification`` (a bare ``.startswith`` check) return
        False, so worker-completion prompts fall through to the NORMAL gate
        path instead of the short-circuit — re-arming exit_reflection's
        UserPromptSubmit trigger unconditionally. This snapshot is captured
        for BOTH the short-circuit and the fall-through path (see the two
        call sites below) so a real UPS log line can show which branch a
        given prompt actually took, without asserting which one is the
        culprit (that diagnosis is deferred, not this PR's job).
        """
        raw_prompt = ctx.raw_input.get(
            "prompt", ""
        )  # allow-fallback: absent prompt is itself diagnostic (e.g. agy PreInvocation has none)
        prompt_text = raw_prompt if isinstance(raw_prompt, str) else ""
        return {
            # prompt_id: Claude Code >= 2.1.196 field, None on older clients
            # or non-Claude callers — absence is itself diagnostic signal.
            "prompt_id": ctx.raw_input.get("prompt_id"),
            "prompt_preview": prompt_text[:80],
            "prompt_length": len(prompt_text),
            "is_task_notification": HookRouter._is_task_notification(ctx),
        }

    def execute_hooks(self, ctx: HookContext) -> CanonicalHookOutput:
        """Run all configured gates for the event and merge results.

        Dispatches directly to GateRegistry and GenericGate methods,
        eliminating the wrapper layers in gates.py and gate_registry.py.
        """
        # Task-notification prompts are internal plumbing — not real user input.
        # No gates, hydrator, or PKB nudge run for them; the only thing added is
        # one short guidance line reminding the agent to act on the notification
        # without relaying routine background noise to the user.
        # Logging happens once, uniformly, in main() after resolve_policy() runs —
        # not here (see resolve_policy() / log_hook_event() call in main()).
        if ctx.hook_event == "UserPromptSubmit" and self._is_task_notification(ctx):
            from lib.template_registry import TemplateRegistry

            try:
                guidance = TemplateRegistry.instance().render("task_notification.guidance")
            except Exception as e:
                print(f"WARNING: task_notification.guidance injection error: {e}", file=sys.stderr)
                guidance = None
            output = CanonicalHookOutput(verdict=None, context_injection=guidance or None)
            diagnostic = self._build_ups_diagnostic(ctx)
            # No gates run on this short-circuit branch — empty, not absent,
            # so both branches' log lines carry the same diagnostic shape.
            diagnostic["gate_transitions"] = []
            output.metadata["ups_diagnostic"] = diagnostic
            return output

        merged_result = CanonicalHookOutput()
        ups_diagnostic: dict[str, Any] | None = None
        if ctx.hook_event == "UserPromptSubmit":
            ups_diagnostic = self._build_ups_diagnostic(ctx)

        # Load Session State ONCE. Thread the harness routing signals so every
        # event places artefacts in this session's real dir — required on agy,
        # which has no SessionStart to set AOPS_SESSION_STATE_DIR (aops-bc8e18c5).
        try:
            state = SessionState.load(
                ctx.session_id,
                transcript_path=ctx.transcript_path,
                client_type=ctx.client_type,
            )
        except Exception as e:
            print(f"WARNING: Failed to load session state: {e}", file=sys.stderr)
            state = SessionState.create(
                ctx.session_id,
                transcript_path=ctx.transcript_path,
                client_type=ctx.client_type,
            )
            # state.gate_modes is empty here (fresh SessionState); the
            # _dispatch_gates fallback below populates it from gate_config
            # for test/bootstrap scenarios where SessionStart hasn't run.

        # Initialize gate registry
        GateRegistry.initialize()

        # Increment per-prompt turn counter (used by gate min_turns_since_open conditions)
        if ctx.hook_event == "UserPromptSubmit":
            state.global_turn_count += 1

        # Run special handlers first (unified_logger, ntfy, etc.) then gates
        self._run_special_handlers(ctx, state, merged_result)

        # Lightweight hydrator hint (non-blocking)
        if ctx.hook_event == "UserPromptSubmit":
            self._run_lightweight_hydrator(ctx, state, merged_result)

        # Dispatch to GenericGate methods based on event type.
        # Subagent sessions return early (gates only evaluate in main session).
        result = self._dispatch_gates(ctx, state)
        if result:
            hook_output = self._gate_result_to_canonical(result)
            self._merge_result(merged_result, hook_output)

            # Append gate status icons to system message
            # but only if we were already going to print system message
            try:
                gate_status = format_gate_status_icons(state)
                if gate_status:
                    if merged_result.system_message:
                        merged_result.system_message = (
                            f"{merged_result.system_message} {gate_status}"
                        )
                    else:
                        merged_result.system_message = gate_status
            except Exception as e:
                print(f"WARNING: Gate status icons failed: {e}", file=sys.stderr)

        # Safety: auto-approve if Stop blocked >= 4 times within 2 minutes (aops-c67313ef)
        if ctx.hook_event in ("Stop", "SessionEnd") and merged_result.verdict == "deny":
            try:
                now = datetime.now().timestamp()
                block_timestamps = state.state.get("stop_block_timestamps", [])  # noqa: E501  # allow-fallback: lazy init  # fmt: skip
                # Purge entries older than 2 minutes
                block_timestamps = [ts for ts in block_timestamps if now - ts < 120.0]
                block_timestamps.append(now)
                state.state["stop_block_timestamps"] = block_timestamps
                if len(block_timestamps) >= 5:
                    merged_result.verdict = "allow"
                    warn = (
                        "⚠ SAFETY OVERRIDE: Stop hook blocked 5+ times in 2 minutes."
                        " Auto-approving to prevent stall."
                    )
                    merged_result.system_message = (
                        f"{merged_result.system_message}\n{warn}"
                        if merged_result.system_message
                        else warn
                    )
                    state.state["stop_block_timestamps"] = []
            except Exception as e:
                print(f"WARNING: Stop block safety check failed: {e}", file=sys.stderr)

        # Save Session State ONCE
        try:
            state.save()
        except Exception as e:
            print(f"CRITICAL: Failed to save session state: {e}", file=sys.stderr)

        # UPS diagnostic (aops_2597b5ff scope D): fold in every gate_transition
        # this UserPromptSubmit caused, so one metadata blob shows origin
        # signal + consequence together in the log line.
        if ups_diagnostic is not None:
            ups_diagnostic["gate_transitions"] = merged_result.metadata.get(
                "gate_transitions", []
            )  # allow-fallback: no gate transitioned is the common, non-error case
            merged_result.metadata["ups_diagnostic"] = ups_diagnostic

        # Logging happens once, uniformly, in main() after resolve_policy() runs.
        return merged_result

    def _run_special_handlers(
        self, ctx: HookContext, state: SessionState, merged_result: CanonicalHookOutput
    ) -> None:
        """Run special handlers (logging, notifications) that aren't gates."""
        # Session env setup on start
        if ctx.hook_event == "SessionStart":
            try:
                from hooks.session_env_setup import run_session_env_setup

                init_result = run_session_env_setup(ctx, state)
                if init_result:
                    hook_output = self._gate_result_to_canonical(init_result)
                    self._merge_result(merged_result, hook_output)
                    if init_result.verdict == GateVerdict.DENY:
                        return  # Fail-fast on initialization failure
            except Exception as e:
                print(f"WARNING: session_env_setup error: {e}", file=sys.stderr)

    def _dispatch_gates(self, ctx: HookContext, state: SessionState) -> GateResult | None:
        # Fallback for tests/ad-hoc invocations where SessionStart hasn't run.
        if not state.gate_modes:
            try:
                from hooks import gate_config
                from hooks.gate_config import GATE_MODE_VARS

                for name in GATE_MODE_VARS:
                    state.gate_modes[name] = getattr(gate_config, name)
            except Exception as e:
                print(f"WARNING: gate_modes fallback resolution failed: {e}", file=sys.stderr)

        """Dispatch to GenericGate methods based on event type.

        Maps hook events to GenericGate methods:
        - PreToolUse -> gate.check()
        - PostToolUse -> gate.on_tool_use()
        - UserPromptSubmit -> gate.on_user_prompt()
        - SessionStart -> gate.on_session_start()
        - Stop/SessionEnd -> gate.on_stop()
        - AfterAgent -> gate.on_after_agent()
        - SubagentStart -> gate.on_subagent_start()
        - SubagentStop -> gate.on_subagent_stop()
        """
        # PreToolUse remains skipped for subagent-classified sessions: rbg
        # carries a blocking PreToolUse policy (periodic compliance threshold),
        # and several subagent types (e.g. Explore, Plan) have no Agent-tool
        # access to satisfy a compliance-block demand — blocking them on
        # PreToolUse is an unrecoverable deadlock, not enforcement
        # (aops-55bcf1a2). This is the one deliberately-retained suppression;
        # see aops_571771b4 PR body.
        #
        # Every OTHER event now evaluates regardless of is_subagent
        # (Nic ruling 2026-07-08, aops_571771b4): gates must EVALUATE for
        # subagent-classified sessions instead of being fail-silently
        # suppressed. In particular PostToolUse — previously skipped wholesale
        # — now dispatches so ops-counter increments and other PostToolUse
        # triggers (turn_did_work, mid-edit tracking) actually run for
        # subagent-classified sessions; GenericGate.on_tool_use excludes only
        # COMPLIANCE_SUBAGENT_TYPES from the ops-counter increment itself, so
        # a compliance subagent's own internal reads still can't inflate the
        # counter it exists to reset (the aops-55bcf1a2 Bug 2 regression).
        # SESSION-LIFECYCLE events (Stop/SessionEnd/SubagentStop/
        # UserPromptSubmit) were already exempted from the old blanket skip so
        # session-level gates (IDA honesty, handover) work for Claude Code
        # background agents, which get is_subagent=True despite being
        # independent sessions (#19220):
        #   - Stop / SessionEnd  → the gate FIRES.
        #   - UserPromptSubmit    → the fire-once gate RE-ARMS for the next turn.
        #       Without this a fire-once Stop gate fires exactly once and then
        #       stays OPEN forever — IDA went silent after turn 1 in background
        #       sessions because its UPS re-arm was being dropped here.
        #   - SubagentStop        → main-context bookkeeping about a finished subagent.
        if ctx.is_subagent and ctx.hook_event == "PreToolUse":
            return None

        # NOTE: the old global `stop_hook_active` retry bypass was REMOVED here.
        # It was Claude/Gemini-only (agy never sends the flag, so it was inert
        # there), it short-circuited the whole gate loop BEFORE any gate ran —
        # defeating block-until-satisfied and starving each gate's stop_deny_count
        # escape hatch on flagged retries — and its multi-Stop granularity was
        # never pinned down. Loop safety is now CLIENT-AGNOSTIC and gate-owned:
        #   - warn gates fire-once (CLOSED→OPEN latch) so a retried Stop passes;
        #   - block gates persist until a satisfaction trigger opens them, bounded
        #     by the per-turn stop_deny_count downgrade (WARN-and-allow);
        #   - the 5-blocks-in-2-min override below is the residual wall-clock net.
        # See specs/enforcement/GATES.md (two-mode contract). agy cannot be
        # hard-blocked on Stop anyway (no forced continuation → no retry loop).

        # Don't nag a session that stopped only because it is PAUSED — yielding
        # while it waits on a backgrounded subagent/workflow/monitor or a cron to
        # wake it (is_paused, computed in normalize_input). It isn't claiming
        # "done", so the exit gates (exit_reflection/ida) shouldn't fire.
        # A genuine stop (no waking background work) still triggers them.
        # NOTE: this suppresses ALL Stop/SessionEnd gates while paused — kept in
        # sync with specs/ENFORCEMENT-MAP.md.
        if ctx.hook_event in ("Stop", "SessionEnd") and ctx.is_paused:
            return None

        # Ensure subagent_type is populated for trigger evaluation.
        # normalize_input() handles this for production calls, but tests may
        # construct HookContext directly. extract_subagent_type() covers both
        # SPAWN_TOOLS lookup and Gemini's bare agent name pattern.
        if not ctx.subagent_type and ctx.tool_name:
            tool_input: dict[str, Any] = ctx.tool_input if isinstance(ctx.tool_input, dict) else {}
            extracted, _ = extract_subagent_type(ctx.tool_name, tool_input)
            if extracted:
                ctx.subagent_type = extracted

        messages = []
        context_injections = []
        final_verdict = GateVerdict.ALLOW
        # Diagnostic instrument (aops_2597b5ff scope D): every gate state
        # transition this event caused, across every gate that ran before a
        # DENY short-circuits the loop below. Each entry comes from
        # GenericGate._evaluate_triggers via GateResult.metadata
        # ["gate_transition"] — see lib/gates/engine.py.
        gate_transitions: list[dict[str, Any]] = []

        for gate in GateRegistry.get_all_gates():
            try:
                result = self._call_gate_method(gate, ctx, state)

                if result:
                    if result.system_message:
                        messages.append(result.system_message)
                    if result.context_injection:
                        context_injections.append(result.context_injection)
                    transition = result.metadata.get("gate_transition")
                    if transition:
                        gate_transitions.append(transition)

                    # Verdict precedence: DENY > WARN > ALLOW
                    if result.verdict == GateVerdict.DENY:
                        final_verdict = GateVerdict.DENY
                        break  # First deny wins
                    elif result.verdict == GateVerdict.WARN:
                        final_verdict = GateVerdict.WARN

            except Exception as e:
                import traceback

                print(f"Gate '{gate.name}' failed: {e}", file=sys.stderr)
                traceback.print_exc(file=sys.stderr)

        metadata: dict[str, Any] = {}

        if gate_transitions:
            metadata["gate_transitions"] = gate_transitions

        if messages or context_injections or final_verdict != GateVerdict.ALLOW or gate_transitions:
            return GateResult(
                verdict=final_verdict,
                system_message="\n".join(messages) if messages else None,
                context_injection="\n\n".join(context_injections) if context_injections else None,
                metadata=metadata,
            )
        return None

    def _call_gate_method(
        self, gate: "GenericGate", ctx: HookContext, state: SessionState
    ) -> GateResult | None:
        """Call the appropriate gate method based on hook event."""
        event = ctx.hook_event
        if event == "PreToolUse":
            return gate.check(ctx, state)
        elif event == "PostToolUse":
            return gate.on_tool_use(ctx, state)
        elif event == "UserPromptSubmit":
            return gate.on_user_prompt(ctx, state)
        elif event == "SessionStart":
            return gate.on_session_start(ctx, state)
        elif event in ("Stop", "SessionEnd"):
            return gate.on_stop(ctx, state)
        elif event == "AfterAgent":
            return gate.on_after_agent(ctx, state)
        elif event == "SubagentStart":
            return gate.on_subagent_start(ctx, state)
        elif event == "SubagentStop":
            return gate.on_subagent_stop(ctx, state)
        return None

    def _gate_result_to_canonical(self, result: GateResult) -> CanonicalHookOutput:
        """Convert GateResult to CanonicalHookOutput."""
        return CanonicalHookOutput(
            verdict=result.verdict.value,
            system_message=result.system_message,
            context_injection=result.context_injection,
            metadata=result.metadata,
        )

    def _merge_result(self, target: CanonicalHookOutput, source: CanonicalHookOutput):
        """Merge source into target (in-place)."""
        if source.verdict == "deny":
            target.verdict = "deny"
        elif source.verdict == "ask" and target.verdict != "deny":
            target.verdict = "ask"
        elif source.verdict == "warn" and target.verdict == "allow":
            target.verdict = "warn"

        if source.system_message:
            target.system_message = (
                f"{target.system_message}\n{source.system_message}"
                if target.system_message
                else source.system_message
            )

        if source.context_injection:
            target.context_injection = (
                f"{target.context_injection}\n\n{source.context_injection}"
                if target.context_injection
                else source.context_injection
            )

        target.metadata.update(source.metadata)

    # ------------------------------------------------------------------
    # Claude Code
    # ------------------------------------------------------------------

    def output_for_claude(
        self, result: CanonicalHookOutput, event: str
    ) -> ClaudeGeneralHookOutput | ClaudeStopHookOutput:
        """Format for Claude Code. Thin wrapper: resolve policy, then translate.

        Kept as a single public entry point so existing call sites and tests
        that invoke ``output_for_claude(canonical, event)`` directly keep
        working unchanged.
        """
        resolved = self.resolve_policy_for_claude(result, event)
        return self.translate_claude(resolved, event)

    def resolve_policy_for_claude(
        self, result: CanonicalHookOutput, event: str
    ) -> ResolvedDecision:
        """All Claude JSON-channel verdict-changing policy, for every event
        Claude can receive.

        This ALWAYS resolves to the JSON channel. Keeping this method
        pure "give me the Stop/general JSON shape" call for direct callers
        and tests, exactly like the pre-refactor renderer.

        Stop/SessionEnd get the full channel-routing treatment (warn->
        block-to-deliver upgrade, advisory cleanup — see
        ``_resolve_policy_for_claude_stop``); every other event gets the
        simpler HSO verdict mapping plus the event-support validity checks
        that used to live inline in the renderer (see
        ``_resolve_policy_for_claude_general``).
        """
        if event in ("Stop", "SessionEnd"):
            return self._resolve_policy_for_claude_stop(result, event)
        return self._resolve_policy_for_claude_general(result, event)

    def _resolve_policy_for_claude_stop(
        self, result: CanonicalHookOutput, event: str
    ) -> ResolvedDecision:
        """Stop/SessionEnd JSON-channel routing. The DECISION of whether a
        warn-mode advisory must block-to-deliver is POLICY, read from the SSoT
        channel table (client_spec) — not hardcoded in the renderer. See
        ``ClaudeStopHookOutput`` docstring for the live-verification history
        behind ``agent_context_without_block``.
        """
        spec = client_spec.channel_spec("claude", "Stop")
        # channel_spec("claude","Stop").agent_context_without_block:
        #   True  (Claude Code 2.1.191, mem-4ab6cc0b, live-verified
        #          2026-06-25) -> a warn that only needs to DELIVER advisory
        #          rides hookSpecificOutput.additionalContext WITHOUT a block.
        #          This RETIRES the legacy WARN->block-to-deliver upgrade.
        #   False (legacy 2.1.158) -> no agent-only Stop channel, so a warn
        #          carrying advisory must upgrade to decision="block"+reason
        #          purely to deliver it.
        #
        # ENFORCEMENT (deny/block-mode handover) ALWAYS blocks — delivery !=
        # enforcement: a non-blocking nudge can be disregarded by the model
        # (mem-4ab6cc0b), so block-mode gates keep decision="block".
        agent_ctx_without_block = bool(spec and spec.agent_context_without_block)

        ctx_inj = result.context_injection
        sys_msg = result.system_message

        # The Stop `reason` field is BOTH user-visible (Claude Code renders a
        # blocking Stop hook's reason as a notice) and agent-visible — there is
        # no agent-only `reason` channel. Strip whitespace so the advisory
        # reads as a clean notice. `context` (additionalContext) is
        # agent-only, so it keeps markers/formatting intact (the gate's trust
        # framing).
        agent_reason = _clean_advisory(ctx_inj)

        if result.verdict == "deny":
            # Enforcement path: must HALT the agent.
            wire_decision = "block"
            reason = agent_reason
            context = None
        elif result.verdict == "warn" and ctx_inj:
            if agent_ctx_without_block:
                # Deliver without blocking — additionalContext reaches the
                # agent's context on the next turn (it keeps continuing).
                wire_decision = "allow"
                reason = None
                context = ctx_inj
            else:
                # No agent-only channel: upgrade to block purely to deliver.
                wire_decision = "block"
                reason = agent_reason
                context = None
        else:
            wire_decision = "allow"
            reason = None
            context = None

        return ResolvedDecision(
            channel="json",
            wire_decision=wire_decision,
            # banner is a short, user-facing summary. Surfaced via user-visible
            # channels only. Do NOT echo ctx_inj here — that was the channel
            # that leaked advisory text to the user transcript (aops-d10e7db6).
            banner=sys_msg,
            reason=reason,
            context=context,
            metadata=result.metadata,
        )

    def _resolve_policy_for_claude_general(
        self, result: CanonicalHookOutput, event: str
    ) -> ResolvedDecision:
        """Policy for every Claude event except Stop/SessionEnd: event-support
        validity checks (Claude rejects hookSpecificOutput / blocking verdicts
        outside ``_CLAUDE_HSO_EVENTS``) plus the warn->allow collapse (Claude's
        general HSO events have no non-blocking "deliver advisory" verdict
        distinct from allow).
        """
        if event not in _CLAUDE_HSO_EVENTS:
            # Claude Code exposes NO hookSpecificOutput channel for these events
            # (SessionStart / SubagentStart / SubagentStop / AfterAgent), so an
            # advisory ``context_injection`` cannot be delivered to the agent and
            # a blocking verdict cannot be enforced. That does NOT make either a
            # misconfiguration: a MULTI-EVENT trigger legitimately produces them
            # here — the rbg reset trigger fires on
            # ``^(PreToolUse|SubagentStart|SubagentStop)$`` with ONE shared
            # transition, so the same rbg run that delivers its ``rbg.verified``
            # advisory on the PreToolUse leg (an HSO event) also carries it onto
            # SubagentStart, where it has nowhere to go. The load-bearing state
            # change (counter reset, gate open) already persisted in
            # ``execute_hooks`` (``state.save()``) BEFORE we reach output
            # formatting, so nothing is lost by dropping the undeliverable copy.
            #
            # DROP the undeliverable channel with a loud stderr breadcrumb — a
            # runtime hook must NEVER crash the session over an advisory it
            # merely can't route on this event. Raising here (the strict posture
            # introduced by the agy-focused refactor in 600985c9) turned a benign
            # redundant advisory into a whole-hook ValueError on every rbg
            # dispatch ("Failed with non-blocking status code: Traceback ...").
            # This restores the pre-600985c9 graceful-drop and matches the
            # TestNonHSOEventSafety contract ("silently dropped").
            if result.context_injection:
                print(
                    "WARNING: Claude Code has no context_injection (advisory) "
                    f"channel for {event}; dropping advisory: {result.context_injection!r}",
                    file=sys.stderr,
                )
            if result.verdict in ("deny", "ask"):
                print(
                    f"WARNING: Claude Code cannot enforce a {result.verdict!r} "
                    f"verdict for {event}; downgrading to allow.",
                    file=sys.stderr,
                )
            return ResolvedDecision(
                channel="json", banner=result.system_message, metadata=result.metadata
            )

        if result.verdict is None:
            wire_decision = None
        elif result.verdict == "deny":
            wire_decision = "block"
        elif result.verdict == "ask":
            wire_decision = "ask"
        else:  # "allow" or "warn" — warn collapses to allow
            wire_decision = "allow"

        reason = result.system_message if wire_decision in ("block", "ask") else None

        return ResolvedDecision(
            channel="json",
            wire_decision=wire_decision,
            banner=result.system_message,
            reason=reason,
            context=result.context_injection,
            metadata=result.metadata,
        )

    def translate_claude(
        self, resolved: ResolvedDecision, event: str
    ) -> ClaudeGeneralHookOutput | ClaudeStopHookOutput:
        """Pure mechanical mapping from a resolved decision to Claude's wire
        schema. No policy left here — every branch is a fixed, deterministic
        field-name/shape mapping. See ``resolve_policy_for_claude`` for the
        decisions that produced ``resolved``.
        """
        if event in ("Stop", "SessionEnd"):
            return self._translate_claude_stop(resolved, event)
        return self._translate_claude_general(resolved, event)

    def _translate_claude_stop(
        self, resolved: ResolvedDecision, event: str
    ) -> ClaudeStopHookOutput:
        output = ClaudeStopHookOutput()

        if resolved.wire_decision == "block":
            output.decision = "block"
            if resolved.reason:
                output.reason = resolved.reason
        elif resolved.context:
            output.decision = "approve"
            output.hookSpecificOutput = ClaudeHookSpecificOutput(
                hookEventName=event, additionalContext=resolved.context
            )
        else:
            output.decision = "approve"

        if resolved.banner:
            output.stopReason = resolved.banner
            output.systemMessage = resolved.banner

        return output

    def _translate_claude_general(
        self, resolved: ResolvedDecision, event: str
    ) -> ClaudeGeneralHookOutput:
        output = ClaudeGeneralHookOutput()
        if resolved.banner:
            output.systemMessage = resolved.banner

        if event not in _CLAUDE_HSO_EVENTS:
            return output

        hso = ClaudeHookSpecificOutput(hookEventName=event)
        has_hso = False

        if resolved.wire_decision == "block":
            hso.permissionDecision = "deny"
            hso.permissionDecisionReason = resolved.reason
            has_hso = True
        elif resolved.wire_decision == "ask":
            hso.permissionDecision = "ask"
            hso.permissionDecisionReason = resolved.reason
            has_hso = True
        elif resolved.wire_decision == "allow":
            hso.permissionDecision = "allow"
            has_hso = True

        if resolved.context:
            hso.additionalContext = resolved.context
            has_hso = True

        if has_hso:
            output.hookSpecificOutput = hso

        return output

    # ------------------------------------------------------------------
    # agy (Antigravity)
    # ------------------------------------------------------------------

    def output_for_agy(self, result: CanonicalHookOutput, event: str) -> dict[str, Any]:
        """Translate the internal verdict to an ``exa.hooks_pb.*Result`` protojson dict.

        Thin wrapper: resolve policy, then translate. Kept as a single public
        entry point so existing call sites and tests that invoke
        ``output_for_agy(canonical, event)`` directly keep working unchanged.

        agy/Antigravity parses hook stdout as **protojson** against the per-event
        ``*Result`` message and rejects on the FIRST unknown field. That is the
        silent-drop regression in aops-27004ffd: the Claude/Gemini schema's
        ``decision`` / ``metadata`` / ``systemMessage`` are all *unknown* fields
        to ``exa.hooks_pb``, so routing agy through ``output_for_gemini`` made the
        harness discard every verdict (including RBG DENYs) while the router
        exited 0. ``translate_agy`` therefore emits ONLY the fields each
        ``*Result`` defines — and never ``metadata``.

        ``event`` is the ORIGINAL agy event name (``PreToolUse``, ``PostToolUse``,
        ``PreInvocation``, ``PostInvocation``, ``Stop``) — NOT the router's
        internal mapped name. agy maps ``PreInvocation``→UserPromptSubmit and
        ``PostInvocation``→Stop many-to-one, so the original name is required to
        select the correct ``*Result`` shape.

        Enum-string status (blocked on live-agy discovery, aops-939b6c3a):
          * The PreToolUse DENY path is expressed STRUCTURALLY via the top-level
            ``allowTool=false`` + ``denyReason`` fields of ``PreToolHookResult``
            (the safety-critical "deny actually blocks" path). It needs NO enum
            string. The fields are TOP-LEVEL on ``PreToolHookResult`` — NOT
            nested inside ``permissionOverrides`` (which is a *repeated* per-tool
            override list, a separate concept; nesting them there made protojson
            reject with ``syntax error … unexpected token {`` because it expected
            ``[`` for the repeated field — aops-891c0e36).
          * The Stop ``decision`` and PostInvocation ``terminationBehavior`` enum
            STRINGS (the hard stop-block) are not yet live-verified. We do NOT
            guess them — a wrong enum is silently discarded by agy, which is worse
            than a clean miss — so the hard stop-block field is intentionally not
            emitted. The advisory is still delivered via ``injectSteps`` on the
            result types that support it.
        """
        resolved = self.resolve_policy_for_agy(result, event)
        return self.translate_agy(resolved, event)

    def resolve_policy_for_agy(self, result: CanonicalHookOutput, event: str) -> ResolvedDecision:
        """agy verdict-changing policy: ``ask`` collapses into ``block`` (headless
        — agy can't prompt for confirmation), advisory/reason text is
        whitespace-cleaned, and each event's content-support validity is
        checked HERE (client+event-aware policy, not mechanical translation) so
        ``translate_agy`` never needs to raise.
        """
        # "ask" cannot prompt in a headless agy run, so the safe, enforcing
        # interpretation of a gate that wanted to stop-and-confirm is to block.
        wire_decision = "block" if result.verdict in ("deny", "ask") else "allow"
        context = _clean_advisory(result.context_injection)
        reason = _clean_advisory(result.system_message)

        if event == "PreToolUse":
            # PreToolHookResult only supports allowTool and denyReason.
            # denyReason corresponds strictly to short_reason (system_message).
            # It DOES NOT support advisory (context_injection).
            if wire_decision == "block":
                if not reason:
                    raise ValueError(
                        f"agy PreToolUse deny requires short_reason. (Got advisory: {context!r})"
                    )
                if context:
                    # Same undeliverable-content class as the PreToolUse
                    # allow/warn branch and PostToolUse fixes above
                    # (task_499355a9, aops_e5e2c80f). PreToolHookResult's
                    # block branch carries denyReason (reason) fine, but has
                    # no field for advisory text; drop it loudly instead of
                    # crashing the hook.
                    print(
                        f"WARNING: agy PreToolUse block cannot carry advisory "
                        f"text — dropping undeliverable content_injection (context={context!r}).",
                        file=sys.stderr,
                    )
                    result.metadata["delivery_dropped"] = {
                        "event": event,
                        "client": "agy",
                        "reason": None,
                        "context": context,
                    }
                    context = None
            else:
                if context:
                    # Same undeliverable-content class as the PostToolUse
                    # case above, live-reproduced twice this tick (agy-test2,
                    # agy-test3 — the `rbg` gate's periodic countdown fires
                    # here on plain tool use and crashed every time,
                    # task_499355a9). PreToolHookResult's allow branch has no
                    # field for advisory text; drop it loudly instead of
                    # crashing the hook.
                    print(
                        f"WARNING: agy PreToolUse allow/warn cannot carry advisory "
                        f"text — dropping undeliverable content_injection (context={context!r}).",
                        file=sys.stderr,
                    )
                    result.metadata["delivery_dropped"] = {
                        "event": event,
                        "client": "agy",
                        "reason": None,
                        "context": context,
                    }
                    context = None
                # allowTool has no field for short_reason; translate_agy's allow
                # branch can't emit it, so clear it here rather than logging a
                # `resolved.reason` that never actually reaches the wire.
                reason = None
        elif event == "PostToolUse":
            if reason or context:
                # agy's PostToolHookResult protojson has no field to carry a
                # message (translate_agy's PostToolUse branch always emits
                # {}) — this content is structurally undeliverable to agy on
                # this event. Raising here used to crash the whole hook
                # subprocess: it exited non-zero with no stdout, agy silently
                # treated that as a no-op, and the only trace was a
                # misleading log entry carrying the pre-crash gate message as
                # if it had reached the user (aops_e5e2c80f — a fabricated
                # "◇ Compliance verified." system_message on a PostToolUse
                # record whose handler had actually thrown). Drop the content
                # instead, but loudly: per O1's delivery-liveness-alarm
                # requirement (task_499355a9), a silently-dropped gate must
                # never be indistinguishable from a passing one.
                print(
                    f"WARNING: agy PostToolUse cannot carry a message — dropping "
                    f"undeliverable content (reason={reason!r}, context={context!r}).",
                    file=sys.stderr,
                )
                result.metadata["delivery_dropped"] = {
                    "event": event,
                    "client": "agy",
                    "reason": reason,
                    "context": context,
                }
                reason = None
                context = None
        elif event in ("PreInvocation", "PostInvocation"):
            pass  # both reason and context are supported, folded into injectSteps by translate_agy
        elif event == "Stop":
            # StopHookResult {decision, reason}. reason is strictly the system_message.
            if context:
                # Same undeliverable-content class as the PreToolUse/PostToolUse
                # fixes above (task_499355a9, aops_e5e2c80f). StopHookResult
                # carries reason (system_message) fine, but has no field for
                # advisory text; drop it loudly instead of crashing the hook.
                print(
                    f"WARNING: agy Stop cannot carry advisory text — dropping "
                    f"undeliverable content_injection (context={context!r}).",
                    file=sys.stderr,
                )
                result.metadata["delivery_dropped"] = {
                    "event": event,
                    "client": "agy",
                    "reason": None,
                    "context": context,
                }
                context = None
            if wire_decision == "block" and not reason:
                raise ValueError("agy Stop block requires a system_message (short_reason).")
        else:
            # Unknown / unmapped event: only the empty object validates against
            # any *Result without triggering an unknown-field rejection.
            if reason or context:
                raise ValueError(f"agy does not support any fields for unmapped event {event}.")

        return ResolvedDecision(
            channel="json",
            wire_decision=wire_decision,
            reason=reason,
            context=context,
            metadata=result.metadata,
        )

    def translate_agy(self, resolved: ResolvedDecision, event: str) -> dict[str, Any]:
        """Pure mechanical mapping from a resolved decision to agy's per-event
        protojson shape. No validation left here — ``resolve_policy_for_agy``
        already proved the content fits this event's ``*Result`` shape.
        """
        is_block = resolved.wire_decision == "block"
        reason = resolved.reason
        context = resolved.context

        if event == "PreToolUse":
            if is_block:
                return {"allowTool": False, "denyReason": reason}
            return {"allowTool": True}

        if event == "PostToolUse":
            return {}

        if event in ("PreInvocation", "PostInvocation"):
            steps = []
            if reason:
                steps.append({"ephemeralMessage": reason})
            if context:
                hidden_advisory = (
                    "<details><summary>System Advisory (Agent Context)</summary>\n\n"
                    f"{context}\n</details>"
                )
                steps.append({"ephemeralMessage": hidden_advisory})
            return {"injectSteps": steps} if steps else {}

        if event == "Stop":
            return {"reason": reason} if reason else {}

        return {}


# --- Main Entry Point ---


def main():
    import argparse

    parser = argparse.ArgumentParser(description="Universal Hook Router")
    parser.add_argument("--client", choices=["claude", "agy"], help="Client type (claude or agy)")
    parser.add_argument("event", nargs="?", help="Event name (required for agy if not in payload)")

    # Parse known args to avoid issues if extra flags are passed
    args, unknown = parser.parse_known_args()

    router = HookRouter()

    # Read Input First (needed for detection)
    raw_input = {}
    try:
        if not sys.stdin.isatty():
            input_data = sys.stdin.read()
            if input_data.strip():
                raw_input = json.loads(input_data)
    except Exception as e:
        print(f"WARNING: Failed to read stdin: {e}", file=sys.stderr)

    # Capture the ORIGINAL event name before normalize_input() maps + pops it.
    # agy keys its protojson *Result on the native event (PreInvocation /
    # PostInvocation / Stop map many-to-one onto the internal name), so the
    # agy formatter needs the pre-mapping name.
    raw_event_name = raw_input.get("hook_event_name")

    # Debug log all input (enable with DEBUG_HOOKS=1)
    _debug_log_input(raw_input, args)

    # Detect Invocation Mode, relying on explicit --client flag
    if args.client:
        client_type = args.client
        cli_event = args.event
    else:
        raise OSError("No --client flag provided on hook invocation.")

    # Pipeline
    ctx = None
    result = None
    try:
        ctx = router.normalize_input(raw_input, cli_event, client_type=client_type)
        result = router.execute_hooks(ctx)

        # agy keys its protojson *Result on the ORIGINAL agy event name
        # (PreInvocation/PostInvocation/Stop map many-to-one onto the router's
        # internal mapped name), so it needs the pre-mapping name; Claude
        # uses the internal mapped name.
        agy_event = cli_event or raw_event_name or ctx.hook_event
        render_event = agy_event if client_type == "agy" else ctx.hook_event

        # resolve_policy() is the LAST point at which a hook event's fate can
        # still change: Stop channel routing, advisory cleanup, the
        # general-event warn->allow collapse, agy's ask->block collapse, and
        # per-client/event validity checks all run here. Everything after this is
        # pure, deterministic field-mapping (translate_*) — so logging the
        # resolved decision right after this
        # point IS logging what will actually be sent, in one shared shape
        # regardless of client.
        if client_type == "agy":
            resolved = router.resolve_policy_for_agy(result, render_event)
        else:
            resolved = router.resolve_policy_for_claude(result, render_event)

        exit_code = 0

        # Logging must never be the reason a hook fails to deliver its real
        # payload to the client — a logging failure is caught and warned here,
        # not allowed to propagate up to the crash handler below.
        try:
            log_hook_event(ctx, output=result, resolved=resolved, exit_code=exit_code)
        except Exception as e:
            print(f"WARNING: Failed to log hook event: {e}", file=sys.stderr)

        # Output (JSON conversion happens only here — translate_* is pure)
        if client_type == "agy":
            # agy parses stdout as exa.hooks_pb.*Result protojson and rejects on the
            # first unknown field — it does NOT speak Claude's hook dialect (the
            # silent-drop bug 4c73f02a introduced; aops-27004ffd).
            print(json.dumps(router.translate_agy(resolved, render_event)))
        else:
            output = router.translate_claude(resolved, render_event)
            print(output.model_dump_json(exclude_none=True))
    except Exception as e:
        import traceback

        error_msg = f"{e.__class__.__name__}: {str(e)}\n{traceback.format_exc()}"

        if ctx is None:
            from lib.hook_context import HookContext

            session_id = (
                raw_input.get("session_id") or os.environ.get("AOPS_SESSION_ID") or "unknown"
            )  # allow-fallback: session_id is optional in crash-logging context
            hook_event = cli_event or raw_event_name or "unknown"
            ctx = HookContext(
                session_id=session_id,
                hook_event=hook_event,
                client_type=client_type,
                raw_input=raw_input,
            )

        try:
            # `log_hook_event` is already imported at module scope (top of
            # file) — re-importing it locally here would shadow that name for
            # this ENTIRE function (Python scopes a name assigned anywhere in a
            # function, including a local `import`, to the whole function
            # body), breaking the earlier module-level call in the try block
            # above with an UnboundLocalError.
            #
            # `result` (the gate's true CanonicalHookOutput) is included when
            # available — e.g. gate execution succeeded but resolve_policy/
            # translation failed — so a crash entry still shows what the gates
            # decided, not just that something broke.
            log_hook_event(ctx, output=result, exit_code=1, error=error_msg)
        except Exception as log_err:
            print(f"WARNING: Failed to log crashed hook event: {log_err}", file=sys.stderr)

        raise e


if __name__ == "__main__":
    main()
