"""aOps library - shared utilities for the framework."""
