---
title: null
permalink: aops/skills/markdown-ops/assets/bmem-template
tags: []
type: note
---

#

## Context



## Observations

- [fact]
- [idea]
- [decision]
- [technique]
- [requirement]
- [insight]
- [problem]
- [solution]
- [question]

## Relations

- relates_to [[]]
- implements [[]]
- requires [[]]
- extends [[]]
- part_of [[]]