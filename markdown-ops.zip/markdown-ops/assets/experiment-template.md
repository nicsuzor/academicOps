# [Experiment Name]

## Metadata
- Date: YYYY-MM-DD
- Issue: #NNN
- Commit: [hash]
- Model: [claude-sonnet-4-5/gemini-2.0-flash]

## Context

[Background and motivation for this experiment]

## Hypothesis

[What you expect to happen]

## Changes Made

[Specific modifications with file paths and line numbers]

## Success Criteria

[How to measure if this worked - concrete metrics]

## Results

[What actually happened - fill after testing]

## Outcome

[Success/Failure/Partial - decision with justification]

## Notes

[Additional observations, unexpected findings, lessons learned]
